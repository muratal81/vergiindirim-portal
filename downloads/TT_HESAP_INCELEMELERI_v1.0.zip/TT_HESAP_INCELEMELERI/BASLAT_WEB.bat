@echo off
REM ====================================================================
REM   TT Hesap Incelemeleri - WEB (Flask) Modu Baslatici
REM ====================================================================
cd /d "%~dp0program"
if not exist "web\server.py" (
    echo.
    echo  HATA: program\web\server.py bulunamadi.
    echo  Bu .bat dosyasini ZIP'in icinden DOGRUDAN calistirmayin.
    echo  Once .zip dosyasina SAG TIKLA - TUMUNU AYIKLA yapin,
    echo  cikan klasor icinden bu .bat dosyasini calistirin.
    echo.
    pause
    exit /b 1
)
echo.
echo  Tam Tasdik Raporu - Hesap Incelemeleri
echo  Web sunucusu baslatiliyor... (Otomatik olarak tarayicida acilacak)
echo  Adres: http://localhost:5000
echo.
echo  Sunucuyu kapatmak icin Ctrl+C basin veya bu pencereyi kapatin.
echo.
py web\server.py
if errorlevel 1 (
    echo.
    echo  HATA: Web sunucusu baslatilamadi.
    echo  Once KURULUM.bat dosyasina cift tiklayin (Python paketleri icin).
    echo.
    pause
)
