"""GUI olmadan dogrudan test: gercek dosyalar uzerinde programi calistir."""
import sys
import os
from pathlib import Path

# Modul yolu
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from parsers.mizan_parser import parse_mizan, parse_dovizli_mizan
from parsers.bilanco_parser import parse_bilanco, parse_gelir_tablosu
from parsers.beyanname_parser import parse_beyanname
from engine.data_model import RaporVerisi, MukellefBilgileri, KurTablosu
from engine.mutabakat import kontrolleri_calistir
from engine.rapor_motoru import hesap_incelemeleri_uret
from docx_writer.rapor_yazici import yaz_word_raporu


def main():
    # Test dosyalari
    base = Path("C:/Users/Murat/Dropbox/PAYLAŞIM/MURAT ALAN (Case Conflict)/2026/CLAUDE DOSYASI/PROGRAMLAR (Case Conflict)/TT HESAP İNCELEMERLİ PROGRAMI")
    mizan_path = str(base / "2024-4 GELİR TABLOSU-BİLANÇO R5-VDK DZT.xlsx")
    beyanname_path = str(base / "006283_3200039053_KURUMLAR_28_01012024-31122024.XM_BYN_YAYLA.pdf")
    output_dir = str(BASE_DIR / "ornek_ciktilar")
    os.makedirs(output_dir, exist_ok=True)

    print(f"[1/6] Mizan okunuyor...")
    mizan = parse_mizan(mizan_path, sheet_name="Mizan")
    print(f"      {len(mizan)} mizan satiri.")

    print(f"[2/6] Dovizli Mizan okunuyor...")
    dovizli = parse_dovizli_mizan(mizan_path, sheet_name="Dövizli Mizan")
    print(f"      {len(dovizli)} dovizli mizan satiri.")

    print(f"[3/6] Bilanco okunuyor...")
    bilanco = parse_bilanco(mizan_path, sheet_name="Bilanço", hedef_donem="31.12.2024")
    print(f"      {len(bilanco)} bilanco satiri.")

    print(f"[4/6] Gelir Tablosu okunuyor...")
    gelir = parse_gelir_tablosu(mizan_path, sheet_name="Gelir Tablosu", hedef_donem="31.12.2024")
    print(f"      {len(gelir)} gelir tablosu satiri.")

    print(f"[5/6] Beyanname okunuyor...")
    beyanname = parse_beyanname(beyanname_path)
    print(f"      VKN={beyanname.vergi_no}, Unvan={beyanname.unvan}")
    print(f"      Ticari Bilanco Kari: {beyanname.ticari_bilanco_kari:,.2f}")
    print(f"      KKEG: {beyanname.kkeg_toplam:,.2f}")
    print(f"      Matrah: {beyanname.matrah:,.2f}")
    print(f"      Hesaplanan Vergi: {beyanname.hesaplanan_vergi:,.2f}")
    print(f"      Yil Ici Kesinti: {beyanname.yil_ici_kesinti:,.2f}")
    print(f"      Beyanname Bilanco Satirlari: {len(beyanname.bilanco_satirlari)}")
    print(f"      Beyanname Gelir Tablosu Satirlari: {len(beyanname.gelir_tablosu_satirlari)}")

    mukellef = MukellefBilgileri(
        vergi_no=beyanname.vergi_no or "3200039053",
        unvan=beyanname.unvan or "YAYLA AGRO GIDA SAN. TIC.A.S.",
        vergi_dairesi=beyanname.vergi_dairesi or "ANKARA KURUMLAR",
        donem_baslangic="01.01.2024",
        donem_bitis="31.12.2024",
        rapor_no="YMM-TEST-2025/001",
        ymm_adi="CUMHUR INAN BILEN",
    )

    kurlar = KurTablosu()  # varsayilan 31.12.2024 kurlari

    rapor = RaporVerisi(
        mukellef=mukellef,
        mizan=mizan,
        dovizli_mizan=dovizli,
        bilanco=bilanco,
        gelir_tablosu=gelir,
        beyanname=beyanname,
        kurlar=kurlar,
    )

    print(f"[6/6] Mutabakat kontrolleri...")
    bulgular = kontrolleri_calistir(rapor)
    print(f"      {len(bulgular)} bulgu (kritik: {sum(1 for b in bulgular if b.onem == 'kritik')}, uyari: {sum(1 for b in bulgular if b.onem == 'uyari')})")
    for b in bulgular[:5]:
        print(f"        {b.kod}: {b.aciklama[:80]} | Fark: {b.fark:,.2f}")

    print("Bloklar uretiliyor...")
    bloklar = hesap_incelemeleri_uret(rapor)
    print(f"      {len(bloklar)} blok uretildi.")
    # Onizleme
    for blok in bloklar[:15]:
        if blok["tip"] in ("h1", "h2", "h3", "h4"):
            print(f"      [{blok['tip']}] {blok['metin'][:80]}")

    output_path = os.path.join(output_dir, "TEST_Hesap_Incelemeleri_YAYLA_AGRO.docx")
    print(f"Word yaziliyor: {output_path}")
    yaz_word_raporu(rapor, bloklar, output_path)
    print(f"BASARILI! Dosya: {output_path}")
    print(f"Dosya boyutu: {os.path.getsize(output_path):,} bytes")


if __name__ == "__main__":
    try:
        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    except Exception:
        pass
    main()
