# Tam Tasdik Raporu - Hesap Incelemeleri Otomasyonu

Bu program, mizan (Excel) ve Kurumlar Vergisi Beyannamesi (PDF) dosyalarini okuyarak,
Tam Tasdik Raporu'nun **"III- Hesap Incelemeleri"** (A. Bilanco Hesaplari + B. Gelir Tablosu Hesaplari)
bolumunu Microsoft Word (.docx) formatinda uretir.

## Program Konumu

Programın masaüstü konumu:
```
C:\Users\Murat\Dropbox\PAYLAŞIM\MURAT ALAN (Case Conflict)\2026\CLAUDE DOSYASI\PROGRAMLAR (Case Conflict)\TT HESAP İNCELEMERLİ PROGRAMI
```

Bu klasorde 3 baslatici dosya bulunur:
- **`KURULUM.bat`** — Ilk kurulum (Python paketlerini yukler)
- **`BASLAT_MASAUSTU.bat`** — tkinter masaustu penceresi
- **`BASLAT_WEB.bat`** — Web sunucusu + tarayicida otomatik acilis

## Ilk Kurulum

1. Python 3.11+ yuklu olmalidir (yoksa <https://python.org> adresinden yukleyin).
2. `KURULUM.bat` dosyasina **cift tiklayin** — su paketler yuklenir:
   - python-docx, openpyxl, pdfplumber, flask

## Calistirma

### Yontem 1: Web (Tarayici) Uzerinden — TAVSIYE EDILEN

1. `BASLAT_WEB.bat` dosyasina **cift tiklayin**.
2. Otomatik olarak varsayilan tarayiciniz `http://localhost:5000` adresini acar.
3. Form uzerinden:
   - **1. Dosyalar:** Mizan Excel + Beyanname PDF yukle
   - **2. Mukellef:** (beyannameden otomatik dolar)
   - **3. Kur:** 31.12.2024 icin 580 No.lu VUK GT kurlari hazir
   - **4. Raporu Uret:** Butona basinca .docx otomatik indirilir
4. Sunucuyu kapatmak icin BASLAT_WEB.bat penceresinde **Ctrl+C** basin.

### Yontem 2: Masaustu (tkinter) Penceresi

1. `BASLAT_MASAUSTU.bat` dosyasina **cift tiklayin**.
2. Tab tab dosyalari ve bilgileri girin, "RAPORU URET" butonuna basin.
3. Cikti `TT_HESAP_INCELEMELERI\ornek_ciktilar\` klasorune kaydedilir.

## Cikti

Uretilen Word dosyasi su yapidadir:
- Kapak sayfasi (mukellef, donem, rapor no, YMM)
- Mutabakat bulgulari (varsa - sari/kirmizi tablo)
- **III- HESAP INCELEMELERI**
  - **A. Bilanco Hesaplarina Iliskin Incelemeler**
    - Yabanci para hesaplari + doviz tablolari
    - Diger bilanco hesaplari (Cekler, Menkul Kiymetler, Supheli Alacaklar, Stoklar, MDV, MODV, Borclar)
    - Ozkaynaklar (Sermaye, Yedekler, Ozel Fonlar, Donem Kari)
  - **B. Gelir Tablosu Hesaplari**
    - Satislar, Maliyetler, Faaliyet Giderleri
    - Diger Olagan Gelir/Giderler
    - Finansman Giderleri (FGK hesabi otomatik)
    - Olagandisi kalemler
    - Donem Kari ve Vergi Karsiligi

## Klasor Yapisi

```
TT HESAP İNCELEMERLİ PROGRAMI\
├── KURULUM.bat                  ← ilk kurulum
├── BASLAT_MASAUSTU.bat          ← tkinter
├── BASLAT_WEB.bat               ← web
├── TT_HESAP_INCELEMELERI\       ← program kodu
│   ├── tt_hesap_incelemeleri.py (tkinter ana giris)
│   ├── parsers\                 (Excel/PDF okuyucular)
│   ├── engine\                  (mutabakat ve metin uretim motoru)
│   ├── docx_writer\             (Word ciktisi)
│   ├── web\                     (Flask web sunucusu)
│   │   ├── server.py
│   │   └── templates\index.html
│   └── ornek_ciktilar\          (uretilen .docx dosyalari)
└── (test dosyalari: mizan, beyanname, talimat, ornek YMM raporu)
```

## Onemli Notlar (v1.2 Talimatlarindan)

- Veri eksikse program metin **uydurmaz**; ilgili bolum bos kalir veya uyari verir.
- Program kesin rapor metni uretmeden once beyanname-mizan capraz kontrolu yapar.
  Kritik fark varsa bulgular tablosunda kirmizi olarak listelenir.
- Tutarlar `1.234.567,89-TL` formatinda, negatifler `(1.234.567,89-TL)` formatinda.
- Yabanci para hesaplari icin 28.01.2025 tarih ve 580 No.lu VUK GT ekindeki kurlar varsayilan.

## MVP Sinirlamalari (Sonraki Versiyona Birakildi)

Su kalemler **manuel kontrol/ekleme** gerektirir (program henuz uretmiyor):
- C. Diger Incelemeler (Gecici Vergi tablosu, Tevkifat detay, KKEG tablosu, Istisnalar)
- EK-1 Bilanco / EK-2 Gelir Tablosu mali tablo ekleri
- KKM Istisnasi (KVK Gecici m.14) detay tablosu
- AR-GE indirimi detayi (5746 SK)
- Yatirim Tesvik Belgesi kapsamindaki Indirimli Kurumlar
- Bagis ve Yardimlar detayi
- 7440 SK matrah artirimi
- Banka bazinda stopaj/tevkifat tablosu

Aktiflestirmek icin `engine\rapor_motoru.py` icindeki `# NOT:` satirlari kullanilabilir.
