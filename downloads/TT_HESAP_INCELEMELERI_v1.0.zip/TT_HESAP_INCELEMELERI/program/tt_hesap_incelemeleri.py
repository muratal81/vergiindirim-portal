"""TAM TASDIK RAPORU - HESAP INCELEMELERI OTOMASYONU

Mizan (Excel) + Kurumlar Vergisi Beyannamesi (PDF) okuyarak
III- Hesap Incelemeleri bolumunu Word olarak ureten masaustu program.

Kullanim: py tt_hesap_incelemeleri.py
"""
import os
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path
from datetime import datetime

# Modul yolu
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from parsers.mizan_parser import parse_mizan, parse_dovizli_mizan
from parsers.bilanco_parser import parse_bilanco, parse_gelir_tablosu
from parsers.beyanname_parser import parse_beyanname
from engine.data_model import RaporVerisi, MukellefBilgileri, KurTablosu
from engine.mutabakat import kontrolleri_calistir
from engine.rapor_motoru import hesap_incelemeleri_uret
from docx_writer.rapor_yazici import yaz_word_raporu


class TTHesapIncelemeleriApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Tam Tasdik Raporu - Hesap Incelemeleri Otomasyonu v1.0")
        self.root.geometry("780x680")

        self.mizan_path = tk.StringVar()
        self.beyanname_path = tk.StringVar()
        self.output_dir = tk.StringVar(value=str(Path.cwd()))
        self.mizan_sheet = tk.StringVar(value="Mizan")
        self.dovizli_mizan_sheet = tk.StringVar(value="Dövizli Mizan")
        self.bilanco_sheet = tk.StringVar(value="Bilanço")
        self.gelir_tablosu_sheet = tk.StringVar(value="Gelir Tablosu")
        self.hedef_donem = tk.StringVar(value="31.12.2024")

        self.vergi_no = tk.StringVar()
        self.unvan = tk.StringVar()
        self.vergi_dairesi = tk.StringVar(value="ANKARA KURUMLAR")
        self.donem_baslangic = tk.StringVar(value="01.01.2024")
        self.donem_bitis = tk.StringVar(value="31.12.2024")
        self.rapor_no = tk.StringVar()
        self.ymm_adi = tk.StringVar()

        self.kur_teblig_tarihi = tk.StringVar(value="28.01.2025")
        self.kur_teblig_no = tk.StringVar(value="580")
        self.usd_alis = tk.StringVar(value="35.2233")
        self.usd_efektif = tk.StringVar(value="35.1987")
        self.eur_alis = tk.StringVar(value="36.7429")
        self.eur_efektif = tk.StringVar(value="36.7172")
        self.gbp_alis = tk.StringVar(value="44.2458")
        self.chf_alis = tk.StringVar(value="38.9510")

        self._build_ui()

    def _build_ui(self):
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)

        # Tab 1: Dosya secimi
        tab1 = ttk.Frame(notebook)
        notebook.add(tab1, text="1. Dosyalar")
        self._build_files_tab(tab1)

        # Tab 2: Mukellef bilgileri
        tab2 = ttk.Frame(notebook)
        notebook.add(tab2, text="2. Mukellef")
        self._build_mukellef_tab(tab2)

        # Tab 3: Kur parametreleri
        tab3 = ttk.Frame(notebook)
        notebook.add(tab3, text="3. Doviz Kurlari")
        self._build_kur_tab(tab3)

        # Tab 4: Calistir
        tab4 = ttk.Frame(notebook)
        notebook.add(tab4, text="4. Rapor Uret")
        self._build_run_tab(tab4)

    def _build_files_tab(self, parent):
        frm = ttk.LabelFrame(parent, text="Mizan / Bilanco Excel Dosyasi")
        frm.pack(fill="x", padx=10, pady=8)
        ttk.Entry(frm, textvariable=self.mizan_path, width=70).grid(row=0, column=0, padx=5, pady=5)
        ttk.Button(frm, text="Sec...", command=self._sec_mizan).grid(row=0, column=1, padx=5)

        ttk.Label(frm, text="Mizan sayfa adi:").grid(row=1, column=0, sticky="w", padx=5)
        ttk.Entry(frm, textvariable=self.mizan_sheet, width=30).grid(row=1, column=1, sticky="w", padx=5, pady=2)
        ttk.Label(frm, text="Dovizli Mizan sayfa adi:").grid(row=2, column=0, sticky="w", padx=5)
        ttk.Entry(frm, textvariable=self.dovizli_mizan_sheet, width=30).grid(row=2, column=1, sticky="w", padx=5, pady=2)
        ttk.Label(frm, text="Bilanco sayfa adi:").grid(row=3, column=0, sticky="w", padx=5)
        ttk.Entry(frm, textvariable=self.bilanco_sheet, width=30).grid(row=3, column=1, sticky="w", padx=5, pady=2)
        ttk.Label(frm, text="Gelir Tablosu sayfa adi:").grid(row=4, column=0, sticky="w", padx=5)
        ttk.Entry(frm, textvariable=self.gelir_tablosu_sheet, width=30).grid(row=4, column=1, sticky="w", padx=5, pady=2)
        ttk.Label(frm, text="Hedef donem (gg.aa.yyyy):").grid(row=5, column=0, sticky="w", padx=5)
        ttk.Entry(frm, textvariable=self.hedef_donem, width=20).grid(row=5, column=1, sticky="w", padx=5, pady=2)

        frm2 = ttk.LabelFrame(parent, text="Kurumlar Vergisi Beyannamesi PDF")
        frm2.pack(fill="x", padx=10, pady=8)
        ttk.Entry(frm2, textvariable=self.beyanname_path, width=70).grid(row=0, column=0, padx=5, pady=5)
        ttk.Button(frm2, text="Sec...", command=self._sec_beyanname).grid(row=0, column=1, padx=5)

        frm3 = ttk.LabelFrame(parent, text="Cikti Klasoru")
        frm3.pack(fill="x", padx=10, pady=8)
        ttk.Entry(frm3, textvariable=self.output_dir, width=70).grid(row=0, column=0, padx=5, pady=5)
        ttk.Button(frm3, text="Sec...", command=self._sec_output).grid(row=0, column=1, padx=5)

        bilgi = ttk.Label(parent, text=(
            "Notlar:\n"
            "  - Mizan dosyasi Excel formatinda (.xlsx) olmalidir.\n"
            "  - Beyanname PDF formatinda (GIB e-Beyanname ciktisi) olmalidir.\n"
            "  - 'Cikti Klasoru' icine .docx dosyasi yazilacaktir.\n"
            "  - Beyanname yuklendiginde mukellef bilgileri otomatik doldurulmaya calisilir."
        ), justify="left", foreground="gray30")
        bilgi.pack(anchor="w", padx=15, pady=5)

    def _build_mukellef_tab(self, parent):
        frm = ttk.LabelFrame(parent, text="Mukellef ve Donem Bilgileri")
        frm.pack(fill="both", expand=True, padx=10, pady=10)
        row = 0
        for label, var, width in [
            ("Vergi Kimlik Numarasi", self.vergi_no, 25),
            ("Unvan", self.unvan, 60),
            ("Vergi Dairesi", self.vergi_dairesi, 40),
            ("Donem Baslangic (gg.aa.yyyy)", self.donem_baslangic, 20),
            ("Donem Bitis (gg.aa.yyyy)", self.donem_bitis, 20),
            ("Rapor Numarasi", self.rapor_no, 40),
            ("YMM Adi", self.ymm_adi, 50),
        ]:
            ttk.Label(frm, text=label + ":").grid(row=row, column=0, sticky="w", padx=5, pady=4)
            ttk.Entry(frm, textvariable=var, width=width).grid(row=row, column=1, sticky="w", padx=5, pady=4)
            row += 1

        bilgi = ttk.Label(parent, text=(
            "Bu bilgiler raporun kapaginda kullanilir. Beyanname yuklendiginde otomatik\n"
            "olarak doldurulur. Manuel duzeltebilirsiniz."
        ), justify="left", foreground="gray30")
        bilgi.pack(anchor="w", padx=15, pady=5)

    def _build_kur_tab(self, parent):
        frm = ttk.LabelFrame(parent, text="Yil Sonu Doviz Kurlari (VUK Genel Tebligi)")
        frm.pack(fill="both", expand=True, padx=10, pady=10)
        row = 0
        for label, var, width in [
            ("Teblig Tarihi (gg.aa.yyyy)", self.kur_teblig_tarihi, 20),
            ("Teblig Sira No", self.kur_teblig_no, 10),
            ("USD Doviz Alis Kuru", self.usd_alis, 15),
            ("USD Efektif Alis Kuru", self.usd_efektif, 15),
            ("EUR Doviz Alis Kuru", self.eur_alis, 15),
            ("EUR Efektif Alis Kuru", self.eur_efektif, 15),
            ("GBP Doviz Alis Kuru", self.gbp_alis, 15),
            ("CHF Doviz Alis Kuru", self.chf_alis, 15),
        ]:
            ttk.Label(frm, text=label + ":").grid(row=row, column=0, sticky="w", padx=5, pady=4)
            ttk.Entry(frm, textvariable=var, width=width).grid(row=row, column=1, sticky="w", padx=5, pady=4)
            row += 1
        bilgi = ttk.Label(parent, text=(
            "Bu kurlar metin uretiminde 'Vergi Usul Kanunu Genel Tebligi'nin ekinde yer alan\n"
            "doviz kurlari' ifadesi icin kullanilir. Varsayilan degerler 31.12.2024 icin."
        ), justify="left", foreground="gray30")
        bilgi.pack(anchor="w", padx=15, pady=5)

    def _build_run_tab(self, parent):
        frm = ttk.Frame(parent)
        frm.pack(fill="both", expand=True, padx=10, pady=10)

        ttk.Button(frm, text="RAPORU URET (Word olarak kaydet)", command=self._calistir,
                   style="Accent.TButton").pack(pady=10, fill="x")

        ttk.Label(frm, text="Islem Gunlugu:").pack(anchor="w", pady=(10, 2))
        self.log_text = tk.Text(frm, height=22, wrap="word")
        self.log_text.pack(fill="both", expand=True)
        scrollbar = ttk.Scrollbar(self.log_text, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scrollbar.set)

    # ------------------ EVENT HANDLERS --------------------
    def _sec_mizan(self):
        path = filedialog.askopenfilename(
            title="Mizan/Bilanco Excel dosyasini secin",
            filetypes=[("Excel dosyalari", "*.xlsx *.xlsm"), ("Tum dosyalar", "*.*")],
        )
        if path:
            self.mizan_path.set(path)
            # Cikti klasorunu Excel'in bulundugu yere ayarla
            if not self.output_dir.get() or self.output_dir.get() == str(Path.cwd()):
                self.output_dir.set(str(Path(path).parent))

    def _sec_beyanname(self):
        path = filedialog.askopenfilename(
            title="Kurumlar Vergisi Beyannamesi PDF secin",
            filetypes=[("PDF dosyalari", "*.pdf"), ("Tum dosyalar", "*.*")],
        )
        if path:
            self.beyanname_path.set(path)
            # Mukellef bilgilerini doldur
            try:
                bv = parse_beyanname(path)
                if bv.vergi_no:
                    self.vergi_no.set(bv.vergi_no)
                if bv.unvan:
                    self.unvan.set(bv.unvan)
                if bv.vergi_dairesi:
                    self.vergi_dairesi.set(bv.vergi_dairesi)
                if bv.donem:
                    # 01.01.2024-31.12.2024 formatinda
                    parts = bv.donem.split("-")
                    if len(parts) == 2:
                        self.donem_baslangic.set(parts[0])
                        self.donem_bitis.set(parts[1])
                self._log(f"Beyanname yuklendi: VKN={bv.vergi_no}, Unvan={bv.unvan}")
                self._log(f"  Ticari Bilanco Kari: {bv.ticari_bilanco_kari:,.2f}")
                self._log(f"  KKEG: {bv.kkeg_toplam:,.2f}")
                self._log(f"  Matrah: {bv.matrah:,.2f}")
                self._log(f"  Hesaplanan Vergi: {bv.hesaplanan_vergi:,.2f}")
            except Exception as e:
                self._log(f"Beyanname onizleme hatasi: {e}")

    def _sec_output(self):
        path = filedialog.askdirectory(title="Cikti klasorunu secin")
        if path:
            self.output_dir.set(path)

    def _log(self, msg: str):
        self.log_text.insert("end", msg + "\n")
        self.log_text.see("end")
        self.root.update_idletasks()

    def _to_float(self, s: str) -> float:
        try:
            return float(s.replace(",", "."))
        except Exception:
            return 0.0

    def _calistir(self):
        self.log_text.delete("1.0", "end")
        self._log("=" * 70)
        self._log("RAPOR URETIMI BASLIYOR")
        self._log("=" * 70)

        mizan_p = self.mizan_path.get()
        beyanname_p = self.beyanname_path.get()
        outdir = self.output_dir.get()

        if not mizan_p or not os.path.exists(mizan_p):
            messagebox.showerror("Hata", "Mizan Excel dosyasi secilmedi veya bulunamadi.")
            return
        if not beyanname_p or not os.path.exists(beyanname_p):
            messagebox.showwarning("Uyari", "Beyanname PDF secilmedi - bos beyanname verisiyle devam ediliyor.")

        try:
            self._log(f"[1/6] Mizan okunuyor: {os.path.basename(mizan_p)}")
            mizan = parse_mizan(mizan_p, sheet_name=self.mizan_sheet.get())
            self._log(f"      {len(mizan)} satir okundu.")

            self._log(f"[2/6] Dovizli Mizan okunuyor...")
            dovizli = parse_dovizli_mizan(mizan_p, sheet_name=self.dovizli_mizan_sheet.get())
            self._log(f"      {len(dovizli)} satir okundu.")

            self._log(f"[3/6] Bilanco okunuyor (donem={self.hedef_donem.get()})...")
            try:
                bilanco = parse_bilanco(mizan_p, sheet_name=self.bilanco_sheet.get(),
                                        hedef_donem=self.hedef_donem.get())
                self._log(f"      {len(bilanco)} satir okundu.")
            except Exception as e:
                self._log(f"      UYARI: Bilanco okunamadi: {e}")
                bilanco = []

            self._log(f"[4/6] Gelir Tablosu okunuyor...")
            try:
                gelir = parse_gelir_tablosu(mizan_p, sheet_name=self.gelir_tablosu_sheet.get(),
                                           hedef_donem=self.hedef_donem.get())
                self._log(f"      {len(gelir)} satir okundu.")
            except Exception as e:
                self._log(f"      UYARI: Gelir tablosu okunamadi: {e}")
                gelir = []

            self._log(f"[5/6] Beyanname okunuyor...")
            if beyanname_p and os.path.exists(beyanname_p):
                from engine.data_model import BeyannameVerisi
                beyanname = parse_beyanname(beyanname_p)
                self._log(f"      Ticari Kar: {beyanname.ticari_bilanco_kari:,.2f}, Matrah: {beyanname.matrah:,.2f}")
            else:
                from engine.data_model import BeyannameVerisi
                beyanname = BeyannameVerisi()

            mukellef = MukellefBilgileri(
                vergi_no=self.vergi_no.get(),
                unvan=self.unvan.get(),
                vergi_dairesi=self.vergi_dairesi.get(),
                donem_baslangic=self.donem_baslangic.get(),
                donem_bitis=self.donem_bitis.get(),
                rapor_no=self.rapor_no.get(),
                ymm_adi=self.ymm_adi.get(),
            )

            kurlar = KurTablosu(
                teblig_tarihi=self.kur_teblig_tarihi.get(),
                teblig_no=self.kur_teblig_no.get(),
                usd_alis=self._to_float(self.usd_alis.get()),
                usd_efektif_alis=self._to_float(self.usd_efektif.get()),
                eur_alis=self._to_float(self.eur_alis.get()),
                eur_efektif_alis=self._to_float(self.eur_efektif.get()),
                gbp_alis=self._to_float(self.gbp_alis.get()),
                chf_alis=self._to_float(self.chf_alis.get()),
            )

            rapor = RaporVerisi(
                mukellef=mukellef,
                mizan=mizan,
                dovizli_mizan=dovizli,
                bilanco=bilanco,
                gelir_tablosu=gelir,
                beyanname=beyanname,
                kurlar=kurlar,
            )

            self._log("[6/6] Mutabakat kontrolleri calisiyor...")
            bulgular = kontrolleri_calistir(rapor)
            kritik = sum(1 for b in bulgular if b.onem == "kritik")
            uyari = sum(1 for b in bulgular if b.onem == "uyari")
            self._log(f"      {len(bulgular)} bulgu: {kritik} kritik, {uyari} uyari.")

            self._log("Bloklar uretiliyor...")
            bloklar = hesap_incelemeleri_uret(rapor)
            self._log(f"      {len(bloklar)} blok uretildi.")

            # Cikti dosya adi
            tarih_str = datetime.now().strftime("%Y%m%d_%H%M%S")
            unvan_kisa = (mukellef.unvan or "RAPOR").replace(" ", "_")[:40]
            out_filename = f"TT_Hesap_Incelemeleri_{unvan_kisa}_{tarih_str}.docx"
            out_path = os.path.join(outdir, out_filename)

            self._log(f"Word dosyasi yaziliyor: {out_filename}")
            yaz_word_raporu(rapor, bloklar, out_path)
            self._log("=" * 70)
            self._log(f"BASARILI! Cikti: {out_path}")
            self._log("=" * 70)

            if messagebox.askyesno("Tamamlandi", f"Rapor uretildi:\n{out_path}\n\nKlasoru acmak ister misiniz?"):
                os.startfile(outdir)

        except Exception as e:
            import traceback
            tb = traceback.format_exc()
            self._log(f"HATA: {e}")
            self._log(tb)
            messagebox.showerror("Hata", f"Rapor uretiminde hata olustu:\n{e}")


def main():
    root = tk.Tk()
    # Stil
    try:
        style = ttk.Style()
        style.theme_use("vista" if "vista" in style.theme_names() else "clam")
        style.configure("Accent.TButton", font=("Segoe UI", 11, "bold"), foreground="#FFFFFF", background="#0078D4")
    except Exception:
        pass
    app = TTHesapIncelemeleriApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
