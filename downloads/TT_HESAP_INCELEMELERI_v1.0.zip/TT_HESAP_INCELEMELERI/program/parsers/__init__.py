"""Parser modulleri - Excel ve PDF dosyalarini ayristirir."""
