"""Kurumlar Vergisi Beyannamesi PDF parser."""
import re
import pdfplumber

from engine.data_model import BeyannameVerisi, BilancoKalemi, GelirTablosuKalemi


_NUM_RE = re.compile(r"(-?\d{1,3}(?:\.\d{3})+(?:,\d+)?|-?\d+(?:,\d+)?)\s*$")


def _parse_amount(s: str) -> float:
    """1.234.567,89 -> 1234567.89, parantez negatifleri de destekler."""
    s = s.strip()
    neg = False
    if s.startswith("(") and s.endswith(")"):
        neg = True
        s = s[1:-1]
    if s.startswith("-"):
        neg = True
        s = s[1:]
    s = s.replace(".", "").replace(",", ".")
    try:
        v = float(s)
        return -v if neg else v
    except ValueError:
        return 0.0


def _extract_amount_from_line(line: str, label_pattern: str) -> float | None:
    """Bir satirda label'in sonundaki sayisal degeri yakala."""
    m = re.search(label_pattern + r".*?(-?\d[\d\.]*(?:,\d+)?)\s*$", line, re.IGNORECASE)
    if m:
        return _parse_amount(m.group(1))
    return None


def parse_beyanname(pdf_path: str) -> BeyannameVerisi:
    bv = BeyannameVerisi()
    with pdfplumber.open(pdf_path) as pdf:
        all_text = []
        for page in pdf.pages:
            t = page.extract_text() or ""
            all_text.append(t)
        text = "\n".join(all_text)

    lines = [ln.rstrip() for ln in text.split("\n")]

    # Mukellef bilgileri
    for i, ln in enumerate(lines):
        m = re.search(r"Vergi Kimlik Numarasi\s*(\d{10})", ln) or re.search(r"Vergi Kimlik Numarası\s*(\d{10})", ln)
        if m and not bv.vergi_no:
            bv.vergi_no = m.group(1)
        m = re.search(r"Soyadı \(Unvanı\)\s*(.+)", ln)
        if m and not bv.unvan:
            bv.unvan = m.group(1).strip()
            # Adı (Unvanın Devamı) bir sonraki satirda olabilir
            if i + 1 < len(lines):
                m2 = re.search(r"Adı \(Unvanın Devamı\)\s*(.+)", lines[i + 1])
                if m2:
                    devam = m2.group(1).strip()
                    if devam and devam.lower() not in bv.unvan.lower():
                        bv.unvan = bv.unvan + " " + devam

    # Donem ve VD basligi
    for ln in lines:
        m = re.search(r"DÖNEM TİPİ\s+Yıl\s+(\d{4})", ln)
        if m:
            yil = m.group(1)
            bv.donem = f"01.01.{yil}-31.12.{yil}"
        # "ANKARA KURUMLAR DÖNEM TİPİ Yıl 2024" -> "ANKARA KURUMLAR"
        m = re.search(r"^([A-ZÇĞIİÖŞÜ][A-ZÇĞIİÖŞÜ\s]+?)\s+DÖNEM TİPİ", ln)
        if m and not bv.vergi_dairesi:
            bv.vergi_dairesi = m.group(1).strip()

    # Tutar etiketleri - tek satirlik desenler
    label_patterns = {
        "ticari_bilanco_kari": r"Ticari Bilan(?:ç|c)o Karı",
        "ticari_bilanco_zarari": r"Ticari Bilan(?:ç|c)o Zararı",
        "kkeg_toplam": r"Kanunen Kabul Edilmeyen Giderler",
        "matrah": r"Kurumlar Vergisi Matrah",
        "hesaplanan_vergi": r"Hesaplanan Kurumlar Vergisi",
        "yil_ici_kesinti": r"Yıl İçinde Kesinti Yoluyla Ödenen Vergiler",
        "odenen_gecici_vergi": r"Ödenen Geçici Vergi",
        "zarar_olsa_dahi_indirim_toplam": r"Cari Yıla Ait Zarar, İstisna ve İndirimler Toplam",
    }

    for ln in lines:
        for field, pat in label_patterns.items():
            if re.search(pat, ln, re.IGNORECASE):
                # son sayisal degeri al
                nums = re.findall(r"-?\d{1,3}(?:\.\d{3})*(?:,\d+)?", ln)
                if nums:
                    val = _parse_amount(nums[-1])
                    cur = getattr(bv, field)
                    if abs(cur) < 0.005:
                        setattr(bv, field, val)

    # Bilanco ve gelir tablosu — beyanname icindeki PDF tablolari
    bv.bilanco_satirlari = _parse_bilanco_table_from_pdf(lines)
    bv.gelir_tablosu_satirlari = _parse_gelir_tablosu_table_from_pdf(lines)

    return bv


def _parse_bilanco_table_from_pdf(lines: list[str]) -> list:
    """Beyanname PDF'inde 'TEK DÜZEN HESAP PLANI AYRINTILI BİLANÇO' bolumunu ayristir."""
    kalemler = []
    in_section = False
    in_aktif = False
    in_pasif = False
    for ln in lines:
        s = ln.strip()
        if "AYRINTILI BİLANÇO" in s.upper():
            in_section = True
            continue
        if "AYRINTILI GELİR TABLOSU" in s.upper() or "GELİR TABLOSU" in s.upper() and "AYRINTILI" in s.upper():
            in_section = False
            in_aktif = False
            in_pasif = False
        if not in_section:
            continue
        if s.startswith("AKTİF") or s == "AKTİF":
            in_aktif = True
            in_pasif = False
            continue
        if s.startswith("PASİF"):
            in_aktif = False
            in_pasif = True
            continue
        if not (in_aktif or in_pasif):
            continue
        # son 2 sayisal degeri al
        nums = re.findall(r"-?\d{1,3}(?:\.\d{3})*(?:,\d+)?", s)
        if len(nums) >= 2:
            try:
                cari = _parse_amount(nums[-1])
                onceki = _parse_amount(nums[-2])
            except Exception:
                continue
            # Aciklama: sondan iki sayinin oncesinde
            label = s
            for n in nums[-2:]:
                idx = label.rfind(n)
                if idx > 0:
                    label = label[:idx].strip()
            # hesap kodu (varsa) - genel beyanname formati bunlari icermez
            kalemler.append(BilancoKalemi(
                hesap_kodu="",
                aciklama=label,
                onceki_donem=onceki,
                cari_donem=cari,
                seviye=0,
            ))
    return kalemler


def _parse_gelir_tablosu_table_from_pdf(lines: list[str]) -> list:
    """Beyanname PDF'inde gelir tablosu kalemlerini ayristir."""
    kalemler = []
    in_section = False
    for ln in lines:
        s = ln.strip()
        if "AYRINTILI GELİR TABLOSU" in s.upper():
            in_section = True
            continue
        if "EK BİLGİLER" in s.upper() or "DİPNOT" in s.upper():
            in_section = False
        if not in_section:
            continue
        nums = re.findall(r"-?\d{1,3}(?:\.\d{3})*(?:,\d+)?", s)
        if len(nums) >= 2:
            try:
                cari = _parse_amount(nums[-1])
                onceki = _parse_amount(nums[-2])
            except Exception:
                continue
            label = s
            for n in nums[-2:]:
                idx = label.rfind(n)
                if idx > 0:
                    label = label[:idx].strip()
            kalemler.append(GelirTablosuKalemi(
                hesap_kodu="",
                aciklama=label,
                onceki_donem=onceki,
                cari_donem=cari,
                seviye=0,
            ))
    return kalemler
