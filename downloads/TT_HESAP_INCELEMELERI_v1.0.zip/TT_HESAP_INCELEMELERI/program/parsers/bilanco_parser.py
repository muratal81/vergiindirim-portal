"""Bilanco ve Gelir Tablosu Excel parser."""
import openpyxl
from datetime import datetime

from engine.data_model import BilancoKalemi, GelirTablosuKalemi


def _to_float(v) -> float:
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace("\xa0", "").replace(" ", "")
    if not s:
        return 0.0
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        s = s.replace(".", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return 0.0


def _find_donem_columns(ws, max_scan: int = 5, hedef_donem: str = "31.12.2024") -> tuple[int, int, int]:
    """Bilanço/Gelir tablosunda donem kolonlarini bul.
    Returns: (header_row, onceki_donem_col, cari_donem_col) — 0-based.
    """
    cari_dt = datetime.strptime(hedef_donem, "%d.%m.%Y").date()
    onceki_dt = cari_dt.replace(year=cari_dt.year - 1)
    onceki_col = -1
    cari_col = -1
    header_row = -1

    for ri in range(max_scan):
        row = [ws.cell(row=ri + 1, column=ci + 1).value for ci in range(25)]
        for ci, v in enumerate(row):
            if isinstance(v, datetime):
                if v.date() == cari_dt:
                    if cari_col == -1:  # ilk eslesmeyi al
                        cari_col = ci
                        header_row = ri
                if v.date() == onceki_dt:
                    if onceki_col == -1:
                        onceki_col = ci
            elif isinstance(v, str):
                # 2024-12-31 veya 31.12.2024 metinleri
                s = v.strip()
                if s.startswith(hedef_donem) or s == hedef_donem or s.startswith(f"{cari_dt.year}-{cari_dt.month:02d}-{cari_dt.day:02d}"):
                    if cari_col == -1:
                        cari_col = ci
                        header_row = ri
                if s.startswith(f"{onceki_dt.year}-{onceki_dt.month:02d}-{onceki_dt.day:02d}"):
                    if onceki_col == -1:
                        onceki_col = ci
        if cari_col != -1:
            break

    if cari_col == -1:
        raise ValueError(f"Bilanco/Gelir tablosunda {hedef_donem} kolonu bulunamadi.")
    return header_row, onceki_col, cari_col


def parse_bilanco(xlsx_path: str, sheet_name: str = "Bilanço", hedef_donem: str = "31.12.2024") -> list:
    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    if sheet_name not in wb.sheetnames:
        wb.close()
        return []
    ws = wb[sheet_name]
    header_row, onceki_col, cari_col = _find_donem_columns(ws, hedef_donem=hedef_donem)
    # Aciklama kolonu (genelde 1) -> "AKTİFLER (VARLIKLAR)" baslikli kolon
    aciklama_col = 1
    hesap_kodu_col = 0
    # Header satirinda "Açıklama" veya "AKTİFLER" bulunan kolonu sec
    hdr = [ws.cell(row=header_row + 1, column=ci + 1).value for ci in range(15)]
    for ci, v in enumerate(hdr):
        if v and isinstance(v, str):
            s = v.upper()
            if "AKTİF" in s or "VARLIKLAR" in s or "AÇIKLAMA" in s:
                aciklama_col = ci
                hesap_kodu_col = max(0, ci - 1)
                break

    kalemler = []
    for ri, row in enumerate(ws.iter_rows(min_row=header_row + 2, values_only=True)):
        if not row:
            continue
        if aciklama_col >= len(row):
            continue
        aciklama_raw = row[aciklama_col]
        if not aciklama_raw:
            continue
        aciklama_str = str(aciklama_raw).strip()
        if not aciklama_str:
            continue

        hesap_kodu_raw = row[hesap_kodu_col] if hesap_kodu_col < len(row) else None
        hesap_kodu = str(hesap_kodu_raw).strip() if hesap_kodu_raw else ""

        # Seviye tespiti (kac bosluk ile basliyor)
        leading_spaces = len(aciklama_raw) - len(aciklama_raw.lstrip()) if isinstance(aciklama_raw, str) else 0
        if leading_spaces == 0:
            seviye = 0
        elif leading_spaces <= 2:
            seviye = 1
        else:
            seviye = 2

        onceki = _to_float(row[onceki_col]) if onceki_col < len(row) else 0.0
        cari = _to_float(row[cari_col]) if cari_col < len(row) else 0.0

        # Bos kalemleri at - hem onceki hem cari sifir, hem de hesap kodu yok ve aciklama buyuk harfli baslik degil
        if abs(onceki) < 0.005 and abs(cari) < 0.005 and not hesap_kodu:
            # Yine de baslik olabilir, eklemiyoruz tablo icin (sadece veri var olanlari)
            continue

        kalemler.append(BilancoKalemi(
            hesap_kodu=hesap_kodu,
            aciklama=aciklama_str,
            onceki_donem=onceki,
            cari_donem=cari,
            seviye=seviye,
        ))
    wb.close()
    return kalemler


def parse_gelir_tablosu(xlsx_path: str, sheet_name: str = "Gelir Tablosu", hedef_donem: str = "31.12.2024") -> list:
    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    if sheet_name not in wb.sheetnames:
        wb.close()
        return []
    ws = wb[sheet_name]
    header_row, onceki_col, cari_col = _find_donem_columns(ws, hedef_donem=hedef_donem)

    aciklama_col = 1
    hesap_kodu_col = 0
    hdr = [ws.cell(row=header_row + 1, column=ci + 1).value for ci in range(15)]
    for ci, v in enumerate(hdr):
        if v and isinstance(v, str):
            s = v.upper()
            if "AÇIKLAMA" in s or "BRÜT" in s:
                aciklama_col = ci
                hesap_kodu_col = max(0, ci - 1)
                break

    kalemler = []
    for ri, row in enumerate(ws.iter_rows(min_row=header_row + 2, values_only=True)):
        if not row or aciklama_col >= len(row):
            continue
        aciklama_raw = row[aciklama_col]
        if not aciklama_raw:
            continue
        aciklama_str = str(aciklama_raw).strip()
        if not aciklama_str:
            continue
        hesap_kodu_raw = row[hesap_kodu_col] if hesap_kodu_col < len(row) else None
        hesap_kodu = str(hesap_kodu_raw).strip() if hesap_kodu_raw else ""

        leading_spaces = len(aciklama_raw) - len(aciklama_raw.lstrip()) if isinstance(aciklama_raw, str) else 0
        if leading_spaces == 0:
            seviye = 0
        elif leading_spaces <= 2:
            seviye = 1
        else:
            seviye = 2

        onceki = _to_float(row[onceki_col]) if onceki_col < len(row) else 0.0
        cari = _to_float(row[cari_col]) if cari_col < len(row) else 0.0
        if abs(onceki) < 0.005 and abs(cari) < 0.005 and not hesap_kodu:
            continue

        kalemler.append(GelirTablosuKalemi(
            hesap_kodu=hesap_kodu,
            aciklama=aciklama_str,
            onceki_donem=onceki,
            cari_donem=cari,
            seviye=seviye,
        ))
    wb.close()
    return kalemler
