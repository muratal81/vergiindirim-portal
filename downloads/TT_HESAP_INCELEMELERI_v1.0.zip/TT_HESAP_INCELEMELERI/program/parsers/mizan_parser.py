"""Mizan ve Dovizli Mizan Excel parser modulleri."""
import openpyxl
from typing import Optional

from engine.data_model import MizanSatiri, DovizliMizanSatiri


def _to_float(v) -> float:
    """Excel hucresini float'a cevir."""
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace("\xa0", "").replace(" ", "")
    if not s:
        return 0.0
    # Turkce: 1.234.567,89  / Ingilizce: 1,234,567.89
    if "," in s and "." in s:
        # son hangisi geliyor onu ondalik ayrac kabul et
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        # Ondalik ayrac
        s = s.replace(".", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return 0.0


def _detect_header_row(ws, max_scan: int = 20) -> tuple[int, dict]:
    """Mizan sayfasinin baslik satirini bul, kolon eslestir.

    Returns: (header_row_index_0_based, {alan: kolon_index_0_based})
    """
    needed = {
        "hesap_kodu": ["hesap no", "hesap kodu", "hesap kod", "kod", "tam hesap"],
        "hesap_adi": ["hesap adi", "hesap adı", "hesap ismi", "ad"],
        "borc_toplam": ["toplam borc", "toplam borç", "borç toplam"],
        "alacak_toplam": ["toplam alacak", "alacak toplam", "toplam alac"],
        "borc_bakiye": ["bakiye borc", "bakiye borç", "borç bakiye"],
        "alacak_bakiye": ["bakiye alacak", "alacak bakiye", "bakiye alac"],
        "para_birimi": ["para br", "para bri", "doviz", "döviz", "f. p. br", "p.br"],
    }
    for ri in range(max_scan):
        row = [ws.cell(row=ri + 1, column=ci + 1).value for ci in range(20)]
        row_str = [str(v).lower().strip() if v is not None else "" for v in row]
        mapping = {}
        for field, keywords in needed.items():
            for ci, cell in enumerate(row_str):
                if any(kw in cell for kw in keywords):
                    if field not in mapping:
                        mapping[field] = ci
        # En az hesap_kodu, hesap_adi, borc_bakiye, alacak_bakiye olmali
        if {"hesap_kodu", "hesap_adi", "borc_bakiye", "alacak_bakiye"}.issubset(mapping.keys()):
            return ri, mapping
    raise ValueError("Mizan sayfasinda baslik satiri bulunamadi.")


def parse_mizan(xlsx_path: str, sheet_name: str = "Mizan") -> list:
    """Mizan sayfasini oku, MizanSatiri listesi dondur."""
    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    if sheet_name not in wb.sheetnames:
        raise ValueError(f"Sayfa bulunamadi: {sheet_name}")
    ws = wb[sheet_name]
    header_row, mapping = _detect_header_row(ws)
    satirlar = []
    # Tam (1-based) header_row+2 -> data baslangici
    for ri, row in enumerate(ws.iter_rows(min_row=header_row + 2, values_only=True)):
        if not row:
            continue
        hesap_kodu_raw = row[mapping["hesap_kodu"]] if mapping["hesap_kodu"] < len(row) else None
        if hesap_kodu_raw is None:
            continue
        hesap_kodu = str(hesap_kodu_raw).strip()
        if not hesap_kodu or hesap_kodu.lower() in ("nan", "none"):
            continue
        # Numerik mi? En az ilk karakter rakam olmali (TDHP)
        if not hesap_kodu[0].isdigit():
            continue
        hesap_adi = str(row[mapping["hesap_adi"]]).strip() if mapping["hesap_adi"] < len(row) and row[mapping["hesap_adi"]] else ""
        # Bos seviye girintilerini temizle
        hesap_adi = " ".join(hesap_adi.split())

        satir = MizanSatiri(
            hesap_kodu=hesap_kodu,
            hesap_adi=hesap_adi,
            borc_toplam=_to_float(row[mapping["borc_toplam"]]) if "borc_toplam" in mapping and mapping["borc_toplam"] < len(row) else 0.0,
            alacak_toplam=_to_float(row[mapping["alacak_toplam"]]) if "alacak_toplam" in mapping and mapping["alacak_toplam"] < len(row) else 0.0,
            borc_bakiye=_to_float(row[mapping["borc_bakiye"]]) if mapping["borc_bakiye"] < len(row) else 0.0,
            alacak_bakiye=_to_float(row[mapping["alacak_bakiye"]]) if mapping["alacak_bakiye"] < len(row) else 0.0,
            para_birimi=str(row[mapping["para_birimi"]]).strip() if "para_birimi" in mapping and mapping["para_birimi"] < len(row) and row[mapping["para_birimi"]] else "TL",
        )
        satirlar.append(satir)
    wb.close()
    return satirlar


def parse_dovizli_mizan(xlsx_path: str, sheet_name: str = "Dövizli Mizan") -> list:
    """Dovizli mizan sayfasini oku."""
    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    if sheet_name not in wb.sheetnames:
        wb.close()
        return []
    ws = wb[sheet_name]
    # Header'i bul - "Top.Borç (R.P)", "Bak.Borç (R.P)" gibi sutunlar var
    header_row = None
    mapping = {}
    for ri in range(15):
        row = [ws.cell(row=ri + 1, column=ci + 1).value for ci in range(20)]
        row_str = [str(v).lower().strip() if v is not None else "" for v in row]
        m = {}
        for ci, cell in enumerate(row_str):
            if "hesap no" in cell or "hesap kod" in cell:
                m.setdefault("hesap_kodu", ci)
            elif "hesap ad" in cell:
                m.setdefault("hesap_adi", ci)
            elif cell.startswith("r.pbr") or "doviz cinsi" in cell or "döviz cinsi" in cell or cell.startswith("r. p. br"):
                m.setdefault("doviz_cinsi", ci)
            elif "top.borç (r.p)" in cell or "top.borc (r.p)" in cell:
                m.setdefault("dov_borc_top", ci)
            elif "top.alac.(r.p)" in cell or "top.alac.(r.p)" in cell or "top.alac. (r.p)" in cell:
                m.setdefault("dov_alac_top", ci)
            elif "bak.borç (r.p)" in cell or "bak.borc (r.p)" in cell:
                m.setdefault("dov_borc_bak", ci)
            elif "bak.alac.(r.p)" in cell or "bak.alac. (r.p)" in cell:
                m.setdefault("dov_alac_bak", ci)
            elif cell == "toplam borç" or cell == "toplam borc":
                m.setdefault("tl_borc_top", ci)
            elif cell == "toplam alac." or cell == "toplam alacak":
                m.setdefault("tl_alac_top", ci)
            elif cell == "bakiye borç" or cell == "bakiye borc":
                m.setdefault("tl_borc_bak", ci)
            elif cell == "bakiye alac." or cell == "bakiye alacak":
                m.setdefault("tl_alac_bak", ci)
        if {"hesap_kodu", "tl_borc_bak", "tl_alac_bak"}.issubset(m.keys()):
            header_row = ri
            mapping = m
            break

    if header_row is None:
        wb.close()
        return []

    satirlar = []
    for ri, row in enumerate(ws.iter_rows(min_row=header_row + 2, values_only=True)):
        if not row:
            continue
        hk_raw = row[mapping["hesap_kodu"]] if mapping["hesap_kodu"] < len(row) else None
        if hk_raw is None:
            continue
        hesap_kodu = str(hk_raw).strip()
        if not hesap_kodu or not hesap_kodu[0].isdigit():
            continue
        hesap_adi = ""
        if "hesap_adi" in mapping and mapping["hesap_adi"] < len(row) and row[mapping["hesap_adi"]]:
            hesap_adi = " ".join(str(row[mapping["hesap_adi"]]).split())
        doviz_cinsi = ""
        if "doviz_cinsi" in mapping and mapping["doviz_cinsi"] < len(row) and row[mapping["doviz_cinsi"]]:
            doviz_cinsi = str(row[mapping["doviz_cinsi"]]).strip().upper()

        satir = DovizliMizanSatiri(
            hesap_kodu=hesap_kodu,
            hesap_adi=hesap_adi,
            doviz_cinsi=doviz_cinsi,
            doviz_borc_toplam=_to_float(row[mapping["dov_borc_top"]]) if "dov_borc_top" in mapping and mapping["dov_borc_top"] < len(row) else 0.0,
            doviz_alacak_toplam=_to_float(row[mapping["dov_alac_top"]]) if "dov_alac_top" in mapping and mapping["dov_alac_top"] < len(row) else 0.0,
            doviz_borc_bakiye=_to_float(row[mapping["dov_borc_bak"]]) if "dov_borc_bak" in mapping and mapping["dov_borc_bak"] < len(row) else 0.0,
            doviz_alacak_bakiye=_to_float(row[mapping["dov_alac_bak"]]) if "dov_alac_bak" in mapping and mapping["dov_alac_bak"] < len(row) else 0.0,
            tl_borc_toplam=_to_float(row[mapping["tl_borc_top"]]) if "tl_borc_top" in mapping and mapping["tl_borc_top"] < len(row) else 0.0,
            tl_alacak_toplam=_to_float(row[mapping["tl_alac_top"]]) if "tl_alac_top" in mapping and mapping["tl_alac_top"] < len(row) else 0.0,
            tl_borc_bakiye=_to_float(row[mapping["tl_borc_bak"]]) if mapping["tl_borc_bak"] < len(row) else 0.0,
            tl_alacak_bakiye=_to_float(row[mapping["tl_alac_bak"]]) if mapping["tl_alac_bak"] < len(row) else 0.0,
        )
        satirlar.append(satir)
    wb.close()
    return satirlar
