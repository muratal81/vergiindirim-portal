"""Veri modelleri."""
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class MizanSatiri:
    """Tek bir mizan satirini temsil eder."""
    hesap_kodu: str
    hesap_adi: str
    borc_toplam: float = 0.0
    alacak_toplam: float = 0.0
    borc_bakiye: float = 0.0
    alacak_bakiye: float = 0.0
    para_birimi: str = "TL"

    @property
    def net_bakiye(self) -> float:
        """Net bakiye (borc - alacak). Borc bakiye pozitif, alacak bakiye negatif."""
        return self.borc_bakiye - self.alacak_bakiye

    @property
    def bakiye_mutlak(self) -> float:
        """Mutlak bakiye degeri (TL)."""
        return abs(self.borc_bakiye) if self.borc_bakiye else abs(self.alacak_bakiye)

    @property
    def ana_hesap_kodu(self) -> str:
        """100.01.001 -> 100"""
        return self.hesap_kodu.split(".")[0].strip()

    @property
    def alt_seviye(self) -> int:
        """100 = 0, 100.01 = 1, 100.01.001 = 2"""
        return self.hesap_kodu.count(".")


@dataclass
class DovizliMizanSatiri:
    """Dovizli mizan satiri - orijinal doviz tutari ile."""
    hesap_kodu: str
    hesap_adi: str
    doviz_cinsi: str
    doviz_borc_toplam: float = 0.0
    doviz_alacak_toplam: float = 0.0
    doviz_borc_bakiye: float = 0.0
    doviz_alacak_bakiye: float = 0.0
    tl_borc_toplam: float = 0.0
    tl_alacak_toplam: float = 0.0
    tl_borc_bakiye: float = 0.0
    tl_alacak_bakiye: float = 0.0

    @property
    def doviz_bakiye(self) -> float:
        return self.doviz_borc_bakiye - self.doviz_alacak_bakiye

    @property
    def tl_bakiye(self) -> float:
        return self.tl_borc_bakiye - self.tl_alacak_bakiye

    @property
    def kur(self) -> float:
        if self.doviz_bakiye and abs(self.doviz_bakiye) > 0.001:
            return self.tl_bakiye / self.doviz_bakiye
        return 0.0

    @property
    def ana_hesap_kodu(self) -> str:
        return self.hesap_kodu.split(".")[0].strip()


@dataclass
class BilancoKalemi:
    """Bilanco satiri (TDHP standardi)."""
    hesap_kodu: str  # 100, 101, 102 vb. veya bos
    aciklama: str
    onceki_donem: float = 0.0
    cari_donem: float = 0.0
    seviye: int = 0  # 0=baslik, 1=grup, 2=detay


@dataclass
class GelirTablosuKalemi:
    """Gelir tablosu satiri."""
    hesap_kodu: str
    aciklama: str
    onceki_donem: float = 0.0
    cari_donem: float = 0.0
    seviye: int = 0


@dataclass
class BeyannameVerisi:
    """Kurumlar vergisi beyannamesi - onemli alanlar."""
    vergi_no: str = ""
    unvan: str = ""
    donem: str = ""
    vergi_dairesi: str = ""

    # Ana matrah/vergi bilgileri
    ticari_bilanco_kari: float = 0.0
    ticari_bilanco_zarari: float = 0.0
    kkeg_toplam: float = 0.0
    zarar_olsa_dahi_indirim_toplam: float = 0.0
    matrah: float = 0.0
    hesaplanan_vergi: float = 0.0
    yil_ici_kesinti: float = 0.0
    odenen_gecici_vergi: float = 0.0

    # Bilanco satirlari (PDF'den okunan)
    bilanco_satirlari: list = field(default_factory=list)  # list[BilancoKalemi]
    gelir_tablosu_satirlari: list = field(default_factory=list)

    # Istisna/indirimler (tur, tutar)
    istisnalar: list = field(default_factory=list)  # list[tuple[str, float]]


@dataclass
class MukellefBilgileri:
    """Rapor kapagi icin mukellef ve donem bilgileri."""
    vergi_no: str = ""
    unvan: str = ""
    vergi_dairesi: str = ""
    donem_baslangic: str = "01.01.2024"
    donem_bitis: str = "31.12.2024"
    rapor_no: str = ""
    ymm_adi: str = ""
    ymm_oda_sicil: str = ""

    @property
    def donem(self) -> str:
        return f"{self.donem_baslangic}-{self.donem_bitis}"

    @property
    def donem_sonu(self) -> str:
        return self.donem_bitis


@dataclass
class KurTablosu:
    """580 No.lu VUK GT - 28.01.2025 doviz kurlari."""
    teblig_tarihi: str = "28.01.2025"
    teblig_no: str = "580"
    # Yil sonu 31.12.2024 kurlari
    usd_alis: float = 35.2233
    usd_efektif_alis: float = 35.1987
    eur_alis: float = 36.7429
    eur_efektif_alis: float = 36.7172
    gbp_alis: float = 44.2458
    chf_alis: float = 38.9510


@dataclass
class ValidationFinding:
    """Mutabakat bulgusu."""
    kod: str
    aciklama: str
    onem: str  # 'kritik', 'uyari', 'bilgi'
    mizan_tutar: float = 0.0
    beyanname_tutar: float = 0.0
    fark: float = 0.0


@dataclass
class RaporVerisi:
    """Tum raporun kullanacagi konsolide veri."""
    mukellef: MukellefBilgileri
    mizan: list  # list[MizanSatiri]
    dovizli_mizan: list  # list[DovizliMizanSatiri]
    bilanco: list  # list[BilancoKalemi]
    gelir_tablosu: list  # list[GelirTablosuKalemi]
    beyanname: BeyannameVerisi
    kurlar: KurTablosu
    bulgular: list = field(default_factory=list)  # list[ValidationFinding]

    def hesap_bakiye(self, hesap_kodu_prefix: str) -> float:
        """Bir hesap koduyla baslayan TUM alt hesaplarin TL bakiyeleri toplami (sadece ana hesap satirini al)."""
        # Ana hesap satirini bul (3 haneli)
        target = hesap_kodu_prefix.strip()
        for satir in self.mizan:
            if satir.hesap_kodu.strip() == target:
                return satir.net_bakiye
        # Bulunamazsa toplam alt hesaplardan hesapla
        # Ama bu sefer SADECE en alt seviye satirlari ele al (cifte sayma olmasin)
        toplam = 0.0
        for satir in self.mizan:
            if satir.hesap_kodu.startswith(target + ".") or satir.hesap_kodu == target:
                # Sadece en derin seviyeyi al
                pass
        # Default: ana hesap kodu eslesen ilk satiri al
        for satir in self.mizan:
            if satir.ana_hesap_kodu == target:
                return satir.net_bakiye
        return 0.0

    @staticmethod
    def _kod_eslesir(hesap_kodu: str, target: str) -> bool:
        """100 prefix'i 10000xxx kodlu hesaplari degil sadece 100, 100.01.001 gibi noktaii baslayanlari yakalamali."""
        hk = hesap_kodu.strip()
        return hk == target or hk.startswith(target + ".")

    def dovizli_bakiye_toplami(self, hesap_kodu_prefix: str) -> float:
        """Bir hesap grubunun dovizli alt hesaplarinin TL bakiye toplami."""
        toplam = 0.0
        target = hesap_kodu_prefix.strip()
        for satir in self.dovizli_mizan:
            if satir.doviz_cinsi and satir.doviz_cinsi.upper() not in ("TL", "TRY", ""):
                if self._kod_eslesir(satir.hesap_kodu, target):
                    toplam += satir.tl_bakiye
        return toplam

    def dovizli_detay(self, hesap_kodu_prefix: str) -> dict:
        """Hesap grubunun dovizli detayi: {doviz_cinsi: (toplam_doviz, ortalama_kur, toplam_tl)}"""
        target = hesap_kodu_prefix.strip()
        detay = {}  # doviz_cinsi -> [doviz, tl]
        for satir in self.dovizli_mizan:
            if not satir.doviz_cinsi or satir.doviz_cinsi.upper() in ("TL", "TRY", ""):
                continue
            if not self._kod_eslesir(satir.hesap_kodu, target):
                continue
            dc = satir.doviz_cinsi.upper()
            if dc not in detay:
                detay[dc] = [0.0, 0.0]
            detay[dc][0] += satir.doviz_bakiye
            detay[dc][1] += satir.tl_bakiye
        # Kur hesapla
        sonuc = {}
        for dc, (doviz, tl) in detay.items():
            kur = tl / doviz if abs(doviz) > 0.001 else 0.0
            sonuc[dc] = (doviz, kur, tl)
        return sonuc
