"""Tam tasdik raporu metin uretim motoru.

Bu modul, RaporVerisi'nden hareketle 'III- Hesap Incelemeleri' bolumune
ait paragraf ve tablolari uretir. Cikti olarak bir 'BlokListesi' dondurur;
docx_writer modulu bu listeyi dogrudan Word dosyasina yazar.

Blok tipleri:
  - {"tip": "h1", "metin": ...}   -> Buyuk baslik
  - {"tip": "h2", "metin": ...}   -> Orta baslik (A. BILANCO HESAPLARI)
  - {"tip": "h3", "metin": ...}   -> Alt baslik (1.1. Kasa)
  - {"tip": "p",  "metin": ...}   -> Paragraf
  - {"tip": "doviz_tablo", "satirlar": [...], "toplam_tl": ...}
  - {"tip": "tablo", "basliklar": [...], "satirlar": [...], "toplam": (...)}
  - {"tip": "sari_uyari", "metin": ...}  -> Sari arka planli uyari blogu
"""
from engine.data_model import RaporVerisi
from engine.formatlar import tutar, tutar_sade, doviz_format, kur_format


def hesap_bakiye_tam(rapor: RaporVerisi, hesap_kodu: str) -> float:
    """Ana hesap kodunun net bakiyesi (mizan ana satiri)."""
    target = hesap_kodu.strip()
    for s in rapor.mizan:
        if s.hesap_kodu.strip() == target:
            return s.net_bakiye
    return 0.0


def bilanco_satir_bul(rapor: RaporVerisi, anahtarlar: list[str]) -> float:
    """Bilanco kalemlerinden anahtar kelimeyi iceren cari donem tutarini bul."""
    for k in rapor.bilanco:
        for ah in anahtarlar:
            if ah.lower() in k.aciklama.lower():
                return k.cari_donem
    return 0.0


def gelir_tablo_satir_bul(rapor: RaporVerisi, anahtarlar: list[str]) -> float:
    for k in rapor.gelir_tablosu:
        for ah in anahtarlar:
            if ah.lower() in k.aciklama.lower():
                return k.cari_donem
    return 0.0


# ============================================================
# YABANCI PARA HESAPLARI - Bolum 1
# ============================================================

YABANCI_PARA_HESAPLARI = [
    # (hesap_kodu, baslik, ekstra_aciklama)
    ("100", "Kasa", "efektif"),  # efektif doviz alis
    ("102", "Bankalar", "alis"),  # doviz alis
    ("120", "Alıcılar", "alis"),
    ("159", "Verilen Sipariş Avansları (K.V.)", "alis"),
    ("259", "Verilen Sipariş Avansları (U.V.)", "alis"),
    ("300", "Banka Kredileri (K.V.)", "yatirim"),
    ("301", "Finansal Kiralama İşlemlerinden Borçlar Hesabı (K.V.)", "yatirim_lease"),
    ("302", "Ertelenmiş Finansal Kiralama Borçlanma Maliyeti Hesabı (K.V.)", "yatirim_lease_eksi"),
    ("303", "Uzun Vadeli Kredilerin Anapara Taksitleri", "yatirim"),
    ("309", "Diğer Mali Borçlar Hesabı", "yatirim"),
    ("320", "Satıcılar (K.V.)", "alis"),
    ("340", "Alınan Sipariş Avansları (K.V.)", "alis"),
    ("381", "Gider Tahakkukları (K.V.)", "alis"),
    ("400", "Banka Kredileri (U.V.)", "yatirim"),
    ("401", "Finansal Kiralama İşlemlerinden Borçlar (U.V.)", "yatirim_lease"),
    ("402", "Ertelenmiş Finansal Kiralama Borçlanma Maliyeti Hesabı (U.V.)", "yatirim_lease_eksi"),
]


def _doviz_paragraf_metni(rapor: RaporVerisi, hesap_kodu: str, baslik: str, tip: str) -> str:
    """Yabanci para hesap incelemesi paragrafi olusturur."""
    ana_bakiye = abs(hesap_bakiye_tam(rapor, hesap_kodu))
    dovizli_tl = abs(rapor.dovizli_bakiye_toplami(hesap_kodu))
    donem_sonu = rapor.mukellef.donem_sonu

    if ana_bakiye < 0.005:
        return ""

    kur_aciklama = "döviz kurları"
    if tip == "efektif":
        kur_aciklama = "efektif döviz alış kuru"

    # Yatirim finansmanli kredi grubu icin ek metin
    yatirim_metni = ""
    if tip in ("yatirim", "yatirim_lease"):
        yatirim_metni = (
            "163 seri No.lu VUK ve 187 seri numaralı GVK Genel Tebliği hükümleri kapsamında "
            "Yatırım finansmanında kullanılan kredilerle ilgili faiz ve kur farklarının yatırımın "
            "maliyetine diğerlerinin ise gelir tablosu hesaplarına aktarıldığı tespit edilmiştir."
        )
    elif tip == "yatirim_lease_eksi":
        yatirim_metni = (
            "163 seri No.lu VUK ve 187 seri numaralı GVK Genel Tebliği hükümleri kapsamında "
            "Yatırım finansmanında kullanılan kredilerle ilgili kur farklarının yatırımın "
            "maliyetinden düşüldüğü diğerlerinin ise gelir tablosu hesaplarına aktarıldığı "
            "tespit edilmiştir."
        )
    else:
        yatirim_metni = "oluşan kur farkının gelir tablosu hesaplarına aktarıldığı tespit edilmiştir."

    # Tamami dovizli mi?
    tamami_dovizli = dovizli_tl > 0 and abs(dovizli_tl - ana_bakiye) / max(ana_bakiye, 1) < 0.02

    if tamami_dovizli:
        # "tamamı dövizli ... hesaplarından oluştuğu"
        kisim_metni = f"tamamı dövizli {baslik} hesaplarından oluştuğu"
    else:
        kisim_metni = (
            f"{tutar(dovizli_tl)} tutarındaki kısmının dövizli {baslik} hesaplarından oluştuğu"
        )

    metin = (
        f"{donem_sonu} tarihli kurum bilançosunda {tutar(ana_bakiye)} olarak yer alan "
        f"{baslik} hesabının {kisim_metni}, ilgili hesap bakiyelerinin "
        f"{rapor.kurlar.teblig_tarihi} tarih ve {rapor.kurlar.teblig_no} sıra No.lu Vergi Usul "
        f"Kanunu Genel Tebliği'nin ekinde yer alan {kur_aciklama} ile değerlendiği ve "
        f"{yatirim_metni}"
    )
    return metin


def _doviz_tablo_satirlari(rapor: RaporVerisi, hesap_kodu: str) -> list:
    """Hesap kodu icin doviz cinsi bazinda tablo satirlari uretir."""
    detay = rapor.dovizli_detay(hesap_kodu)
    satirlar = []
    for dc, (doviz, kur, tl) in detay.items():
        if abs(doviz) < 0.005:
            continue
        satirlar.append({
            "doviz_cinsi": dc,
            "doviz_tutari": abs(doviz),
            "kur": abs(kur),
            "bakiye_tl": abs(tl),
        })
    return satirlar


def bilanco_dovizli_bolum_bloklari(rapor: RaporVerisi) -> list:
    """1. Yabanci Para Cinsinden Izlenen Hesaplar — bolum tum bloklari."""
    bloklar = []

    bloklar.append({
        "tip": "h3",
        "metin": "1. Yabancı Para Cinsinden İzlenen Hesaplar:",
    })
    bloklar.append({
        "tip": "p",
        "metin": (
            "Şirketin yabancı para cinsinden izlenen hesapları 213 Sayılı Vergi Usul Kanunu'nun "
            "(VUK) 280'inci maddesinde düzenlenmiştir."
        ),
    })
    bloklar.append({
        "tip": "p",
        "metin": (
            "VUK'un 280'inci maddesinde \"Yabancı paraların borsa rayici ile değerleneceği, Borsa "
            "rayicinin takarrüründe muvazaa olduğu anlaşılırsa bu rayiç yerine alış bedeli esas "
            "alınacağı, Yabancı paranın borsada rayici yoksa, değerlemeye uygulanacak kur Maliye "
            f"Bakanlığınca tespit olunacağı,\" ifade edilmiştir. Bu kapsamda şirketin yabancı para "
            f"cinsinden bulunan hesapları {rapor.kurlar.teblig_tarihi} tarih ve {rapor.kurlar.teblig_no} "
            "sıra No.lu Vergi Usul Kanunu Genel Tebliği'nin ekinde yer alan döviz kurları üzerinden "
            "değerlenmiştir."
        ),
    })

    sira = 0
    for hesap_kodu, baslik, tip in YABANCI_PARA_HESAPLARI:
        dovizli_tl = abs(rapor.dovizli_bakiye_toplami(hesap_kodu))
        ana_bakiye = abs(hesap_bakiye_tam(rapor, hesap_kodu))
        if dovizli_tl < 0.005 or ana_bakiye < 0.005:
            continue
        sira += 1
        bloklar.append({"tip": "h4", "metin": f"1.{sira}. {baslik}:"})
        metin = _doviz_paragraf_metni(rapor, hesap_kodu, baslik, tip)
        if metin:
            bloklar.append({"tip": "p", "metin": metin})
            bloklar.append({"tip": "p", "metin": "Bilanço tarihi itibarıyla bakiye veren dövizli " + baslik + " hesaplarının özet dökümü aşağıdaki gibidir;"})
            satirlar = _doviz_tablo_satirlari(rapor, hesap_kodu)
            if satirlar:
                bloklar.append({"tip": "doviz_tablo", "satirlar": satirlar})

    return bloklar


# ============================================================
# DIGER BILANCO HESAPLARI
# ============================================================

def diger_bilanco_bloklari(rapor: RaporVerisi, sira_baslangic: int = 2) -> list:
    """Yabanci para haricindeki bilanco hesap incelemeleri."""
    bloklar = []
    sira = sira_baslangic
    donem_sonu = rapor.mukellef.donem_sonu

    # 101 - Alinan Cekler
    bakiye = hesap_bakiye_tam(rapor, "101")
    if abs(bakiye) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Alınan Çekler:"})
        bloklar.append({"tip": "p", "metin": f"Şirketin {donem_sonu} tarihi itibariyle Alınan Çekler hesabının bakiyesi {tutar(abs(bakiye))}'dir."})
        sira += 1

    # 103 - Verilen Cekler ve Odeme Emirleri
    bakiye = hesap_bakiye_tam(rapor, "103")
    if abs(bakiye) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Verilen Çekler ve Ödeme Emirleri (-):"})
        bloklar.append({"tip": "p", "metin": f"Şirketin {donem_sonu} tarihi itibariyle Verilen Çekler ve Ödeme Emirleri hesabının bakiyesi ({tutar_sade(abs(bakiye))}-TL) olup tamamı TL cinsinden ve ödemesi sonraki döneme aittir."})
        sira += 1

    # 108 - Diger Hazir Degerler
    bakiye = hesap_bakiye_tam(rapor, "108")
    if abs(bakiye) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Diğer Hazır Değerler:"})
        bloklar.append({"tip": "p", "metin": f"Şirketin {donem_sonu} tarihi itibariyle Diğer Hazır Değerler hesabının bakiyesi {tutar(abs(bakiye))}'dir."})
        sira += 1

    # 11x - Menkul Kiymetler
    bakiye_11 = sum(hesap_bakiye_tam(rapor, kod) for kod in ["110", "111", "112", "118", "119"])
    if abs(bakiye_11) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Menkul Kıymetler:"})
        deger_dusukluk = abs(hesap_bakiye_tam(rapor, "119"))
        diger_mk = abs(hesap_bakiye_tam(rapor, "118"))
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihi itibarıyla Menkul Kıymetler hesabının bakiyesi "
            f"{tutar(abs(bakiye_11))} olup; bahse konu fonların dönem sonu değerlemesinden elde edilen "
            "kazançlar gelir hesaplarına aktarılmıştır."
        )})
        bloklar.append({"tip": "p", "metin": (
            "VUK Mükerrer 298/A maddesi ve 555 Sıra No.lu VUK Genel Tebliği uyarınca, bu hesapta "
            "izlenen finansal varlıkların niteliksel analizi yapılmıştır. Tebliğ'de belirtildiği üzere, "
            "portföyünün %51'inden fazlası devamlı olarak hisse senetlerinden oluşan (A Tipi) yatırım "
            "fonu katılma belgeleri gibi öz sermaye payını temsil eden finansal enstrümanların parasal "
            "olmayan kıymet olarak sınıflandırıldığı ve iktisap tarihlerine ilişkin düzeltme katsayıları "
            "ile enflasyon düzeltmesine tabi tutulduğu anlaşılmıştır. Devlet Tahvili gibi sabit getirili "
            "ve anapara geri ödeme değeri nominal para birimiyle belirli olan borçlanma senetlerinin "
            "parasal kıymet niteliği taşıması sebebiyle kapsam dışında bırakıldığı teyit edilmiştir."
        )})
        sira += 1

    # 126 - Verilen Depozito ve Teminatlar
    bakiye = hesap_bakiye_tam(rapor, "126")
    if abs(bakiye) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Verilen Depozito ve Teminatlar:"})
        bloklar.append({"tip": "p", "metin": f"Şirketin {donem_sonu} tarihi itibariyle Verilen Depozito ve Teminatlar hesabının bakiyesi {tutar(abs(bakiye))}'dir."})
        bloklar.append({"tip": "p", "metin": (
            "VUK Mükerrer 298/A maddesi ve 555 Sıra No.lu Tebliğ uyarınca, bu hesapta yer alan kıymetlerin "
            "incelenmesi neticesinde, bunların işletmenin üçüncü kişilere nakit olarak verdiği ve nominal "
            "değeri değişmeye tabi (geri alınması veya iade edilmesi mal veya hizmete bağlanmış) bir alacağı "
            "temsil ettiği görülmüş olanların parasal olmayan kıymet niteliğinde değerlendirildiği ve "
            "enflasyon düzeltmesine tabi tutulduğu, parasal alacak niteliği taşıyanlarınse enflasyon "
            "düzeltmesi kapsamı dışında bırakıldığı tespit edilmiştir."
        )})
        sira += 1

    # 128 - Supheli Ticari Alacaklar
    b128 = hesap_bakiye_tam(rapor, "128")
    if abs(b128) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Şüpheli Ticari Alacaklar:"})
        bloklar.append({"tip": "p", "metin": (
            f"{donem_sonu} tarihi itibariyle Şüpheli Ticari Alacaklar (128) hesabının bakiyesi {tutar(abs(b128))}'dir. "
            "Dönem içinde şüpheli hale gelen alacaklar ile dava/icra dosyalarına intikal ettirilen alacaklar "
            "ilgili çalışma kâğıtlarında incelenmiştir."
        )})
        sira += 1

    # 129 - Supheli Ticari Alacaklar Karsiligi
    b129 = abs(hesap_bakiye_tam(rapor, "129"))
    if b129 > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Şüpheli Ticari Alacaklar Karşılığı (-):"})
        bloklar.append({"tip": "p", "metin": (
            f"Şüpheli ticari alacaklar karşılığı (129) hesabının bakiyesi {tutar(b129)}'dir. "
            "Şirketin faturaya bağlı ticari alacaklarının şüpheli hale gelmiş, dava ve icra safhasına düşmüş "
            "alacakları için cari dönemde ayrılan karşılık tutarı ile cari ve geçmiş dönemde şüpheli hale "
            "gelmiş olan ancak tahsil edilen tutarların gelir tablosuna aktarıldığı tespit edilmiştir."
        )})
        sira += 1

    # 13x - Diger Alacaklar
    b13_kodlar = ["131", "132", "133", "135", "136", "137", "138", "139"]
    b13_toplam = sum(hesap_bakiye_tam(rapor, k) for k in b13_kodlar)
    if abs(b13_toplam) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Diğer Alacaklar (13 hesap grubu):"})
        personelden = abs(hesap_bakiye_tam(rapor, "135"))
        diger_cesitli = abs(hesap_bakiye_tam(rapor, "136"))
        parcalar = []
        if personelden > 0.005:
            parcalar.append(f"{tutar(personelden)}'i Personelden Alacaklar")
        if diger_cesitli > 0.005:
            parcalar.append(f"{tutar(diger_cesitli)}'i Diğer Çeşitli Alacaklar")
        detay = ", ".join(parcalar) + " hesabından oluşmaktadır." if parcalar else ""
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihli bilançosunda yer alan Diğer Alacakların Hesabının bakiyesi "
            f"{tutar(abs(b13_toplam))} olup; {detay}"
        )})
        sira += 1

    # 15x - Stoklar
    stok_kodlar = ["150", "151", "152", "153", "154", "155", "157", "158", "159"]
    stok_satirlari = []
    stok_aciklama = {
        "150": "İlk Madde ve Malzeme",
        "151": "Yarı Mamuller- Üretim",
        "152": "Mamuller",
        "153": "Ticari Mallar",
        "157": "Diğer Stoklar",
        "159": "Verilen Sipariş Avansları",
    }
    stok_toplam = 0.0
    for k in stok_kodlar:
        b = hesap_bakiye_tam(rapor, k)
        if abs(b) > 0.005:
            stok_satirlari.append({"kod": k, "ad": stok_aciklama.get(k, ""), "tutar": b})
            stok_toplam += b
    if stok_toplam > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Stoklar:"})
        bloklar.append({"tip": "p", "metin": (
            f"{donem_sonu} tarihli kurum bilançosunda {tutar(stok_toplam)} olarak yer alan Stoklar "
            "hesabının detayı aşağıdaki gibidir."
        )})
        bloklar.append({
            "tip": "tablo",
            "basliklar": ["Hesap Kodu", "Hesap Adı", "Dönem Sonu Stok Tutarı (TL)"],
            "satirlar": [(s["kod"], s["ad"], tutar_sade(s["tutar"])) for s in stok_satirlari],
            "toplam": ("Toplam", "", tutar_sade(stok_toplam)),
        })
        bloklar.append({"tip": "p", "metin": (
            "VUK Mükerrer 298/A maddesi ve 555 Sıra No.lu Tebliğ kapsamında, parasal olmayan kıymet "
            "niteliğindeki stok hesaplarının enflasyon düzeltmesine tabi tutulduğu görülmüştür. Düzeltme "
            "işlemi sonucu oluşan farkların 698 Enflasyon Düzeltme Hesabı'nda muhasebeleştirildiği "
            "anlaşılmıştır. Yapılan incelemede, stokların düzeltilmesinde Tebliğ'in 2/2 maddesinde "
            "belirtilen toplulaştırılmış yöntemlerden \"Basit Ortalama Yöntemi\"nin kullanıldığı tespit "
            "edilmiştir."
        )})
        sira += 1

    # 180/181 - Gelecek Aylara Ait Giderler ve Gelir Tahakkuklari
    b180 = hesap_bakiye_tam(rapor, "180")
    b181 = hesap_bakiye_tam(rapor, "181")
    if abs(b180) + abs(b181) > 0.005:
        toplam = abs(b180) + abs(b181)
        bloklar.append({"tip": "h3", "metin": f"{sira}. Gelecek Aylara Ait Giderler ve Gelir Tahakkukları:"})
        bloklar.append({"tip": "p", "metin": (
            f"{donem_sonu} tarihi itibariyle Gelecek Aylara Ait Giderler ve Gelir Tahakkukları hesabının "
            f"bakiyesi {tutar(toplam)} olup; {tutar(abs(b180))}'i Gelecek Aylara Ait Giderler hesabından, "
            f"{tutar(abs(b181))}'i ise Gelir Tahakkukları hesabından oluşmaktadır."
        )})
        bloklar.append({"tip": "p", "metin": (
            "VUK Mükerrer 298/A maddesi ve 555 Sıra No.lu VUK Genel Tebliği ile 176 Sıra No.lu VUK Sirküsü "
            "uyarınca, 180 Gelecek Aylara Ait Giderler hesabı parasal olmayan kıymet olarak nitelendirilmiş "
            "ve hesaba kaydedilen her bir harcama kaleminin ödeme tarihi düzeltmeye esas alınarak enflasyon "
            "düzeltmesine tabi tutulmuştur. Düzeltme farkları 698 Enflasyon Düzeltme Hesabı'nda "
            "muhasebeleştirilmiştir."
        )})
        sira += 1

    # 19x - Diger Donen Varliklar (KDV vs.)
    b19_kodlar = ["190", "191", "193", "195", "196", "197", "198"]
    b19_toplam = sum(hesap_bakiye_tam(rapor, k) for k in b19_kodlar)
    if abs(b19_toplam) > 0.005:
        b190 = abs(hesap_bakiye_tam(rapor, "190"))
        b191 = abs(hesap_bakiye_tam(rapor, "191"))
        b195 = abs(hesap_bakiye_tam(rapor, "195"))
        b196 = abs(hesap_bakiye_tam(rapor, "196"))
        bloklar.append({"tip": "h3", "metin": f"{sira}. Diğer Dönen Varlıklar:"})
        parcalar = []
        if b190 > 0.005:
            parcalar.append(f"{tutar(b190)}'i Devreden KDV hesabından")
        if b191 > 0.005:
            parcalar.append(f"{tutar(b191)}'i Diğer KDV hesabından")
        if b195 > 0.005:
            parcalar.append(f"{tutar(b195)}'i İş Avansları hesabından")
        if b196 > 0.005:
            parcalar.append(f"{tutar(b196)}'i Personel Avansları hesabından")
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihli bilançosunda yer alan Diğer Dönen Varlıkları "
            f"{tutar(abs(b19_toplam))} olup; söz konusu tutarın " + ", ".join(parcalar) + " oluşmaktadır."
        )})
        sira += 1

    # 25x - Maddi Duran Varliklar (MDV)
    mdv_kodlar = {
        "250": "Arazi ve Arsalar",
        "251": "Yer Altı ve Yer Üstü Düzenleri",
        "252": "Binalar",
        "253": "Tesis, Makine ve Cihazlar",
        "254": "Taşıtlar",
        "255": "Demirbaşlar",
        "256": "Diğer Maddi Duran Varlıklar",
        "257": "Birikmiş Amortismanlar",
        "258": "Yapılmakta Olan Yatırımlar",
        "259": "Verilen Avanslar",
    }
    mdv_satirlari = []
    mdv_toplam = 0.0
    for k, ad in mdv_kodlar.items():
        b = hesap_bakiye_tam(rapor, k)
        if abs(b) > 0.005:
            # 257 birikmis amortisman negatif gosterilir
            display_tutar = b
            if k == "257":
                display_tutar = -abs(b)  # parantezli gosterilecek
                mdv_toplam -= abs(b)
            else:
                mdv_toplam += abs(b)
            display_ad = ad + " (-)" if k == "257" else ad
            mdv_satirlari.append((k, display_ad, display_tutar))

    if mdv_satirlari:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Maddi Duran Varlıklar:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihi itibarıyla Maddi Duran Varlıkları {tutar(mdv_toplam)} olup; "
            "Maddi Duran Varlıklar hesap gruplarının detayı aşağıdaki gibidir;"
        )})
        bloklar.append({
            "tip": "tablo",
            "basliklar": ["Maddi Duran Varlıklar", "Tutar (TL)"],
            "satirlar": [(s[1], tutar_sade(s[2])) for s in mdv_satirlari],
            "toplam": ("Toplam", tutar_sade(mdv_toplam)),
        })
        bloklar.append({"tip": "p", "metin": (
            "VUK Mükerrer 298/A maddesi ve 555 Sıra No.lu Tebliğ çerçevesinde, parasal olmayan nitelikteki "
            "maddi duran varlık hesaplarının enflasyon düzeltmesine tabi tutulduğu görülmüştür. Düzeltmeye "
            "esas tutarların belirlenmesinde her varlığın iktisap tarihine göre veya bir önceki enflasyon "
            "uygulanmış tarihine göre hesaplanan endeks katsayısı uygulanmış, düzeltme farkları ise 698 "
            "Enflasyon Düzeltme Hesabı'nda muhasebeleştirilmiştir."
        )})
        b258 = abs(hesap_bakiye_tam(rapor, "258"))
        if b258 > 0.005:
            bloklar.append({"tip": "p", "metin": (
                "258 No.lu Yapılmakta Olan Yatırımlar hesabında, 555 Sıra No.lu Tebliğ'in 6'ncı maddesi "
                "uyarınca, finansman gideri içeren alımlarda tutarından ROFM (Reel Olmayan Finansman "
                "Maliyeti) ayrıştırmasının yapıldığı ve maliyet tutarından indirildiği tespit edilmiştir. "
                "Ayrıca, 258 hesapta yer alan yatırımlar için 7529 sayılı Kanun ile düzenlenen VUK "
                "mükerrer 298/A-10 maddesi uyarınca, 2024 yılı itibarıyla yapılan enflasyon düzeltmesi "
                "sonucunda oluşan farkların geçici olarak 549 Özel Fonlar hesabında izlenmeye devam "
                "edildiği ve bu farkların dönem kazancına dahil edilmediği, yatırım tamamlandığında ve "
                "izleyen dört hesap döneminde eşit taksitlerle vergiye tabi tutulacağı mükellefin bilgisi "
                "dahilinde olduğu anlaşılmıştır."
            )})
        sira += 1

    # 259 - Verilen Avanslar (U.V.)
    b259 = abs(hesap_bakiye_tam(rapor, "259"))
    if b259 > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Verilen Sipariş Avansları (U.V.):"})
        bloklar.append({"tip": "p", "metin": (
            f"{donem_sonu} tarihli kurum bilançosunda {tutar(b259)} olarak yer alan uzun vadeli sipariş "
            "avansları hesabına ait tutarların VUK Mükerrer 298/A maddesi ve 555 Sıra No.lu VUK Genel "
            "Tebliği uyarınca parasal kıymet niteliği taşıyan kısımlarının enflasyon düzeltmesinde kapsam "
            "dışı bırakıldığı tespit edilmiştir."
        )})
        sira += 1

    # 26x - Maddi Olmayan Duran Varliklar (MODV)
    modv_kodlar = {
        "260": "Haklar",
        "263": "Araştırma ve Geliştirme Giderleri",
        "264": "Özel Maliyetler",
        "267": "Diğer Maddi Olmayan Duran Varlıklar",
        "268": "Birikmiş Amortismanlar",
    }
    modv_satirlari = []
    modv_toplam = 0.0
    for k, ad in modv_kodlar.items():
        b = hesap_bakiye_tam(rapor, k)
        if abs(b) > 0.005:
            if k == "268":
                modv_satirlari.append((k, ad + " (-)", -abs(b)))
                modv_toplam -= abs(b)
            else:
                modv_satirlari.append((k, ad, abs(b)))
                modv_toplam += abs(b)
    if modv_satirlari:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Maddi Olmayan Duran Varlıklar:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihi itibarıyla Maddi Olmayan Duran Varlıkları {tutar(modv_toplam)} "
            "olup; Maddi Olmayan Duran Varlıklar hesabının detayı aşağıdaki gibidir;"
        )})
        bloklar.append({
            "tip": "tablo",
            "basliklar": ["Maddi Olmayan Duran Varlıklar", "Tutar (TL)"],
            "satirlar": [(s[1], tutar_sade(s[2])) for s in modv_satirlari],
            "toplam": ("Toplam", tutar_sade(modv_toplam)),
        })
        bloklar.append({"tip": "p", "metin": (
            "VUK Mükerrer 298/A maddesi ve 555 Sıra No.lu VUK Genel Tebliği uyarınca, işletmenin sahip "
            "olduğu patent, lisans gibi gayri maddi hakları ve bu hakların oluşturulması sürecindeki "
            "harcamaları izlediği Maddi Olmayan Duran Varlıklar hesapları, mahiyetleri itibarıyla parasal "
            "olmayan kıymet olmaları sebebiyle enflasyon düzeltmesine tabi tutulduğu anlaşılmıştır. "
            "Özellikle 260 ve 263 hesaplarda yer alan tutarlar için, şirket içinde yürütülen Ar-Ge "
            "projeleri kapsamında 263 hesabının aylık tutarları dikkate alınarak birikimli bir şekilde "
            "enflasyon düzeltmesi yapıldığı; 263 hesapta oluşan artışların Ar-Ge indirimi hesabında "
            "dikkate alınmadığı tespit edilmiştir."
        )})
        sira += 1

    # 30x - Mali Borclar (K.V.)
    b30_kodlar = ["300", "301", "302", "303", "309"]
    b30_satirlari = []
    b30_isim = {"300": "Banka Kredileri", "301": "Finansal Kiralama İşlemlerinden Borçlar",
                "302": "Ertelenmiş Finansal Kiralama Borçlanma", "303": "Uzun Vadeli Kredilerin Anapara Taksitleri ve Faizleri",
                "309": "Diğer Mali Borçlar"}
    b30_toplam = 0.0
    for k in b30_kodlar:
        b = hesap_bakiye_tam(rapor, k)
        if abs(b) > 0.005:
            b30_satirlari.append((k, b30_isim[k], b))
            b30_toplam += b
    if b30_satirlari:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Mali Borçlar (K.V.):"})
        parcalar = [f"{tutar(abs(s[2]))}'si {s[1]} hesabından" for s in b30_satirlari]
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} itibarıyla Mali Borçlar hesabının bakiyesi {tutar(abs(b30_toplam))} olup; "
            "bu tutarın " + ", ".join(parcalar) + " oluşmaktadır."
        )})
        sira += 1

    # 32x - Ticari Borclar (K.V.)
    b320 = hesap_bakiye_tam(rapor, "320")
    if abs(b320) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Ticari Borçlar (K.V.):"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} itibarıyla Ticari Borçlar hesabının bakiyesi {tutar(abs(b320))} olup; "
            "tamamı Satıcılar hesabından oluşmaktadır."
        )})
        sira += 1

    # 33x - Diger Borclar
    b33_kodlar = ["331", "332", "333", "335", "336"]
    b33_toplam = sum(hesap_bakiye_tam(rapor, k) for k in b33_kodlar)
    if abs(b33_toplam) > 0.005:
        b335 = abs(hesap_bakiye_tam(rapor, "335"))
        b336 = abs(hesap_bakiye_tam(rapor, "336"))
        bloklar.append({"tip": "h3", "metin": f"{sira}. Diğer Borçlar (K.V.):"})
        parcalar = []
        if b335 > 0.005:
            parcalar.append(f"{tutar(b335)}'i Personele Borçlar hesabı")
        if b336 > 0.005:
            parcalar.append(f"{tutar(b336)}'i Diğer Çeşitli Borçlar hesabı")
        bloklar.append({"tip": "p", "metin": (
            f"{donem_sonu} itibarıyla Diğer Borçlar hesabının bakiyesi {tutar(abs(b33_toplam))} olup; "
            "söz konusu tutarın " + ", ".join(parcalar) + " oluşturmaktadır."
        )})
        sira += 1

    # 340 - Alinan Avanslar
    b340 = abs(hesap_bakiye_tam(rapor, "340"))
    if b340 > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Alınan Avanslar:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} itibarıyla Alınan Avanslar hesabının bakiyesi {tutar(b340)} olup; söz "
            "konusu tutarın tamamı Alınan Sipariş Avansları hesabından oluşmaktadır. VUK Mükerrer 298/A "
            "maddesi ve 555 Sıra No.lu VUK Genel Tebliği uyarınca 340 No.lu hesaba ait tutarların tamamı "
            "parasal kıymetler olması nedeniyle enflasyon düzeltmesine tabi tutulmamıştır."
        )})
        sira += 1

    # 36x - Odenecek Vergi ve Diger Yukumlulukler
    b36_kodlar = ["360", "361", "368", "369"]
    b36_isim = {"360": "Ödenecek Vergi ve Fonları", "361": "Ödenecek Sosyal Güvenlik Kesintilerinden",
                "368": "Vadesi Geçmiş Ertelenmiş Vergiler", "369": "Ödenecek Diğer Yükümlülükler"}
    b36_toplam = 0.0
    b36_parcalar = []
    for k in b36_kodlar:
        b = abs(hesap_bakiye_tam(rapor, k))
        if b > 0.005:
            b36_toplam += b
            b36_parcalar.append(f"{tutar(b)}'lik kısmı {b36_isim[k]} hesaplarından")
    if b36_toplam > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Ödenecek Vergi ve Diğer Yükümlülükler:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihi itibari ile Ödenecek Vergi ve Diğer Yükümlülükler tutarı "
            f"{tutar(b36_toplam)} olup " + ", ".join(b36_parcalar) + " oluşmaktadır."
        )})
        sira += 1

    # 38x - Gelecek Aylara Ait Gelirler ve Gider Tahakkuklari
    b380 = abs(hesap_bakiye_tam(rapor, "380"))
    b381 = abs(hesap_bakiye_tam(rapor, "381"))
    if b380 + b381 > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Gelecek Aylara Ait Gelirler ve Gider Tahakkukları:"})
        parcalar = []
        if b380 > 0.005:
            parcalar.append(f"{tutar(b380)}'i Gelecek Aylara Ait Gelirler hesabından")
        if b381 > 0.005:
            parcalar.append(f"{tutar(b381)}'i Gider Tahakkukları hesabından")
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihi itibari ile Gelecek Aylara Ait Gelirler ve Gider Tahakkukları "
            f"hesabının bakiyesi {tutar(b380 + b381)} olup; söz konusu tutarın " + ", ".join(parcalar) + " oluşmaktadır."
        )})
        bloklar.append({"tip": "p", "metin": (
            "VUK Mükerrer 298/A maddesi ve 555 Sıra No.lu VUK Genel Tebliği uyarınca 380 No.lu hesaba ait "
            "tutarların tamamı parasal kıymetler olması nedeniyle enflasyon düzeltmesine tabi tutulmamıştır."
        )})
        sira += 1

    # 40x - Mali Borclar (U.V.)
    b40_kodlar = ["400", "401", "402", "409"]
    b40_isim = {"400": "Banka Kredileri", "401": "Finansal Kiralama İşlemleri",
                "402": "Ertelenmiş Finansal Kiralama Borçlanma maliyetleri", "409": "Diğer Mali Borçlar"}
    b40_satirlari = []
    b40_toplam = 0.0
    for k in b40_kodlar:
        b = hesap_bakiye_tam(rapor, k)
        if abs(b) > 0.005:
            b40_satirlari.append((k, b40_isim[k], b))
            b40_toplam += b
    if b40_satirlari:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Mali Borçlar (U.V.):"})
        parcalar = [f"{tutar(abs(s[2]))}'si {s[1]} hesabından" for s in b40_satirlari]
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihi itibari ile Mali Borçlar (U.V.) hesabının bakiyesi "
            f"{tutar(abs(b40_toplam))} olup; bu tutarın " + ", ".join(parcalar) + " oluşmaktadır."
        )})
        sira += 1

    return bloklar, sira


# ============================================================
# OZKAYNAKLAR (5xx)
# ============================================================

def ozkaynaklar_bloklari(rapor: RaporVerisi, sira_baslangic: int) -> tuple[list, int]:
    bloklar = []
    sira = sira_baslangic
    donem_sonu = rapor.mukellef.donem_sonu

    # 5xx tum hesap toplami - sadece 3 haneli TDHP ana hesaplari
    tum_5xx = sum(
        s.net_bakiye for s in rapor.mizan
        if s.hesap_kodu.strip().startswith("5") and len(s.hesap_kodu.strip()) == 3 and s.hesap_kodu.strip().isdigit()
    )
    if abs(tum_5xx) < 0.005:
        return bloklar, sira

    # H3 baslik
    bloklar.append({"tip": "h3", "metin": f"{sira}. Özkaynaklar:"})
    bloklar.append({"tip": "p", "metin": (
        f"Şirketin dönem sonu itibari ile Özkaynaklar toplamı {tutar(abs(tum_5xx))} olarak gerçekleşmiştir."
    )})

    # 500 + 502 + 504 -> Odenmis Sermaye
    b500 = abs(hesap_bakiye_tam(rapor, "500"))
    b501 = abs(hesap_bakiye_tam(rapor, "501"))
    b502 = abs(hesap_bakiye_tam(rapor, "502"))
    b503 = abs(hesap_bakiye_tam(rapor, "503"))
    b504 = abs(hesap_bakiye_tam(rapor, "504"))
    if b500 + b502 > 0.005:
        odenmis_sermaye = b500 - b501 + b502 - b503 - b504
        bloklar.append({"tip": "h4", "metin": f"{sira}.1. Ödenmiş Sermaye:"})
        parcalar = []
        if b500 > 0.005:
            parcalar.append(f"{tutar(b500)}'i Sermaye hesabından")
        if b501 > 0.005:
            parcalar.append(f"({tutar_sade(b501)}-TL)'i Ödenmemiş Sermaye hesabından")
        if b502 > 0.005:
            parcalar.append(f"{tutar(b502)}'i Sermaye Düzeltmesi Olumlu Farkları hesabından")
        if b504 > 0.005:
            parcalar.append(f"({tutar_sade(b504)}-TL)'i hisse geri alım programı kapsamındaki tutardan")
        bloklar.append({"tip": "p", "metin": (
            f"Ödenmiş Sermaye tutarı {tutar(abs(odenmis_sermaye))} olup; söz konusu tutarın " + ", ".join(parcalar) + " oluşmaktadır."
        )})
        bloklar.append({"tip": "p", "metin": (
            "VUK Mükerrer 298/A maddesi ve 555 Sıra No.lu VUK Genel Tebliği uyarınca, 500 Sermaye hesabı "
            "parasal olmayan kıymet olması sebebiyle enflasyon düzeltmesine tabi tutulduğu; düzeltme "
            "işleminin sermayeyi oluşturan her bir taahhüdün yerine getirildiği tarihler baz alınarak "
            "yapıldığı, oluşan olumlu farkın 698 Enflasyon Düzeltme Hesabı'na borç, 502 Sermaye "
            "Düzeltmesi Olumlu Farkları hesabına alacak kaydedildiği anlaşılmıştır."
        )})

    # 52x - Sermaye Yedekleri
    b52_toplam = sum(abs(hesap_bakiye_tam(rapor, k)) for k in ["520", "521", "522", "523", "529"])
    b520 = abs(hesap_bakiye_tam(rapor, "520"))
    if b52_toplam > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.2. Sermaye Yedekleri:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin dönem sonu itibariyle Sermaye Yedekleri hesabı {tutar(b52_toplam)} olup; bu tutarın "
            f"{tutar(b520)} Hisse Senedi İhraç Primlerinden oluşmaktadır."
        )})
        bloklar.append({"tip": "p", "metin": (
            "VUK Mükerrer 298/A maddesi ve 555 Sıra No.lu Tebliğ kapsamında, 520 No.lu Sermaye Yedekleri "
            "hesabı parasal olmayan özkaynak unsuru niteliğinde olup hisse senetleri ihracında oluşan "
            "primlerin düzeltmeye tabi tutulduğu, düzeltme farkının 698 Enflasyon Düzeltme Hesabı'na gider "
            "olarak kaydedildiği anlaşılmıştır."
        )})

    # 540 - Yasal Yedekler
    b540 = abs(hesap_bakiye_tam(rapor, "540"))
    if b540 > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.3. Yasal Yedekler:"})
        bloklar.append({"tip": "p", "metin": (
            f"Dönem sonu itibariyle Yasal Yedekler tutarı {tutar(b540)}'dir. VUK Mükerrer 298/A maddesi "
            "ve 555 Sıra No.lu Tebliğ kapsamında, 540 Yasal Yedekler Hesabı'nın parasal olmayan öz kaynak "
            "kalemleri arasında yer aldığı ve ayrılmış olan tutarın ait olduğu hesap dönemi sonundaki aydan "
            f"{donem_sonu} tarihine kadar olan Yİ-ÜFE artış oranları kullanılarak düzeltildiği görülmüştür. "
            "Düzeltme farkları 698 Enflasyon Düzeltme Hesabı'na gider olarak kaydedilmiş ve 540 hesabına "
            "ilave edilerek muhasebeleştirilmiştir."
        )})

    # 541 - Statu Yedekler
    b541 = abs(hesap_bakiye_tam(rapor, "541"))
    if b541 > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.4. Statü Yedekleri:"})
        bloklar.append({"tip": "p", "metin": (
            f"Dönem sonu itibariyle Statü Yedekler tutarı {tutar(b541)}'dir. VUK Mükerrer 298/A maddesi "
            "ve 555 Sıra No.lu Tebliğ uyarınca, şirket esas sözleşmesine dayanarak ayrılan ve özkaynak "
            "kalemleri arasında yer alan 541 Statü Yedekleri Hesabı parasal olmayan pasif unsur olarak "
            "enflasyon düzeltmesine tabi tutulmuş; düzeltme farkları 698 Enflasyon Düzeltme Hesabı'na "
            "gider olarak kaydedilmiş ve 541 hesabına ilave edilerek muhasebeleştirilmiştir."
        )})

    # 542 - Olaganustu Yedekler
    b542 = abs(hesap_bakiye_tam(rapor, "542"))
    if b542 > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.5. Olağanüstü Yedekler:"})
        bloklar.append({"tip": "p", "metin": (
            f"Dönem sonu itibariyle Olağanüstü Yedekler tutarı {tutar(b542)}'dir. VUK Mükerrer 298/A "
            "maddesi ve 555 Sıra No.lu Tebliğ kapsamında, 542 Olağanüstü Yedekler hesabının parasal "
            "olmayan pasif niteliğinde olduğu ve enflasyon düzeltmesine tabi tutulması gerektiği "
            "anlaşılmıştır. Düzeltme farkı 698 Enflasyon Düzeltme Hesabı'na gider olarak kaydedilmiş, "
            "karşılığında 542 No.lu hesaba eklenmek suretiyle muhasebeleştirilmiştir."
        )})

    # 549 - Ozel Fonlar
    b549 = abs(hesap_bakiye_tam(rapor, "549"))
    if b549 > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.6. Özel Fonlar:"})
        bloklar.append({"tip": "p", "metin": (
            f"Dönem sonu itibariyle Özel Fonlar tutarı {tutar(b549)} olup; söz konusu tutar şirketin "
            "değişik kanun maddeleri uyarınca oluşturduğu özel fonlardan oluşmaktadır."
        )})
        bloklar.append({"tip": "p", "metin": (
            "VUK Mükerrer 298/A maddesi ve 555 Sıra No.lu VUK Genel Tebliği uyarınca, 549 Özel Fonlar "
            "hesabının parasal olmayan bir öz kaynak unsuru olması sebebiyle enflasyon düzeltmesine tabi "
            "tutulduğu, fonu oluşturan her bir kalemin kaynağına ve tabi olduğu vergi mevzuatına bağlı "
            "olarak alt detayında analiz edildiği görülmüştür."
        )})
        bloklar.append({"tip": "p", "metin": (
            "Bununla birlikte 7529 sayılı Kanun ile VUK mükerrer 298/A-10 maddesine eklenen hüküm "
            "uyarınca, 2024 yılı enflasyon düzeltmesi sonucunda 549 Özel Fonlar Hesabı'nda izlenen ve "
            "yapılmakta olan yatırımlara ilişkin olarak hesaplanan enflasyon düzeltme farklarının, 2024 ve "
            "müteakip yıllarda kurum kazancına dahil edilmeyeceği, bu farkların yalnızca YDO (yeniden "
            "değerleme oranı) ile artırılarak izlenmeye devam edeceği hüküm altına alınmıştır. Yatırım "
            "tamamlandığında ilgili fon tutarının takip eden dört hesap döneminde eşit taksitlerle kurum "
            "kazancına dahil edileceği mükellef bilgisi dahilindedir."
        )})

    # 580 - Gecmis Yillar Zararlari
    b580 = abs(hesap_bakiye_tam(rapor, "580"))
    if b580 > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.7. Geçmiş Yıllar Zararları:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin geçmiş yıllara ait zararı {tutar(b580)}'dir. VUK Mükerrer 298/A maddesi ve 555 Sıra "
            "No.lu Tebliğ kapsamında, 580 Geçmiş Yıllar Zararları Hesabı'nın parasal olmayan pasif unsurlar "
            f"arasında yer aldığı ve enflasyon düzeltmesine tabi tutulduğu, geçmiş yıllar zararlarının "
            f"oluştuğu yıl sonundan {donem_sonu} tarihine kadar olan Yİ-ÜFE endeks oranları dikkate "
            "alınarak düzeltme katsayılarının hesaplanıp uygulandığı tespit edilmiştir. Enflasyon "
            "düzeltmesi sonucunda 580 hesabında meydana gelen azalışların 698 Enflasyon Düzeltme "
            "Hesabı'na gelir olarak yansıtıldığı görülmüştür."
        )})

    # 590 - Donem Net Kari
    b590 = hesap_bakiye_tam(rapor, "590")
    if abs(b590) > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.8. Dönem Net Kârı:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {rapor.mukellef.donem_baslangic[6:]} hesap dönemine ait Dönem Net Kârı {tutar(abs(b590))}'dir."
        )})

    sira += 1
    return bloklar, sira


# ============================================================
# B. GELIR TABLOSU HESAPLARI
# ============================================================

def gelir_tablosu_bloklari(rapor: RaporVerisi) -> list:
    bloklar = []
    donem = rapor.mukellef.donem

    bloklar.append({"tip": "h2", "metin": "B. GELİR TABLOSU HESAPLARI"})
    bloklar.append({"tip": "p", "metin": (
        f"Şirketin, raporumuza eklenmiş bulunan {donem} hesap dönemi gelir tablosunda yer alan satışlar, "
        "maliyetler, pazarlama satış ve dağıtım giderleri, genel yönetim giderleri ile diğer gelir-gider "
        "hesapları ve dönem kârının kanuni defter kayıtları ile mutabık ve muhasebe sistemi uygulama genel "
        "tebliğlerine uygun olduğu ve gerçeği yansıttığı görülmüştür."
    )})
    bloklar.append({"tip": "p", "metin": (
        "Gelir tablosu kalemlerindeki vergi mevzuatını ilgilendiren başlıca hususlar ve bunlar hakkındaki "
        "tespit ve kanaatlerimiz özetle şöyledir;"
    )})

    sira = 1
    # 1. Alis ve Satislar
    yi_satis = abs(hesap_bakiye_tam(rapor, "600"))
    yd_satis = abs(hesap_bakiye_tam(rapor, "601"))
    dig_gelir = abs(hesap_bakiye_tam(rapor, "602"))
    brut_satis = yi_satis + yd_satis + dig_gelir
    if brut_satis > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Alış ve Satışlar:"})
        bloklar.append({"tip": "p", "metin": (
            "Örnekleme suretiyle yapılan incelemelerde, şirketin muhtelif mal ve hizmet alış ve "
            "satışlarına ilişkin faturalarında gerçek dışı bir alış veya satış emaresine rastlanmamıştır."
        )})
        bloklar.append({"tip": "p", "metin": (
            "Şirketin mal ve hizmet alım ve satım miktarlarıyla bu firmalarla olan borç ve alacak "
            "ilişkilerinin uyumlu olduğu, borç ve alacak ödeme ve tahsilatının çoğunlukla bankalardan "
            "havale suretiyle yapıldığı, nakit tediye ve tahsilatının makul seviyede olduğu görülmüştür."
        )})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin, {donem} hesap döneminde Brüt Satışlar toplamı {tutar(brut_satis)}'dir. Bu tutarın "
            f"{tutar(yi_satis)}'lik kısmı Yurtiçi Satışlara, {tutar(yd_satis)}'lik kısmı Yurtdışı "
            f"Satışlara ve {tutar(dig_gelir)}'lik kısmı ise Diğer Gelirlere ilişkindir."
        )})
        sira += 1

    # 2. Satis Indirimleri
    b610 = abs(hesap_bakiye_tam(rapor, "610"))
    b611 = abs(hesap_bakiye_tam(rapor, "611"))
    b612 = abs(hesap_bakiye_tam(rapor, "612"))
    si_top = b610 + b611 + b612
    if si_top > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Satış İndirimleri (-):"})
        parcalar = []
        if b610 > 0.005:
            parcalar.append(f"({tutar_sade(b610)}-TL)'lik kısmı Satıştan İadeler hesabından")
        if b611 > 0.005:
            parcalar.append(f"({tutar_sade(b611)}-TL)'lik kısmı Satış İskontoları hesabından")
        if b612 > 0.005:
            parcalar.append(f"({tutar_sade(b612)}-TL)'lik kısmı Diğer İndirimler hesabından")
        bloklar.append({"tip": "p", "metin": (
            f"{donem} hesap dönemine ilişkin Gelir Tablosunda Satış İndirimleri hesabının bakiyesi "
            f"({tutar_sade(si_top)}) olup; söz konusu tutarın " + " ve ".join(parcalar) + " oluşmaktadır."
        )})
        sira += 1

    # 3. Satislarin Maliyeti
    b620 = abs(hesap_bakiye_tam(rapor, "620"))
    b621 = abs(hesap_bakiye_tam(rapor, "621"))
    b622 = abs(hesap_bakiye_tam(rapor, "622"))
    b623 = abs(hesap_bakiye_tam(rapor, "623"))
    smt = b620 + b621 + b622 + b623
    if smt > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Satışların Maliyeti(-):"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem} hesap dönemine ilişkin Gelir Tablosunda yer alan toplam Satışların Maliyeti "
            f"({tutar_sade(smt)}-TL)'dir."
        )})
        satirlar = []
        if b620 > 0.005:
            satirlar.append(("Satılan Mamuller Maliyeti", f"({tutar_sade(b620)})"))
        if b621 > 0.005:
            satirlar.append(("Satılan Ticari Mallar Maliyeti", f"({tutar_sade(b621)})"))
        if b622 > 0.005:
            satirlar.append(("Satılan Hizmet Maliyeti", f"({tutar_sade(b622)})"))
        if b623 > 0.005:
            satirlar.append(("Diğer Satışların Maliyeti", f"({tutar_sade(b623)})"))
        bloklar.append({
            "tip": "tablo",
            "basliklar": ["Satışların Maliyeti", "Tutar (TL)"],
            "satirlar": satirlar,
            "toplam": ("TOPLAM", f"({tutar_sade(smt)})"),
        })
        sira += 1

    # 4. Faaliyet Giderleri
    b630 = abs(hesap_bakiye_tam(rapor, "630"))
    b631 = abs(hesap_bakiye_tam(rapor, "631"))
    b632 = abs(hesap_bakiye_tam(rapor, "632"))
    fg = b630 + b631 + b632
    if fg > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Faaliyet Giderleri (-):"})
        bloklar.append({"tip": "p", "metin": (
            f"{rapor.mukellef.donem_sonu} tarihli gelir tablosunda Faaliyet Giderlerinin toplamı "
            f"({tutar_sade(fg)}-TL) olarak yer almaktadır. Bu tutarın ({tutar_sade(b630)}-TL)'i "
            f"Araştırma ve Geliştirme Giderleri, ({tutar_sade(b631)}-TL)'i Pazarlama Satış ve Dağıtım "
            f"Giderleri ve ({tutar_sade(b632)}-TL)'i Genel Yönetim Giderleri hesaplarından oluşmaktadır."
        )})
        if b630 > 0.005:
            bloklar.append({"tip": "p", "metin": (
                f"Tasdik dönemi içerisinde şirketin ({tutar_sade(b630)}-TL)'lik Araştırma ve Geliştirme "
                "Giderleri personel ücret ve giderleri, işçi tazminat giderleri, dışardan alınan hizmet "
                "giderleri, danışmanlık giderleri, amortisman giderleri ve eğitim/kurs/seminer/konferans "
                "katılım giderlerinden oluşmaktadır."
            )})
        if b631 > 0.005:
            bloklar.append({"tip": "p", "metin": (
                f"({tutar_sade(b631)}-TL) olarak gerçekleşen Pazarlama Satış ve Dağıtım Giderleri; "
                "personel ücret ve giderleri, işçi tazminat giderleri, seyahat ve ulaşım giderleri, "
                "pazarlama giderleri (reklam, tanıtım, ilan), nakliye, ihracat, satış ve sevk giderleri "
                "ve diğer giderlerden oluşmaktadır."
            )})
        if b632 > 0.005:
            bloklar.append({"tip": "p", "metin": (
                f"Tasdik dönemi içerisinde şirketin Genel Yönetim Giderleri ({tutar_sade(b632)}-TL) "
                "olarak gerçekleşmiştir. Genel Yönetim Giderleri; personel ücret ve giderleri, işçi "
                "tazminat giderleri, elektrik ısınma giderleri, vergi giderleri (resim, harç), temsil "
                "ağırlama giderleri, amortisman giderleri, ulaşım ve haberleşme giderleri, araç giderleri "
                "ve diğer giderlerden oluşmaktadır."
            )})
        sira += 1

    # 5. Diger Olagan Gelir / Giderler
    b64 = sum(abs(hesap_bakiye_tam(rapor, k)) for k in ["640", "641", "642", "643", "644", "645", "646", "647", "648", "649"])
    b65 = sum(abs(hesap_bakiye_tam(rapor, k)) for k in ["650", "651", "652", "653", "654", "655", "656", "657", "658", "659"])
    if b64 + b65 > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Diğer Faaliyetlerden Olağan Gelir ve Gider Kalemleri:"})
        if b64 > 0.005:
            bloklar.append({"tip": "p", "metin": (
                f"Gelir Tablosunda {tutar(b64)} olarak yer alan Diğer Faaliyetlerden Olağan Gelir ve "
                "Kârlar hesabı; Faiz Gelirleri, Konusu Kalmayan Karşılıklar, Menkul Kıymet Satış Kârları, "
                "Kambiyo Kârları, Reeskont Faiz Gelirleri, Enflasyon Düzeltmesi Karları ve Diğer Olağan "
                "Gelir ve Kârlar hesaplarından oluşmaktadır."
            )})
            b642 = abs(hesap_bakiye_tam(rapor, "642"))
            b644 = abs(hesap_bakiye_tam(rapor, "644"))
            b645 = abs(hesap_bakiye_tam(rapor, "645"))
            b646 = abs(hesap_bakiye_tam(rapor, "646"))
            b648 = abs(hesap_bakiye_tam(rapor, "648"))
            if b642 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Faiz Gelirleri toplamı {tutar(b642)} olup; bankalarda bulunan vadeli mevduat "
                    "hesaplarından elde edilen faiz gelirleri oluşmaktadır."
                )})
            if b644 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin Konusu Kalmayan Karşılıklar toplamı {tutar(b644)} olup; ilgili tutar "
                    "geçmiş dönemde icra safhasına gelen ve karşılık gideri ayrılan tutarların tahsil "
                    "edilmiş tutarlarından oluşmaktadır."
                )})
            if b645 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin Menkul Kıymet Satış Kârları toplamı {tutar(b645)} olup; bankada yer alan "
                    "fon hesaplarına ilişkin gelirden oluşmaktadır."
                )})
            if b646 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin döviz cinsinden işlemleri ile döviz cinsinden mevcutlarının değerlenmesi "
                    f"sonucunda ortaya çıkan Kambiyo Kârları toplamı {tutar(b646)}'dir."
                )})
            if b648 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin cari dönemde aktif ve pasiflerindeki parasal olmayan kıymetler için "
                    f"enflasyon düzeltme farkları karları {tutar(b648)}'dir."
                )})
        if b65 > 0.005:
            bloklar.append({"tip": "p", "metin": (
                f"Gelir Tablosunda ({tutar_sade(b65)}-TL) olarak yer alan Diğer Faaliyetlerden Olağan "
                "Gider ve Zararlar hesabı; Karşılık Giderleri, Menkul Kıymet Satış Zararları, Kambiyo "
                "Zararları, Enflasyon Düzeltmesi Zararları hesaplarından oluşmaktadır."
            )})
            b654 = abs(hesap_bakiye_tam(rapor, "654"))
            b655 = abs(hesap_bakiye_tam(rapor, "655"))
            b656 = abs(hesap_bakiye_tam(rapor, "656"))
            b658 = abs(hesap_bakiye_tam(rapor, "658"))
            if b654 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin faturaya bağlı ticari alacaklarının şüpheli hale gelmiş dava ve icra "
                    f"safhasına düşmüş alacakları için ayırmış olduğu karşılık gideri {tutar(b654)}'dir."
                )})
            if b655 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin Menkul Kıymet Satış Zararları toplamı {tutar(b655)} olup; bankada yer "
                    "alan fon hesaplarının fona iadesi ve dönem sonu değerlemesinden kaynaklı oluşan "
                    "zararlardan oluşmaktadır."
                )})
            if b656 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin döviz cinsinden işlemleri ile döviz cinsinden mevcutlarının değerlenmesi "
                    f"sonucunda ortaya çıkan Kambiyo Zararları toplamı ({tutar_sade(b656)}-TL)'dir."
                )})
            if b658 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin cari dönemde aktif ve pasiflerindeki parasal olmayan kıymetler için "
                    f"enflasyon düzeltme zararları {tutar(b658)}'dir."
                )})
        sira += 1

    # 6. Finansman Giderleri (FGK ile birlikte)
    b660 = abs(hesap_bakiye_tam(rapor, "660"))
    b661 = abs(hesap_bakiye_tam(rapor, "661"))
    fg_top = b660 + b661
    if fg_top > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Finansman Giderleri(-):"})
        bloklar.append({"tip": "p", "metin": (
            f"{rapor.mukellef.donem_sonu} itibarıyla şirketin Finansman Giderleri toplamı "
            f"({tutar_sade(fg_top)}-TL) olarak gerçekleşmiştir. Şirketin finansman giderleri bankalara "
            "ödenen yatırım kredisine ait faiz giderleri ile banka komisyon giderleri ve vade farkı "
            "giderlerinden oluşmaktadır."
        )})
        # FGK hesaplamasi - SADECE 3 haneli TDHP ana hesaplari (musteri kodlari haric)
        def _tdhp_ana_grup_toplami(prefix: str) -> float:
            top = 0.0
            for s in rapor.mizan:
                hk = s.hesap_kodu.strip()
                if hk.startswith(prefix) and len(hk) == 3 and hk.isdigit():
                    top += s.net_bakiye
            return top
        kvyk = _tdhp_ana_grup_toplami("3")
        uvyk = _tdhp_ana_grup_toplami("4")
        ozkaynak = _tdhp_ana_grup_toplami("5")
        kvyk = abs(kvyk)
        uvyk = abs(uvyk)
        ozkaynak = abs(ozkaynak)
        toplam_yk = kvyk + uvyk
        ozk_asan = toplam_yk - ozkaynak
        if ozk_asan > 0 and toplam_yk > 0:
            kisitlama_oran = ozk_asan / toplam_yk
            kisitlama_tutar = fg_top * kisitlama_oran
            kkeg = kisitlama_tutar * 0.10
            bloklar.append({"tip": "p", "metin": (
                "Bununla birlikte 15/6/2012 tarihli Resmi Gazete'de yayımlanan 6322 Sayılı Kanun ile "
                "01.01.2013 tarihinde yürürlüğe girmek üzere, 5520 sayılı Kurumlar Vergisi Kanununun "
                "11'inci maddesinin birinci fıkrasının (i) bendinde, kredi kuruluşları, finansal "
                "kuruluşlar, finansal kiralama, faktöring ve finansman şirketleri dışında, kullanılan "
                "yabancı kaynakları öz kaynaklarını aşan işletmelerde, aşan kısma münhasır olmak üzere, "
                "yatırımın maliyetine eklenenler hariç, işletmede kullanılan yabancı kaynaklara ilişkin "
                "faiz, komisyon, vade farkı, kâr payı, kur farkı ve benzeri adlar altında yapılan gider "
                "ve maliyet unsurları toplamının %10'unu aşmamak üzere Cumhurbaşkanınca kararlaştırılan "
                "kısmının kanunen kabul edilmeyen gider olarak dikkate alınacağı hüküm altına alınmıştı."
            )})
            bloklar.append({"tip": "p", "metin": (
                f"Yukarıdaki kanun hükmünce vergi öncesi Şirketin {rapor.mukellef.donem_sonu} tarihli "
                "bilanço hesaplarının tetkikinden özkaynak ve yabancı kaynak durumu aşağıdaki gibidir."
            )})
            bloklar.append({
                "tip": "tablo",
                "basliklar": ["Özkaynak/Yabancı Kaynak Karşılaştırma Tablosu", "Tutar (TL)"],
                "satirlar": [
                    (f"1  Kısa Vadeli Yabancı Kaynaklar (3'lü Hesaplar)", tutar_sade(kvyk)),
                    (f"2  Uzun Vadeli Yabancı Kaynaklar (4'lü Hesaplar)", tutar_sade(uvyk)),
                    (f"3  Toplam Yabancı Kaynaklar (1+2)", tutar_sade(toplam_yk)),
                    (f"4  Özsermaye", tutar_sade(ozkaynak)),
                    (f"5  Özsermayeyi Aşan Yabancı Kaynaklar (3-4)", tutar_sade(ozk_asan)),
                    (f"6  Kısıtlama Oranı (5/3)", f"{kisitlama_oran:.4f}".replace(".", ",")),
                    (f"7  Maliyete Eklenen Finansman Gideri", "0,00"),
                    (f"8  Finansman Gideri (Faiz, Komisyon, Vade Farkı, Kur Farkı ve Benzeri)", tutar_sade(fg_top)),
                    (f"9  Kısıtlanan Tutar (8*6)", tutar_sade(kisitlama_tutar)),
                    (f"10 Hesaplanan KKEG (9*0,10)", tutar_sade(kkeg)),
                ],
                "toplam": None,
            })
            oran_tr = f"{kisitlama_oran:.4f}".replace(".", ",")
            bloklar.append({"tip": "p", "metin": (
                f"Yukarıdaki tabloda da görüleceği üzere şirketin toplam yabancı kaynaklarının "
                f"{tutar(toplam_yk)} olduğu ve özkaynağı aşan tutarın {tutar(ozk_asan)} ve yabancı "
                f"kaynağın özkaynağı aşma oranının {oran_tr} olarak hesaplanması ile "
                f"{tutar(fg_top)} finansman gideri çarpılması sonucunda kısıtlamaya tabi tutar "
                f"{tutar(kisitlama_tutar)} olarak hesaplanmıştır. İlgili tutarın KVK'nın 11'inci "
                f"maddesinde belirtilen %10 oranı ile çarpılması neticesinde finansman gider kısıtlaması "
                f"olarak {tutar(kkeg)}'nin Kanunen Kabul Edilmeyen Gider olarak beyan edildiği "
                "anlaşılmıştır."
            )})
        sira += 1

    # 7. Olagandisi Gelir / Karlar
    b67 = sum(abs(hesap_bakiye_tam(rapor, k)) for k in ["671", "672", "673", "674", "675", "676", "677", "678", "679"])
    b671 = abs(hesap_bakiye_tam(rapor, "671"))
    b679 = abs(hesap_bakiye_tam(rapor, "679"))
    if b67 > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Olağandışı Gelir ve Kârlar Hesabı:"})
        parcalar = []
        if b671 > 0.005:
            parcalar.append(f"{tutar(b671)}'lik kısmı Önceki Dönem Gelir ve Karları hesabından")
        if b679 > 0.005:
            parcalar.append(f"{tutar(b679)}'lik kısmı ise Diğer Olağandışı Gelir ve Kârlar hesabından")
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin Gelir Tablosunda Olağandışı Gelir ve Kârlar hesabının bakiyesi {tutar(b67)} olup"
            + (" ; " + ", ".join(parcalar) + " oluşmaktadır." if parcalar else ".")
        )})
        sira += 1

    # 8. Olagandisi Gider / Zararlar
    b68 = sum(abs(hesap_bakiye_tam(rapor, k)) for k in ["680", "681", "682", "683", "684", "685", "686", "687", "688", "689"])
    b681 = abs(hesap_bakiye_tam(rapor, "681"))
    b689 = abs(hesap_bakiye_tam(rapor, "689"))
    if b68 > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Olağandışı Gider ve Zararlar Hesabı (-):"})
        parcalar = []
        if b681 > 0.005:
            parcalar.append(f"({tutar_sade(b681)}-TL)'lik kısmı Önceki Dönem Gider ve Zararları hesabından")
        if b689 > 0.005:
            parcalar.append(f"({tutar_sade(b689)}-TL)'lik kısmı ise Diğer Olağandışı Gider ve Zararlar hesabından")
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin Gelir Tablosunda Olağandışı Gider ve Zararlar hesabının bakiyesi "
            f"({tutar_sade(b68)}-TL) olup"
            + ("; " + ", ".join(parcalar) + " oluşmaktadır." if parcalar else ".")
        )})
        sira += 1

    # 9-10-11 - Donem Kari ve Vergiler
    b690 = abs(hesap_bakiye_tam(rapor, "690"))
    b691 = abs(hesap_bakiye_tam(rapor, "691"))
    b692 = abs(hesap_bakiye_tam(rapor, "692"))
    if b690 > 0.005 or rapor.beyanname.ticari_bilanco_kari > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Dönem Karı veya Zararı"})
        karlar = rapor.beyanname.ticari_bilanco_kari if rapor.beyanname.ticari_bilanco_kari > 0.005 else b690
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {rapor.mukellef.donem_baslangic[6:]} hesap dönemi sonunda vergi karşılığı öncesi "
            f"dönem karı {tutar(karlar)}'dir."
        )})
        sira += 1
        if rapor.beyanname.hesaplanan_vergi > 0.005 or b691 > 0.005:
            bloklar.append({"tip": "h3", "metin": f"{sira}. Dönem Karı, Vergi ve Diğer Yasal Yükümlülük Karşılığı"})
            v = rapor.beyanname.hesaplanan_vergi if rapor.beyanname.hesaplanan_vergi > 0.005 else b691
            bloklar.append({"tip": "p", "metin": (
                f"Şirketin {rapor.mukellef.donem_baslangic[6:]} hesap dönem kârı üzerinden, ilgili "
                f"mevzuat hükümlerine göre hesaplanan vergi ve yasal yükümlülüklerin tutarı {tutar(v)}'dir."
            )})
            sira += 1
        b692_val = abs(hesap_bakiye_tam(rapor, "692"))
        net_kar = hesap_bakiye_tam(rapor, "590")
        if net_kar == 0:
            net_kar = b692_val if b692_val > 0.005 else (karlar - (rapor.beyanname.hesaplanan_vergi or b691))
        if net_kar:
            bloklar.append({"tip": "h3", "metin": f"{sira}. Dönem Net Karı veya Zararı"})
            bloklar.append({"tip": "p", "metin": (
                f"Şirketin {rapor.mukellef.donem_baslangic[6:]} hesap dönemi sonunda vergi karşılığı sonrası "
                f"dönem net karı {tutar(abs(net_kar))}'dir."
            )})

    return bloklar


# ============================================================
# C. DIGER INCELEMELER
# ============================================================

def diger_incelemeler_bloklari(rapor: RaporVerisi) -> list:
    bloklar = []
    bloklar.append({"tip": "h2", "metin": "C. DİĞER İNCELEMELER"})

    # 1. Gecici Vergiler
    bloklar.append({"tip": "h3", "metin": "1. Yıl İçinde Geçici Vergilerin Hesaplanmasına İlişkin İncelemeler:"})
    bloklar.append({"tip": "p", "metin": (
        "Şirketin cari vergilendirme döneminde kurumlar vergisine mahsup edilmek üzere, 5520 sayılı "
        "Kurumlar Vergisi Kanunu'nun 32'nci maddesinin 2. fıkrasında ve 193 sayılı Gelir Vergisi "
        "Kanunu'nun mükerrer 120'nci maddesinde belirtilen esaslara göre beyan ettiği geçici vergi "
        "beyannamelerine ilişkin bilgiler ilgili çalışma kâğıdı tablosunda gösterilmiştir."
    )})
    if rapor.beyanname.odenen_gecici_vergi > 0.005:
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin ilgili dönem için ödenmiş olduğu toplam geçici vergi tutarı "
            f"{tutar(rapor.beyanname.odenen_gecici_vergi)}'dir."
        )})

    # 2. Kesinti Yoluyla Pesin Odenen Vergiler
    bloklar.append({"tip": "h3", "metin": "2. Kesinti Yoluyla Peşin Ödenen Vergilere İlişkin İncelemeler:"})
    bloklar.append({"tip": "p", "metin": (
        f"Şirketin {rapor.mukellef.donem} hesap dönemine ilişkin bankalardaki vadeli mevduat hesaplarından "
        "elde ettiği faiz gelirleri üzerinden tevkif edilen gelir vergisi stopajı tutarları, banka faiz ve "
        "kesinti yazıları ile mutabık olup rapor ekinde sunulmuştur."
    )})
    if rapor.beyanname.yil_ici_kesinti > 0.005:
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin yıl içinde kesinti yoluyla ödenen vergileri toplam tutarı "
            f"{tutar(rapor.beyanname.yil_ici_kesinti)}'dir."
        )})

    # 3. KKEG
    if rapor.beyanname.kkeg_toplam > 0.005:
        bloklar.append({"tip": "h3", "metin": "3. Kanunen Kabul Edilmeyen Giderler:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin 2024 hesap dönemine ait kanunen kabul edilmeyen giderleri toplam tutarı "
            f"{tutar(rapor.beyanname.kkeg_toplam)} olup; ilgili çalışma kâğıdında türleri itibarıyla "
            "tasnif edilmiştir."
        )})

    # 4. Istisnalar
    if rapor.beyanname.zarar_olsa_dahi_indirim_toplam > 0.005:
        bloklar.append({"tip": "h3", "metin": "4. Zarar Olsa Dahi İndirilecek İstisna ve İndirimler:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin 2024 hesap dönemine ait Zarar Olsa Dahi İndirilecek İstisna ve İndirimler toplamı "
            f"{tutar(rapor.beyanname.zarar_olsa_dahi_indirim_toplam)} olup; Kurumlar Vergisi Beyannamesinde "
            "ayrıntılı dökümü verilmiştir. Bu kapsamda KVK Geçici Madde 14 KKM istisnası, İştirak Kazançları "
            "İstisnası (KVK m.5/1-a) ve diğer ilgili istisna kalemleri çalışma kâğıtları ile kontrol "
            "edilmiştir."
        )})

    # 5. Matrah ve Hesaplanan Vergi
    if rapor.beyanname.matrah > 0.005:
        bloklar.append({"tip": "h3", "metin": "5. Kurumlar Vergisi Matrahı ve Hesaplanan Vergi:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin Kurumlar Vergisi Matrahı {tutar(rapor.beyanname.matrah)}, Hesaplanan Kurumlar "
            f"Vergisi {tutar(rapor.beyanname.hesaplanan_vergi)} olarak beyan edilmiş; mahsup edilecek "
            f"vergiler düşüldükten sonra "
            + (f"İadesi Gereken Kurumlar Vergisi pozisyonu oluşmuştur." if rapor.beyanname.hesaplanan_vergi < rapor.beyanname.yil_ici_kesinti + rapor.beyanname.odenen_gecici_vergi else "Ödenmesi Gereken Kurumlar Vergisi tutarı hesaplanmıştır.")
        )})

    return bloklar


# ============================================================
# ANA URETICI
# ============================================================

def hesap_incelemeleri_uret(rapor: RaporVerisi) -> list:
    """Tum III- Hesap Incelemeleri bolumunu uretir."""
    bloklar = []

    # Bolum basligi
    bloklar.append({"tip": "h1", "metin": "III- HESAP İNCELEMELERİ"})
    bloklar.append({"tip": "p", "metin": (
        f"{rapor.mukellef.donem} hesap dönemi işlemlerinin vergi kanunları yönünden yapılan incelemesinde "
        "tespit edilen hususlar ve değerlendirmeler aşağıda gösterilmiştir."
    )})

    # A. BILANCO
    bloklar.append({"tip": "h2", "metin": "A. BİLANÇO HESAPLARINA İLİŞKİN İNCELEMELER"})
    bloklar.append({"tip": "p", "metin": (
        f"Şirketin, raporumuza eklenmiş bulunan {rapor.mukellef.donem_sonu} tarihli bilançosunda yer alan "
        "tutarların defter-i kebir hesap bakiyeleri ile kanuni defter kayıtlarının mutabık olduğu ve "
        "gerçeği yansıttığı, bilançonun muhasebe sistemi uygulama genel tebliğlerinde belirtilen ilkelere "
        "uygun olduğu, 213 sayılı Vergi Usul Kanunu'nun 298/a maddesi uyarınca parasal olmayan kıymetlerin "
        "555, 560 ve 563 Sıra No.lu Vergi Usul Kanunu Genel Tebliğleri ile belirlenmiş, 165, 170, 175, 176 "
        "ve 181 Sıra No.lu Vergi Usul Kanunu Sirkülerinde de enflasyon düzeltmesi uygulaması ile ilgili "
        "ilave düzenlemeler/açıklamalar ile 7529 sayılı Kanun'un ilgili hükümleri kapsamında enflasyon "
        "düzeltmesine tabi tutulduğu görülmüştür."
    )})

    # 1. Yabanci Para
    bloklar.extend(bilanco_dovizli_bolum_bloklari(rapor))
    # 2.x diger bilanco hesaplari
    diger_bloklar, son_sira = diger_bilanco_bloklari(rapor, sira_baslangic=2)
    bloklar.extend(diger_bloklar)
    # 24. (veya yer geldikce) Ozkaynaklar
    oz_bloklar, _ = ozkaynaklar_bloklari(rapor, sira_baslangic=son_sira)
    bloklar.extend(oz_bloklar)

    # B. GELIR TABLOSU
    bloklar.extend(gelir_tablosu_bloklari(rapor))

    # NOT: C. Diger Incelemeler bolumu kullanici talebi uzerine devre disi.
    # Aktiflestirmek icin: bloklar.extend(diger_incelemeler_bloklari(rapor))

    return bloklar
