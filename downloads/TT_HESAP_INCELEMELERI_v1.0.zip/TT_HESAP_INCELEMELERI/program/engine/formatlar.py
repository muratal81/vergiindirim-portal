"""Tutar / tarih formatlama yardimcilari."""


def tutar(value: float, eksili_parantez: bool = True) -> str:
    """1234567.89 -> '1.234.567,89-TL'  Negatifler parantez icinde."""
    if value is None:
        return "0,00-TL"
    try:
        value = float(value)
    except (ValueError, TypeError):
        return "0,00-TL"
    if abs(value) < 0.005:
        return "0,00-TL"
    negatif = value < 0
    if negatif:
        value = -value
    # Binlik ayrac . ondalik ayrac ,
    formatted = f"{value:,.2f}"
    formatted = formatted.replace(",", "X").replace(".", ",").replace("X", ".")
    s = f"{formatted}-TL"
    if negatif:
        if eksili_parantez:
            s = f"({s})"
        else:
            s = f"-{s}"
    return s


def tutar_sade(value: float) -> str:
    """Tablo icin TL ekiz: '1.234.567,89'  Negatifler '(1.234.567,89)'."""
    if value is None:
        return "0,00"
    try:
        value = float(value)
    except (ValueError, TypeError):
        return "0,00"
    if abs(value) < 0.005:
        return "0,00"
    negatif = value < 0
    if negatif:
        value = -value
    formatted = f"{value:,.2f}"
    formatted = formatted.replace(",", "X").replace(".", ",").replace("X", ".")
    if negatif:
        return f"({formatted})"
    return formatted


def doviz_format(value: float) -> str:
    """Doviz tutari format: 1.234.567,89 (eksisiz)."""
    if value is None:
        return "0,00"
    try:
        value = float(value)
    except (ValueError, TypeError):
        return "0,00"
    formatted = f"{abs(value):,.2f}"
    formatted = formatted.replace(",", "X").replace(".", ",").replace("X", ".")
    return formatted


def kur_format(value: float) -> str:
    """Kur format: 35,2233 (4 ondalik)."""
    if value is None or abs(value) < 0.0001:
        return "0,0000"
    formatted = f"{value:,.4f}"
    formatted = formatted.replace(",", "X").replace(".", ",").replace("X", ".")
    return formatted


def tarih_iso_to_tr(tarih: str) -> str:
    """2024-12-31 -> 31.12.2024"""
    if not tarih:
        return ""
    if "-" in tarih and len(tarih) >= 10:
        try:
            y, m, d = tarih[:10].split("-")
            return f"{d}.{m}.{y}"
        except Exception:
            pass
    return tarih
