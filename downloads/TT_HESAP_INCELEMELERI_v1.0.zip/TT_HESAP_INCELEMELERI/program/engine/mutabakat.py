"""Mutabakat / dogrulama motoru - mizan vs beyanname vs bilanco karsilastirmalari."""
from engine.data_model import RaporVerisi, ValidationFinding


TOLERANS = 0.50  # 0.50 TL toleransi - yuvarlamadan kaynakli farklar icin


# Bilanco satirlari -> mizan hesap kodu prefixleri
BILANCO_HESAP_ESLESTIRMESI = {
    "Kasa": "100",
    "Alınan Çekler": "101",
    "Bankalar": "102",
    "Verilen Çekler ve Ödeme Emirleri (-)": "103",
    "Diğer Hazır Değerler": "108",
    "Diğer Menkul Kıymetler": "118",
    "Alıcılar": "120",
    "Verilen Depozito ve Teminatlar": "126",  # KV hesabi - 226 farkli
    "Şüpheli Ticari Alacaklar": "128",
    "Şüpheli Ticari Alacaklar Karşılığı (-)": "129",
    "Personelden Alacaklar": "135",
    "Diğer Çeşitli Alacaklar": "136",
    "İlk Madde ve Malzeme": "150",
    "Yarı Mamuller - Üretim": "151",
    "Mamuller": "152",
    "Ticari Mallar": "153",
    "Diğer Stoklar": "157",
    "Verilen Sipariş Avansları": "159",  # KV - 259 farkli
    "Gelecek Aylara Ait Giderler": "180",
    "Gelir Tahakkukları": "181",
    "Devreden KDV": "190",
    "Diger KDV": "191",
    "İş Avansları": "195",
    "Personel Avansları": "196",
    "Arazi ve Arsalar": "250",
    "Yer Altı ve Yer Üstü Düzenleri": "251",
    "Binalar": "252",
    "Tesis, Makina ve Cihazlar": "253",
    "Taşıtlar": "254",
    "Demirbaşlar": "255",
    "Yapılmakta Olan Yatırımlar": "258",
    "Haklar": "260",
    "Araştırma ve Geliştirme Giderleri": "263",
    "Özel Maliyetler": "264",
    "Diğer Maddi Olmayan Duran Varlıklar": "267",
    "Banka Kredileri": "300",
    "Finansal Kiralama İşlemlerinden Borçlar": "301",
    "Ertelenmiş Finansal Kiralama Borçlanma": "302",
    "Uzun Vadeli Kredilerin Anapara Taksitleri ve": "303",
    "Diğer Mali Borçlar": "309",
    "Satıcılar": "320",
    "Personele Borçlar": "335",
    "Diğer Çeşitli Borçlar": "336",
    "Alınan Sipariş Avansları": "340",
    "Ödenecek Vergi ve Fonlar": "360",
    "Ödenecek Sosyal Güvenlik Kesintileri": "361",
    "Gider Tahakkukları": "381",
    "Sermaye": "500",
    "Sermaye Düzeltmesi Olumlu Farkları": "502",
    "Hisse Senedi İhraç Primleri": "520",
    "Yasal Yedekler": "540",
    "Statü Yedekleri": "541",
    "Olağanüstü Yedekler": "542",
    "Özel Fonlar": "549",
    "Geçmiş Yıllar Zararları (-)": "580",
    "Dönem Net Karı": "590",
    "Dönem Net Karı (zararı)": "590",
}


def hesap_grup_bakiye(rapor: RaporVerisi, hesap_kodu: str) -> float:
    """Bir hesap kodu icin mizandaki ana hesap satirini bul, net bakiyesini dondur."""
    target = hesap_kodu.strip()
    for satir in rapor.mizan:
        if satir.hesap_kodu.strip() == target:
            return satir.net_bakiye
    return 0.0


def mizan_borc_alacak_kontrol(rapor: RaporVerisi) -> ValidationFinding | None:
    """VAL-001: Mizan borc/alacak toplami esitligi (sadece en alt seviye satirlar).
    Sadece 100, 100.01.001 gibi nokta-formatli kodlari leaf olarak kabul et;
    10000XXX gibi musteri/cari hesap kodlarini ayri tut."""
    leaf_satirlar = []
    kodlar = {s.hesap_kodu for s in rapor.mizan}
    for s in rapor.mizan:
        hk = s.hesap_kodu.strip()
        # Daha derin alt hesap yoksa leaf
        has_child = any(other.startswith(hk + ".") for other in kodlar)
        if not has_child:
            leaf_satirlar.append(s)
    toplam_borc = sum(s.borc_toplam for s in leaf_satirlar)
    toplam_alacak = sum(s.alacak_toplam for s in leaf_satirlar)
    fark = abs(toplam_borc - toplam_alacak)
    if fark > TOLERANS:
        return ValidationFinding(
            kod="VAL-001",
            aciklama=f"Mizan borc/alacak toplami esit degil. Borc: {toplam_borc:,.2f}, Alacak: {toplam_alacak:,.2f}, Fark: {fark:,.2f}",
            onem="uyari",
            mizan_tutar=toplam_borc,
            beyanname_tutar=toplam_alacak,
            fark=fark,
        )
    return None


def beyanname_mizan_kontrol(rapor: RaporVerisi) -> list:
    """Beyanname bilancosu ile mizan ana hesaplarini karsilastir."""
    bulgular = []
    for kalem in rapor.beyanname.bilanco_satirlari:
        ad = kalem.aciklama.strip()
        # Eslestirme tablosunda var mi?
        hesap_kod = None
        for label, kod in BILANCO_HESAP_ESLESTIRMESI.items():
            if label.lower() in ad.lower() or ad.lower() in label.lower():
                hesap_kod = kod
                break
        if not hesap_kod:
            continue
        mizan_bakiye = abs(hesap_grup_bakiye(rapor, hesap_kod))
        beyanname_tutar = abs(kalem.cari_donem)
        fark = abs(mizan_bakiye - beyanname_tutar)
        if fark > TOLERANS:
            bulgular.append(ValidationFinding(
                kod=f"VAL-FS-{hesap_kod}",
                aciklama=f"{ad} ({hesap_kod}) hesabinda mizan-beyanname uyumsuzlugu",
                onem="uyari" if fark < 100 else "kritik",
                mizan_tutar=mizan_bakiye,
                beyanname_tutar=beyanname_tutar,
                fark=fark,
            ))
    return bulgular


def kontrolleri_calistir(rapor: RaporVerisi) -> list:
    """Tum kontrolleri calistir ve bulgulari rapor.bulgular'a ekle."""
    bulgular = []
    f = mizan_borc_alacak_kontrol(rapor)
    if f:
        bulgular.append(f)
    bulgular.extend(beyanname_mizan_kontrol(rapor))
    rapor.bulgular = bulgular
    return bulgular
