"""Tam Tasdik Raporu Hesap Incelemeleri Word ciktisi."""
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from engine.data_model import RaporVerisi
from engine.formatlar import tutar_sade, doviz_format, kur_format


def _set_cell_shading(cell, color_hex: str) -> None:
    """Tablo hucresine arka plan rengi ekle."""
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), color_hex)
    tcPr.append(shd)


def _set_run_font(run, name="Times New Roman", size=11, bold=False):
    run.font.name = name
    run.font.size = Pt(size)
    run.bold = bold
    # East Asia font (kalin Turkce karakterler icin)
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.append(rFonts)
    rFonts.set(qn("w:ascii"), name)
    rFonts.set(qn("w:hAnsi"), name)
    rFonts.set(qn("w:cs"), name)


def _add_paragraph(doc, text, size=11, bold=False, alignment=WD_ALIGN_PARAGRAPH.JUSTIFY, after=4):
    p = doc.add_paragraph()
    p.alignment = alignment
    pf = p.paragraph_format
    pf.space_before = Pt(0)
    pf.space_after = Pt(after)
    pf.line_spacing = 1.15
    run = p.add_run(text)
    _set_run_font(run, size=size, bold=bold)
    return p


def _add_heading(doc, text, level: int):
    """h1=14pt bold ortali, h2=12pt bold solda, h3=11pt bold solda, h4=11pt bold solda."""
    sizes = {1: 13, 2: 12, 3: 11, 4: 11}
    aligns = {1: WD_ALIGN_PARAGRAPH.CENTER, 2: WD_ALIGN_PARAGRAPH.LEFT,
              3: WD_ALIGN_PARAGRAPH.LEFT, 4: WD_ALIGN_PARAGRAPH.LEFT}
    sz = sizes.get(level, 11)
    al = aligns.get(level, WD_ALIGN_PARAGRAPH.LEFT)
    p = doc.add_paragraph()
    p.alignment = al
    pf = p.paragraph_format
    pf.space_before = Pt(8) if level <= 2 else Pt(6)
    pf.space_after = Pt(4)
    pf.keep_with_next = True
    run = p.add_run(text)
    _set_run_font(run, size=sz, bold=True)
    return p


def _add_doviz_tablo(doc, satirlar: list):
    """Doviz tablosu olustur: Doviz Cinsi | Doviz Tutari | Doviz Kuru | Bakiye (TL)"""
    if not satirlar:
        return
    tbl = doc.add_table(rows=1 + len(satirlar) + 1, cols=4)
    tbl.style = "Table Grid"
    # Baslik
    hdr = tbl.rows[0]
    headers = ["Döviz Cinsi", "Döviz Tutarı", "Döviz Kuru", "Bakiye (TL)"]
    for ci, h in enumerate(headers):
        cell = hdr.cells[ci]
        cell.text = ""
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(h)
        _set_run_font(run, size=10, bold=True)
        _set_cell_shading(cell, "D9D9D9")
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER

    toplam_tl = 0.0
    for ri, s in enumerate(satirlar, start=1):
        row = tbl.rows[ri]
        cells = [
            (s["doviz_cinsi"], WD_ALIGN_PARAGRAPH.CENTER),
            (doviz_format(s["doviz_tutari"]), WD_ALIGN_PARAGRAPH.RIGHT),
            (kur_format(s["kur"]), WD_ALIGN_PARAGRAPH.RIGHT),
            (tutar_sade(s["bakiye_tl"]), WD_ALIGN_PARAGRAPH.RIGHT),
        ]
        for ci, (text, al) in enumerate(cells):
            cell = row.cells[ci]
            cell.text = ""
            p = cell.paragraphs[0]
            p.alignment = al
            run = p.add_run(text)
            _set_run_font(run, size=10)
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        toplam_tl += s["bakiye_tl"]

    # Toplam satiri
    last = tbl.rows[-1]
    last.cells[0].text = ""
    p0 = last.cells[0].paragraphs[0]
    run0 = p0.add_run("Toplam")
    _set_run_font(run0, size=10, bold=True)
    p0.alignment = WD_ALIGN_PARAGRAPH.LEFT
    last.cells[1].text = ""
    last.cells[2].text = ""
    last.cells[3].text = ""
    p3 = last.cells[3].paragraphs[0]
    run3 = p3.add_run(tutar_sade(toplam_tl))
    _set_run_font(run3, size=10, bold=True)
    p3.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    for ci in [0, 1, 2, 3]:
        _set_cell_shading(last.cells[ci], "F2F2F2")


def _add_genel_tablo(doc, basliklar: list, satirlar: list, toplam=None):
    """Genel tablo: basliklar + satirlar + opsiyonel toplam satiri."""
    n_cols = len(basliklar)
    n_rows = 1 + len(satirlar) + (1 if toplam else 0)
    tbl = doc.add_table(rows=n_rows, cols=n_cols)
    tbl.style = "Table Grid"
    # Baslik
    for ci, h in enumerate(basliklar):
        cell = tbl.rows[0].cells[ci]
        cell.text = ""
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(h)
        _set_run_font(run, size=10, bold=True)
        _set_cell_shading(cell, "D9D9D9")
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER

    # Satirlar
    for ri, satir in enumerate(satirlar, start=1):
        for ci, val in enumerate(satir):
            cell = tbl.rows[ri].cells[ci]
            cell.text = ""
            p = cell.paragraphs[0]
            # Sayi gibi gozukenleri saga hizala
            text_val = str(val)
            is_num = any(ch.isdigit() for ch in text_val) and (
                text_val.replace(".", "").replace(",", "").replace("(", "").replace(")", "").replace("-", "").replace("TL", "").replace(" ", "").isdigit()
                or text_val.strip().startswith("(")
            )
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT if is_num and ci > 0 else WD_ALIGN_PARAGRAPH.LEFT
            run = p.add_run(text_val)
            _set_run_font(run, size=10)
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER

    # Toplam
    if toplam:
        row = tbl.rows[-1]
        for ci, val in enumerate(toplam):
            cell = row.cells[ci]
            cell.text = ""
            p = cell.paragraphs[0]
            text_val = str(val)
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT if ci > 0 else WD_ALIGN_PARAGRAPH.LEFT
            run = p.add_run(text_val)
            _set_run_font(run, size=10, bold=True)
            _set_cell_shading(cell, "F2F2F2")


def _add_kapak(doc, rapor: RaporVerisi):
    """Rapor kapagi: baslik + mukellef bilgileri."""
    mk = rapor.mukellef

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("YEMİNLİ MALİ MÜŞAVİRLİK")
    _set_run_font(run, size=14, bold=True)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("TAM TASDİK RAPORU - HESAP İNCELEMELERİ")
    _set_run_font(run, size=14, bold=True)

    doc.add_paragraph()
    _add_paragraph(doc, f"Mükellef Vergi Kimlik Numarası: {mk.vergi_no}", size=11, bold=False, alignment=WD_ALIGN_PARAGRAPH.LEFT, after=2)
    _add_paragraph(doc, f"Mükellef Adı–Soyadı / Unvanı: {mk.unvan}", size=11, bold=False, alignment=WD_ALIGN_PARAGRAPH.LEFT, after=2)
    if mk.vergi_dairesi:
        _add_paragraph(doc, f"Vergi Dairesi: {mk.vergi_dairesi}", size=11, bold=False, alignment=WD_ALIGN_PARAGRAPH.LEFT, after=2)
    _add_paragraph(doc, f"İnceleme Dönemi: {mk.donem}", size=11, bold=False, alignment=WD_ALIGN_PARAGRAPH.LEFT, after=2)
    if mk.rapor_no:
        _add_paragraph(doc, f"Rapor Sayısı: {mk.rapor_no}", size=11, bold=False, alignment=WD_ALIGN_PARAGRAPH.LEFT, after=2)
    if mk.ymm_adi:
        _add_paragraph(doc, f"YMM Adı-Soyadı: {mk.ymm_adi}", size=11, bold=False, alignment=WD_ALIGN_PARAGRAPH.LEFT, after=2)

    doc.add_page_break()


def _add_bulgular(doc, rapor: RaporVerisi):
    """Mutabakat bulgulari (varsa) sari arka planli olarak listele."""
    if not rapor.bulgular:
        return
    kritik = [b for b in rapor.bulgular if b.onem == "kritik"]
    uyari = [b for b in rapor.bulgular if b.onem == "uyari"]
    if not (kritik or uyari):
        return
    _add_heading(doc, "MUTABAKAT BULGULARI (Beyanname - Mizan - Mali Tablo)", level=2)
    _add_paragraph(doc, (
        "Aşağıdaki bulgular, programın beyanname-mizan-bilanço çapraz kontrolü sonucunda tespit "
        "ettiği farklardır. Bu farklar nihai rapor onayı öncesinde YMM tarafından değerlendirilmelidir."
    ), size=10)
    tbl = doc.add_table(rows=1 + len(kritik) + len(uyari), cols=5)
    tbl.style = "Table Grid"
    hdrs = ["Kod", "Açıklama", "Mizan (TL)", "Beyanname (TL)", "Fark (TL)"]
    for ci, h in enumerate(hdrs):
        cell = tbl.rows[0].cells[ci]
        cell.text = ""
        p = cell.paragraphs[0]
        run = p.add_run(h)
        _set_run_font(run, size=10, bold=True)
        _set_cell_shading(cell, "D9D9D9")
    ri = 1
    for b in kritik + uyari:
        row = tbl.rows[ri]
        color = "FFCCCC" if b.onem == "kritik" else "FFF2CC"
        cells = [
            b.kod, b.aciklama, tutar_sade(b.mizan_tutar),
            tutar_sade(b.beyanname_tutar), tutar_sade(b.fark)
        ]
        for ci, val in enumerate(cells):
            cell = row.cells[ci]
            cell.text = ""
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if ci < 2 else WD_ALIGN_PARAGRAPH.RIGHT
            run = p.add_run(str(val))
            _set_run_font(run, size=9)
            _set_cell_shading(cell, color)
        ri += 1
    doc.add_paragraph()


def _add_bilanco_ek(doc, rapor: RaporVerisi):
    """EK-1: Bilanco - Standart MSUGT formati."""
    doc.add_page_break()
    _add_heading(doc, "EK-1: BİLANÇO", level=2)
    _add_paragraph(doc, f"{rapor.mukellef.unvan} - {rapor.mukellef.donem_sonu} tarihli bilanço", size=10, alignment=WD_ALIGN_PARAGRAPH.CENTER)
    if not rapor.bilanco:
        _add_paragraph(doc, "Bilanço verisi yüklenmedi.", size=10)
        return
    n_rows = 1 + len(rapor.bilanco)
    tbl = doc.add_table(rows=n_rows, cols=3)
    tbl.style = "Table Grid"
    for ci, h in enumerate(["Açıklama", "Önceki Dönem (TL)", "Cari Dönem (TL)"]):
        cell = tbl.rows[0].cells[ci]
        cell.text = ""
        p = cell.paragraphs[0]
        run = p.add_run(h)
        _set_run_font(run, size=9, bold=True)
        _set_cell_shading(cell, "D9D9D9")

    for ri, k in enumerate(rapor.bilanco, start=1):
        row = tbl.rows[ri]
        prefix = "    " * max(0, k.seviye - 1)
        label = prefix + (f"{k.hesap_kodu} {k.aciklama}" if k.hesap_kodu else k.aciklama)
        row.cells[0].text = ""
        p = row.cells[0].paragraphs[0]
        run = p.add_run(label)
        _set_run_font(run, size=9, bold=(k.seviye == 0))
        for ci, val in enumerate([k.onceki_donem, k.cari_donem], start=1):
            cell = row.cells[ci]
            cell.text = ""
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            run = p.add_run(tutar_sade(val))
            _set_run_font(run, size=9, bold=(k.seviye == 0))


def _add_gelir_tablo_ek(doc, rapor: RaporVerisi):
    """EK-2: Gelir Tablosu."""
    doc.add_page_break()
    _add_heading(doc, "EK-2: GELİR TABLOSU", level=2)
    _add_paragraph(doc, f"{rapor.mukellef.unvan} - {rapor.mukellef.donem} hesap dönemi", size=10, alignment=WD_ALIGN_PARAGRAPH.CENTER)
    if not rapor.gelir_tablosu:
        _add_paragraph(doc, "Gelir tablosu verisi yüklenmedi.", size=10)
        return
    n_rows = 1 + len(rapor.gelir_tablosu)
    tbl = doc.add_table(rows=n_rows, cols=3)
    tbl.style = "Table Grid"
    for ci, h in enumerate(["Açıklama", "Önceki Dönem (TL)", "Cari Dönem (TL)"]):
        cell = tbl.rows[0].cells[ci]
        cell.text = ""
        p = cell.paragraphs[0]
        run = p.add_run(h)
        _set_run_font(run, size=9, bold=True)
        _set_cell_shading(cell, "D9D9D9")
    for ri, k in enumerate(rapor.gelir_tablosu, start=1):
        row = tbl.rows[ri]
        prefix = "    " * max(0, k.seviye - 1)
        label = prefix + (f"{k.hesap_kodu} {k.aciklama}" if k.hesap_kodu else k.aciklama)
        row.cells[0].text = ""
        p = row.cells[0].paragraphs[0]
        run = p.add_run(label)
        _set_run_font(run, size=9, bold=(k.seviye == 0))
        for ci, val in enumerate([k.onceki_donem, k.cari_donem], start=1):
            cell = row.cells[ci]
            cell.text = ""
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            run = p.add_run(tutar_sade(val))
            _set_run_font(run, size=9, bold=(k.seviye == 0))


def yaz_word_raporu(rapor: RaporVerisi, bloklar: list, output_path: str):
    """Tum bloklari iceren Word raporunu yazip kaydeder."""
    doc = Document()

    # Default font ayari
    style = doc.styles["Normal"]
    style.font.name = "Times New Roman"
    style.font.size = Pt(11)

    # Sayfa kenar boslugu
    sections = doc.sections
    for section in sections:
        section.top_margin = Cm(2.5)
        section.bottom_margin = Cm(2.5)
        section.left_margin = Cm(2.5)
        section.right_margin = Cm(2.5)
        # Altbilgi
        footer = section.footer
        if footer.paragraphs:
            fp = footer.paragraphs[0]
            fp.text = "Bu belge, 5070 sayılı Elektronik İmza Kanunu'nun 5. Maddesi gereğince nitelikli elektronik imza ile imzalanmıştır."
            for run in fp.runs:
                _set_run_font(run, size=8)

    # Kapak
    _add_kapak(doc, rapor)
    # Bulgular ozeti
    _add_bulgular(doc, rapor)

    # Ana icerik
    for blok in bloklar:
        tip = blok["tip"]
        if tip == "h1":
            _add_heading(doc, blok["metin"], level=1)
        elif tip == "h2":
            _add_heading(doc, blok["metin"], level=2)
        elif tip == "h3":
            _add_heading(doc, blok["metin"], level=3)
        elif tip == "h4":
            _add_heading(doc, blok["metin"], level=4)
        elif tip == "p":
            _add_paragraph(doc, blok["metin"], size=11)
        elif tip == "doviz_tablo":
            _add_doviz_tablo(doc, blok["satirlar"])
        elif tip == "tablo":
            _add_genel_tablo(doc, blok["basliklar"], blok["satirlar"], blok.get("toplam"))
        elif tip == "sari_uyari":
            p = doc.add_paragraph()
            run = p.add_run(blok["metin"])
            _set_run_font(run, size=11)
            # Sari paragraf shading
            shd = OxmlElement("w:shd")
            shd.set(qn("w:val"), "clear")
            shd.set(qn("w:color"), "auto")
            shd.set(qn("w:fill"), "FFF2CC")
            p._p.get_or_add_pPr().append(shd)

    # NOT: EK-1 Bilanco ve EK-2 Gelir Tablosu ekleri kullanici talebi uzerine devre disi.
    # Aktiflestirmek icin: _add_bilanco_ek(doc, rapor); _add_gelir_tablo_ek(doc, rapor)

    doc.save(output_path)
