"""Word rapor uretim modulleri."""
