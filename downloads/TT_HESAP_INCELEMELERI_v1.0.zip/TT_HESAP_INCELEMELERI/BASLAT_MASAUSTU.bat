@echo off
REM ====================================================================
REM   TT Hesap Incelemeleri - MASAUSTU (tkinter) Modu Baslatici
REM ====================================================================
cd /d "%~dp0program"
if not exist "tt_hesap_incelemeleri.py" (
    echo.
    echo  HATA: program\tt_hesap_incelemeleri.py bulunamadi.
    echo  Bu .bat dosyasini ZIP'in icinden DOGRUDAN calistirmayin.
    echo  Once .zip dosyasina SAG TIKLA - TUMUNU AYIKLA yapin,
    echo  cikan klasor icinden bu .bat dosyasini calistirin.
    echo.
    pause
    exit /b 1
)
echo.
echo  Tam Tasdik Raporu - Hesap Incelemeleri
echo  Masaustu (tkinter) modu baslatiliyor...
echo.
py tt_hesap_incelemeleri.py
if errorlevel 1 (
    echo.
    echo  HATA: Program baslatilamadi.
    echo  Once KURULUM.bat dosyasina cift tiklayin (Python paketleri icin).
    echo.
    pause
)
