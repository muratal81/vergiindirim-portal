@echo off
REM Tam Tasdik Raporu Hesap Incelemeleri - Ilk Kurulum
echo.
echo  ============================================================
echo    Tam Tasdik Raporu Hesap Incelemeleri Programi
echo    Ilk kurulum - Python paketleri yukleniyor...
echo  ============================================================
echo.
py -m pip install python-docx openpyxl pdfplumber flask
echo.
echo  Kurulum tamamlandi.
echo.
echo  Artik su dosyalardan birini calistirabilirsiniz:
echo    - BASLAT_MASAUSTU.bat  (tkinter penceresi)
echo    - BASLAT_WEB.bat       (tarayicidan kullanim)
echo.
pause
