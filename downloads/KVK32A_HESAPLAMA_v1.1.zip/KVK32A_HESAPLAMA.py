#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
KVK 32/A - Indirimli Kurumlar Vergisi Hesaplama Programi (Kapsamli GUI)
========================================================================
Firma bazli kaydetme/yukleme, gecmis YKT takibi,
kitaptaki iki sinir kurali (YKT siniri + gerceklestirilen harcama siniri).

~100+ veri alani, 8 ana grup (A-H) + Firma Yonetimi
Asgari KV (32/C) etkilesimi, OSB ek puan, Nakdi Sermaye detay,
beyanname kodlari (1063/1064/1065), 10 yil sure siniri
"""

import sys
import os
import json
import re
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog
from copy import deepcopy
from dataclasses import dataclass, field, asdict
from typing import Optional
from pathlib import Path
from datetime import datetime

# Opsiyonel: PDF ve Word okuma
try:
    import pdfplumber
    PDF_OK = True
except ImportError:
    PDF_OK = False

try:
    import docx
    DOCX_OK = True
except ImportError:
    DOCX_OK = False

# ============================================================================
# SABITLER
# ============================================================================

VERI_KLASORU = Path.home() / ".kvk32a_veriler"

KV_ORANLARI = {
    2018: 22, 2019: 22, 2020: 22, 2021: 25, 2022: 23,
    2023: 25, 2024: 25, 2025: 25, 2026: 25,
}
VARSAYILAN_KV_ORANI = 25
IHRACAT_URETIM_INDIRIM = 5
URETIM_INDIRIM = 1
NAKDI_SERMAYE_EK_KATKI = 5
ASGARI_KV_ORANI = {2025: 10, 2026: 10}  # KVK 32/C
ASGARI_KV_VARSAYILAN = 10
YATIRIM_SURESI_YIL = 10  # Belge tarihinden itibaren max sure

BKK_3305 = {
    "bolgesel": {
        1: (15, 50), 2: (20, 55), 3: (25, 60),
        4: (30, 70), 5: (40, 80), 6: (50, 90),
    },
    "buyuk_olcekli": {
        1: (25, 50), 2: (30, 55), 3: (35, 60),
        4: (40, 70), 5: (50, 80), 6: (55, 90),
    },
    "stratejik": {
        1: (50, 90), 2: (50, 90), 3: (50, 90),
        4: (50, 90), 5: (50, 90), 6: (50, 90),
    },
    "yatirim_donemi": {1: 50, 2: 50, 3: 50, 4: 50, 5: 80, 6: 80},
}
CB_9903 = {
    "bolgesel": {
        1: (15, 55), 2: (20, 60), 3: (25, 70),
        4: (30, 80), 5: (40, 90), 6: (50, 99),
    },
    "buyuk_olcekli": {
        1: (25, 60), 2: (30, 65), 3: (35, 70),
        4: (40, 80), 5: (50, 90), 6: (55, 99),
    },
    "stratejik": {
        1: (50, 90), 2: (50, 90), 3: (50, 90),
        4: (50, 90), 5: (50, 90), 6: (50, 99),
    },
    "yatirim_donemi": {1: 50, 2: 50, 3: 50, 4: 50, 5: 80, 6: 80},
}

KARAR_MAP = {"2012/3305 sayili BKK": BKK_3305, "9903 sayili CB Karari": CB_9903}
TESVIK_MAP = {"Bolgesel Tesvik": "bolgesel", "Buyuk Olcekli Yatirim": "buyuk_olcekli", "Stratejik Yatirim": "stratejik"}
YATIRIM_TURU_MAP = {"Komple Yeni": "komple", "Tevsi": "tevsi", "Modernizasyon": "modernizasyon",
                    "Urun Cesitlendirme": "urun_cesitlendirme", "Entegrasyon": "entegrasyon"}
TESVIK_TURU_LIST = list(TESVIK_MAP.keys())
KARAR_LIST = list(KARAR_MAP.keys())
YATIRIM_TURU_LIST = list(YATIRIM_TURU_MAP.keys())
BOLGE_LIST = ["1", "2", "3", "4", "5", "6"]
DONEM_TURU_LIST = ["Yatirim", "Isletme"]
TAMAMLAMA_VIZESI_LIST = ["Devam Ediyor", "Tamamlandi", "Sure Uzatmasi"]
GECICI_DONEM_LIST = ["Yillik", "1.Donem (Oca-Mar)", "2.Donem (Oca-Haz)",
                     "3.Donem (Oca-Eyl)", "4.Donem (Oca-Ara)"]


# ============================================================================
# YARDIMCI
# ============================================================================

def pf(tutar):
    if tutar is None: return "-"
    if tutar == 0: return "0,00"
    neg = tutar < 0; tutar = abs(tutar)
    tam = int(tutar); kus = round((tutar - tam) * 100)
    if kus >= 100: tam += 1; kus = 0
    s = ""
    for i, c in enumerate(reversed(str(tam))):
        if i > 0 and i % 3 == 0: s = "." + s
        s = c + s
    r = f"{s},{kus:02d}"
    return f"-{r}" if neg else r

def pt(text):
    text = str(text).strip().replace(" ", "").replace("TL", "").replace("tl", "")
    if not text or text == "-": return 0.0
    if "," in text and "." in text: text = text.replace(".", "").replace(",", ".")
    elif "," in text: text = text.replace(",", ".")
    return float(text)

def kv_orani_yil(yil):
    return KV_ORANLARI.get(yil, VARSAYILAN_KV_ORANI)


def _sayi_bul(text):
    """Turk format sayiyi yakala: 1.234.567,89 veya 1234567.89"""
    if not text:
        return 0.0
    m = re.search(r'[\d.,]+', text.replace(" ", ""))
    return pt(m.group()) if m else 0.0


# ============================================================================
# BEYANNAME PDF PARSER
# ============================================================================

class BeyannameParser:
    """KV beyannamesi PDF'inden veri cikarir."""

    # Beyannamede aranan anahtar kelimeler ve kodlar
    PATTERNS = {
        "donem_yil": r'(?:Takvim\s*Y[ıi]l[ıi]|D.NEM\s*T.P.\s*Y.l|D[öo]nem)\s*[:.]?\s*(\d{4})',
        "ticari_kar": r'(?:Ticari\s*Bilan[cç]o\s*K[aâ]r[ıi]|Ticari\s*kar)\s*[:.]*\s*([\d.,]+)',
        "kkeg": r'Kanunen\s*Kabul\s*Edilmeyen\s*Giderler\s*[:.]*\s*([\d.,]+)',
        "kv_matrahi": r'(?:Kurumlar\s*Vergisi\s*Matrah[ıi]|KV\s*Matrah)\s*[:.]*\s*([\d.,]+)',
        "hesaplanan_kv": r'(?:Hesaplanan\s*Kurumlar\s*Vergisi|Hesaplanan\s*KV)\s*[:.]*\s*([\d.,]+)',
        "indirimli_matrah": r'(?:.ndirimli\s*Kurumlar\s*Vergisine\s*Tabi\s*Matrah|[İI]ndirimli\s*(?:Oran\s*)?(?:Uygulanacak\s*)?Matrah|1063)\s*[:.]*\s*([\d.,]+)',
        "indirimli_kv_orani": r'.ndirimli\s*Kurumlar\s*Vergisi\s*Oran.\s*([\d.,]+)',
        "normal_matrah": r'(?:Genel\s*Orana\s*Tabi\s*Matrah|(?:Normal|Genel)\s*Oran\s*(?:Uygulanacak\s*)?Matrah|1064)\s*[:.]*\s*([\d.,]+)',
        "indirimli_kv": r'(?:Hesaplanan\s*.ndirimli\s*(?:KV|Kurumlar\s*Vergisi)|[İI]ndirimli\s*Oran\s*Hesaplanan\s*(?:KV|Vergi)|1065)\s*[:.]*\s*([\d.,]+)',
        "gecmis_zarar": r'(?:Ge[cç]mi[sş]\s*Y[ıi]l\s*Zarar|Mahsup\s*Edilen\s*Zarar)\s*[:.]*\s*([\d.,]+)',
        "istisna_kazanc": r'(?:[İI]stisna\s*(?:ve\s*[İI]ndirim)?\s*Toplam|[İI]stisna\s*Kazan[cç])\s*[:.]*\s*([\d.,]+)',
    }

    # Firma bilgileri icin anahtar kelimeler (pdfplumber encoding'e uyumlu)
    FIRMA_PATTERNS = {
        "vkn": r'Vergi\s*Kimlik\s*Numaras.\s*(\d{10,11})',
        "vergi_dairesi": r'(\S+\s*(?:VD|V\.?D\.?|VERG.\s*DA.RES.))',
    }

    @staticmethod
    def _unvan_bul(full_text):
        """Beyannameden firma unvanini cikar (Soyadi/Unvan + Adi/Devam)."""
        unvan_parts = []
        # Soyadi (Unvani) satiri — encoding esnek
        m1 = re.search(r'Soyad.\s*\(Unvan.\)\s*(.+?)(?:\n|$)', full_text)
        if m1:
            unvan_parts.append(m1.group(1).strip())
        # Adi (Unvanin Devami) satiri — .n yerine .{1,2}n ile esnek
        m2 = re.search(r'Ad.\s*\(Unvan.{1,3}n\s*Devam.\)\s*(.+?)(?:\n|$)', full_text)
        if m2:
            devam = m2.group(1).strip()
            if devam:
                unvan_parts.append(devam)
        return " ".join(unvan_parts).strip() if unvan_parts else ""

    # Indirimli KV Tablosu parse pattern'leri (Sayfa 9 benzeri)
    # NOT: Bazi degerler alt satirda olabiliyor, \n ile eslestirme yapilir
    IKV_PATTERNS = {
        "ikv_belge_no": r'Te.vik\s*Belgesi\s*Numaras.\s*(\d+)',
        "ikv_karar": r'Te.vik\s*Belgesinin\s*Hangi\s*Karara.*?(\d{4}/\d+)',
        "ikv_baslama": r'Yat.r.ma\s*Ba.lama\s*Tarihi\s*(\d{2}/\d{2}/\d{4})',
        "ikv_yatirim_turu1": r'Yat.r.m.n\s*T.r.\s*1\s*(.+?)(?:\n|$)',
        "ikv_yatirim_turu2": r'Yat.r.m.n\s*T.r.\s*2\s*(.+?)(?:\n|$)',
        "ikv_toplam_yatirim": r'Toplam\s*Yat.r.m\s*Tutar.\s*\(.*?\n([\d.,]+)',
        "ikv_katki_orani": r'Yat.r.ma\s*Katk.\s*Oran.\s*(\d+)',
        "ikv_indirim_orani": r'Vergi\s*.ndirim\s*Oran.\s*(\d+)',
        "ikv_bolge": r'Yat.r.m.n\s*Yap.ld...\s*B.lge\s*(\d+)',
        "ikv_indirimli_kv_orani": r'.ndirimli\s*KV\s*Oran.\s*(\d+)',
        "ikv_toplam_ykt": r'Toplam\s*Yat.r.ma\s*Katk.\s*Tutar.\s*([\d.,]+)',
        "ikv_cari_harcama": r'Cari\s*Y.lda\s*Fiilen\s*Ger.ekle.tirilen\s*Yat.r.m\s*Harcamas.\s*Tutar.\s*([\d.,]+)',
        "ikv_kumulatif_harcama": r'Fiilen\s*Ger.ekle.tirilen\s*Yat.r.m\s*Harcamas.\n([\d.,]+)',
        "ikv_hak_kazanilan_ykt": r'Fiili\s*Yat.r.m\s*Harcamas.\s*Nedeniyle\n([\d.,]+)',
        "ikv_endeks_ykt": r'Endekslenmi.\s*Tutarlar\s*Nedeniyle\s*Hak\s*Kazan.lan.*?Tutar.\s*([\d.,]+)',
        "ikv_onceki_ykt_toplam": r'.nceki\s*D.nemlerde\s*Yararlan.lan\s*Toplam.*?Tutar.\s*([\d.,]+)',
        "ikv_cari_ykt_toplam": r'Cari\s*D.nemde\s*Yararlan.lan\s*Toplam.*?Tutar.\s*([\d.,]+)',
        "ikv_toplam_yararlanan": r'Cari\s*D.nem\s*Dahil\s*Olmak\s*.zere\s*Yararlan.lan\n([\d.,]+)',
    }

    # Onceki/Cari donem YKT detay (deger alt satirda, aciklama alt satirda)
    IKV_MULTILINE_PATTERNS = {
        "ikv_onceki_ykt_yatirim": (r'.nceki\s*D.nemlerde\s*Yararlan.lan.*?Tutar.\n([\d.,]+)\n\(Yat.r.mdan', re.DOTALL),
        "ikv_onceki_ykt_diger": (r'.nceki\s*D.nemlerde\s*Yararlan.lan.*?Tutar.\n([\d.,]+)\n\(Di.er', re.DOTALL),
        "ikv_cari_ykt_yatirim": (r'Cari\s*D.nemde\s*Yararlan.lan.*?Tutar.\n([\d.,]+)\n\(Yat.r.mdan', re.DOTALL),
        "ikv_cari_ykt_diger": (r'Cari\s*D.nemde\s*Yararlan.lan.*?Tutar.\n([\d.,]+)\n\(Di.er', re.DOTALL),
    }

    # YKT tablosu icin anahtar kelimeler
    YKT_PATTERNS = {
        "belge_no": r'(?:Belge\s*No|Teşvik\s*Belge)\s*[:.]*\s*(\d[\d/\-]*)',
        "toplam_ykt": r'(?:Toplam\s*Yat[ıi]r[ıi]ma\s*Katk[ıi]|Toplam\s*YKT)\s*[:.]*\s*([\d.,]+)',
        "donemde_kullanilan": r'(?:D[öo]nemde\s*Kullan[ıi]lan|Cari\s*D[öo]nem)\s*[:.]*\s*([\d.,]+)',
        "kumulatif_kullanilan": r'(?:K[üu]m[üu]latif\s*Kullan[ıi]lan|Toplam\s*Kullan[ıi]lan)\s*[:.]*\s*([\d.,]+)',
        "kalan_ykt": r'(?:Kalan\s*(?:YKT|Katk[ıi])|Devreden)\s*[:.]*\s*([\d.,]+)',
    }

    @staticmethod
    def parse(pdf_path):
        """PDF'den beyanname verilerini cikarir."""
        if not PDF_OK:
            return {"hata": "pdfplumber yuklu degil. pip install pdfplumber"}

        result = {"dosya": str(pdf_path), "ham_metin": "", "veriler": {}, "ykt_tablosu": [],
                  "tablolar": []}
        try:
            with pdfplumber.open(pdf_path) as pdf:
                pages_text = []
                for page in pdf.pages:
                    txt = page.extract_text() or ""
                    pages_text.append(txt)
                    # Tablolari da cikar
                    for tbl in (page.extract_tables() or []):
                        result["tablolar"].append(tbl)
                full_text = "\n".join(pages_text)
                result["ham_metin"] = full_text

                # Firma bilgilerini cikar
                for key, pattern in BeyannameParser.FIRMA_PATTERNS.items():
                    m = re.search(pattern, full_text, re.IGNORECASE)
                    if m:
                        result["veriler"][key] = m.group(1).strip()

                # Unvan (Soyadi + Adi/Devami)
                unvan = BeyannameParser._unvan_bul(full_text)
                if unvan:
                    result["veriler"]["unvan"] = unvan

                # Indirimli KV Tablosu verilerini cikar
                for key, pattern in BeyannameParser.IKV_PATTERNS.items():
                    m = re.search(pattern, full_text, re.IGNORECASE)
                    if m:
                        val = m.group(1).strip()
                        if key in ("ikv_belge_no", "ikv_karar", "ikv_baslama",
                                   "ikv_yatirim_turu1", "ikv_yatirim_turu2"):
                            result["veriler"][key] = val
                        else:
                            result["veriler"][key] = pt(val)

                # Multiline IKV pattern'leri (deger alt satirda)
                for key, (pattern, flags) in BeyannameParser.IKV_MULTILINE_PATTERNS.items():
                    m = re.search(pattern, full_text, re.IGNORECASE | flags)
                    if m:
                        result["veriler"][key] = pt(m.group(1).strip())

                # Ana verileri regex ile cikar
                for key, pattern in BeyannameParser.PATTERNS.items():
                    m = re.search(pattern, full_text, re.IGNORECASE)
                    if m:
                        val = m.group(1)
                        if key == "donem_yil":
                            result["veriler"][key] = int(val)
                        else:
                            result["veriler"][key] = pt(val)

                # YKT tablosunu cikar
                for key, pattern in BeyannameParser.YKT_PATTERNS.items():
                    m = re.search(pattern, full_text, re.IGNORECASE)
                    if m:
                        val = m.group(1)
                        result["veriler"]["ykt_" + key] = pt(val) if key != "belge_no" else val

                # Tablo verilerinden YKT satirlarini bul
                result["ykt_tablosu"] = BeyannameParser._ykt_tablo_bul(result["tablolar"])

        except Exception as e:
            result["hata"] = str(e)
        return result

    @staticmethod
    def _ykt_tablo_bul(tablolar):
        """Tablolardan YKT satirlarini tespit et."""
        ykt_rows = []
        for tbl in tablolar:
            if not tbl:
                continue
            for row in tbl:
                if not row:
                    continue
                row_text = " ".join(str(c or "") for c in row).lower()
                if any(kw in row_text for kw in ["katkı", "katki", "ykt", "teşvik", "tesvik",
                                                  "indirimli", "belge"]):
                    ykt_rows.append([str(c or "").strip() for c in row])
        return ykt_rows

    @staticmethod
    def matrahtan_ykt_hesapla(indirimli_matrah, normal_kv_orani, indirimli_kv_orani):
        """Matrahtan kullanilan YKT = indirimli_matrah * (normal_oran - indirimli_oran) / 100"""
        if indirimli_matrah <= 0 or normal_kv_orani <= 0:
            return 0.0
        fark = normal_kv_orani - indirimli_kv_orani
        return round(indirimli_matrah * fark / 100, 2)


# ============================================================================
# TESVIK BELGESI WORD PARSER
# ============================================================================

class TesvikBelgesiParser:
    """Yatirim Tesvik Belgesi Word dosyasindan veri cikarir."""

    FIELD_PATTERNS = {
        "belge_no": [
            r'(?:Belge\s*No|Belge\s*Numaras[ıi])\s*[:.]\s*([\d/\-]+)',
            r'(\d{6,}[/\-]\d+)',
        ],
        "belge_tarihi": [
            r'(?:Belge\s*Tarih|D[üu]zenleme\s*Tarih)\s*[:.]\s*(\d{2}[./]\d{2}[./]\d{4})',
        ],
        "yatirim_konusu": [
            r'(?:Yat[ıi]r[ıi]m\s*Konusu|Yat[ıi]r[ıi]m[ıi]n\s*Konusu)\s*[:.]\s*(.+?)(?:\n|$)',
        ],
        "yatirim_turu": [
            r'(?:Yat[ıi]r[ıi]m[ıi]n?\s*(?:Cinsi|T[üu]r[üu]))\s*[:.]\s*(.+?)(?:\n|$)',
        ],
        "yatirim_yeri": [
            r'(?:Yat[ıi]r[ıi]m\s*Yeri|Yat[ıi]r[ıi]m[ıi]n\s*Yeri)\s*[:.]\s*(.+?)(?:\n|$)',
        ],
        "toplam_sabit_yatirim": [
            r'(?:Toplam\s*Sabit\s*Yat[ıi]r[ıi]m|Sabit\s*Yat[ıi]r[ıi]m\s*Tutar)\s*[:.]\s*([\d.,]+)',
        ],
        "baslama_tarihi": [
            r'(?:Ba[şs]lama\s*Tarih|Yat[ıi]r[ıi]ma\s*Ba[şs]lama)\s*[:.]\s*(\d{2}[./]\d{2}[./]\d{4})',
        ],
        "bitis_tarihi": [
            r'(?:Biti[şs]\s*Tarih|Tamamlama\s*Tarih|Yat[ıi]r[ıi]m\s*S[üu]resi\s*Sonu)\s*[:.]\s*(\d{2}[./]\d{2}[./]\d{4})',
        ],
        "katki_orani": [
            r'(?:Yat[ıi]r[ıi]ma\s*Katk[ıi]\s*Oran|YKO)\s*[:.]\s*[%]?\s*([\d.,]+)',
        ],
        "indirim_orani": [
            r'(?:Vergi\s*[İI]ndirim\s*Oran|V[İI]O)\s*[:.]\s*[%]?\s*([\d.,]+)',
        ],
        "tesvik_unsuru": [
            r'(?:Te[şs]vik\s*Unsur|Destek\s*Unsur)\s*[:.]\s*(.+?)(?:\n|$)',
        ],
    }

    # Bolge tespiti icin il-bolge eslemesi
    BOLGE_MAP = {
        1: ["ankara", "antalya", "bursa", "eskisehir", "istanbul", "izmir",
            "kocaeli", "mugla", "tekirdag"],
        2: ["adana", "aydin", "bolu", "canakkale", "denizli", "edirne",
            "isparta", "kayseri", "kirklareli", "konya", "manisa",
            "mersin", "sakarya", "trabzon", "yalova"],
        3: ["balikesir", "bilecik", "burdur", "gaziantep", "karabuk",
            "karaman", "kirikkale", "kutahya", "rize", "samsun",
            "usak", "zonguldak"],
        4: ["afyon", "amasya", "artvin", "bartin", "corum", "duzce",
            "elazig", "erzincan", "hatay", "kastamonu", "kirsehir",
            "malatya", "nevsehir", "nigde", "ordu", "sinop",
            "sivas", "tokat", "tunceli", "yozgat"],
        5: ["adiyaman", "aksaray", "bayburt", "erzurum", "giresun",
            "gumushane", "kahramanmaras", "kars", "kilis",
            "osmaniye", "ardahan", "igdir"],
        6: ["agri", "batman", "bingol", "bitlis", "diyarbakir",
            "hakkari", "mardin", "mus", "sanliurfa", "siirt",
            "sirnak", "van"],
    }

    @staticmethod
    def parse(docx_path):
        """Word dosyasindan tesvik belgesi verilerini cikarir."""
        if not DOCX_OK:
            return {"hata": "python-docx yuklu degil. pip install python-docx"}

        result = {"dosya": str(docx_path), "ham_metin": "", "veriler": {},
                  "tablolar": [], "bolge_tahmini": None}
        try:
            doc = docx.Document(docx_path)

            # Paragraflardan metin cikar
            paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
            full_text = "\n".join(paragraphs)

            # Tablolardan da metin cikar
            tablo_metinleri = []
            for table in doc.tables:
                tbl_data = []
                for row in table.rows:
                    row_data = [cell.text.strip() for cell in row.cells]
                    tbl_data.append(row_data)
                    tablo_metinleri.append(" ".join(row_data))
                result["tablolar"].append(tbl_data)

            full_text += "\n" + "\n".join(tablo_metinleri)
            result["ham_metin"] = full_text

            # Alanlari regex ile cikar
            for field_name, patterns in TesvikBelgesiParser.FIELD_PATTERNS.items():
                for pattern in patterns:
                    m = re.search(pattern, full_text, re.IGNORECASE)
                    if m:
                        val = m.group(1).strip()
                        if field_name in ("toplam_sabit_yatirim", "katki_orani", "indirim_orani"):
                            result["veriler"][field_name] = pt(val)
                        else:
                            result["veriler"][field_name] = val
                        break

            # Yatirim turu esle
            yt = result["veriler"].get("yatirim_turu", "").lower()
            if "komple" in yt:
                result["veriler"]["yatirim_turu_mapped"] = "Komple Yeni"
            elif "tevsi" in yt:
                result["veriler"]["yatirim_turu_mapped"] = "Tevsi"
            elif "modern" in yt:
                result["veriler"]["yatirim_turu_mapped"] = "Modernizasyon"
            elif any(k in yt for k in ["ürün", "urun", "çeşit", "cesit"]):
                result["veriler"]["yatirim_turu_mapped"] = "Urun Cesitlendirme"
            elif "entegrasyon" in yt:
                result["veriler"]["yatirim_turu_mapped"] = "Entegrasyon"

            # Bolge tahmini: yatirim yerinden il bul
            yeri = result["veriler"].get("yatirim_yeri", "").lower()
            yeri = yeri.replace("İ", "i").replace("ı", "i").replace("ö", "o") \
                       .replace("ü", "u").replace("ş", "s").replace("ç", "c") \
                       .replace("ğ", "g").replace("Ş", "s").replace("Ç", "c")
            for bolge, iller in TesvikBelgesiParser.BOLGE_MAP.items():
                for il in iller:
                    if il in yeri:
                        result["bolge_tahmini"] = bolge
                        break
                if result["bolge_tahmini"]:
                    break

            # Tablo verilerinden sabit yatirim detaylari cikar
            for tbl in result["tablolar"]:
                for row in tbl:
                    row_lower = " ".join(r.lower() for r in row if r)
                    if "makine" in row_lower or "tesis" in row_lower:
                        for cell in row:
                            v = pt(cell)
                            if v > 0:
                                result["veriler"].setdefault("makine_tutar_tablo", v)
                    if any(k in row_lower for k in ["bina", "inşaat", "insaat"]):
                        for cell in row:
                            v = pt(cell)
                            if v > 0:
                                result["veriler"].setdefault("insaat_tutar_tablo", v)

        except Exception as e:
            result["hata"] = str(e)
        return result


# ============================================================================
# VERI YAPILARI
# ============================================================================

@dataclass
class TesvikBelgesi:
    belge_no: str = ""; belge_tarihi: str = ""
    yatirim_turu: str = "Komple Yeni"; tesvik_turu: str = "Bolgesel Tesvik"
    karar_turu: str = "2012/3305 sayili BKK"; bolge: int = 1
    yatirim_konusu: str = ""; imalat_sanayi: bool = False
    osb_icerisinde: bool = False  # OSB'de ek 1 bolge avantaji
    toplam_sabit_yatirim: float = 0.0
    katki_orani: float = 0.0; indirim_orani: float = 0.0; yatirim_donemi_orani: float = 0.0
    baslama_tarihi: str = ""; tamamlama_tarihi: str = ""; kismen_isletme_tarihi: str = ""
    tamamlama_vizesi: str = "Devam Ediyor"  # Devam Ediyor / Tamamlandi / Sure Uzatmasi
    yuzde_100_indirim: bool = False
    belge_insaat_tutari: float = 0.0; belge_makine_tutari: float = 0.0
    gerceklesen_insaat: float = 0.0; gerceklesen_makine: float = 0.0
    nakdi_sermaye: bool = False
    nakdi_sermaye_tutari: float = 0.0; nakdi_sermaye_tarihi: str = ""

@dataclass
class DonemselHarcama:
    yil: int = 2024; gecici_donem: str = "Yillik"
    toplam_harcama: float = 0.0; makine_techizat: float = 0.0
    bina_insaat: float = 0.0; arazi_arsa: float = 0.0; diger_harcama: float = 0.0
    kur_farki_finansman: float = 0.0; finansal_kiralama: float = 0.0
    avans_odemeleri: float = 0.0; kapsam_disi: float = 0.0

    @property
    def uygun_harcama(self):
        """KVK 32/A katkı hesabına konu olabilecek harcama tutarı."""
        uygun = self.makine_techizat + self.bina_insaat + self.finansal_kiralama + self.avans_odemeleri
        if uygun <= 0 and self.toplam_harcama > 0:
            uygun_olmayan = self.arazi_arsa + self.kur_farki_finansman + self.kapsam_disi
            uygun = self.toplam_harcama - uygun_olmayan
        return max(0.0, uygun)

@dataclass
class TevsiVerileri:
    mevcut_sabit_kiymet: float = 0.0; tevsi_aktif_kiymet: float = 0.0
    tevsi_orani_manuel: Optional[float] = None
    yeniden_degerleme: bool = False; yeniden_degerli_tutar: float = 0.0
    tevsi_hasilat: float = 0.0; toplam_hasilat: float = 0.0

@dataclass
class KazancMatrah:
    yil: int = 2024; gecici_donem: str = "Yillik"; donem_turu: str = "Isletme"
    ticari_kar: float = 0.0; kkeg: float = 0.0; istisna_kazanclar: float = 0.0
    gecmis_yil_zarari: float = 0.0; kv_matrahi: float = 0.0
    yatirim_kazanci: float = 0.0; diger_faaliyet_kazanci: float = 0.0
    ihracat_kazanci: float = 0.0; uretim_kazanci: float = 0.0
    gerceklesen_harcama_kumulatif: float = 0.0  # B grubu kumulatif

@dataclass
class IstisnaEtkilesim:
    # Asgari KV (32/C) detay
    asgari_kv_matrahi: float = 0.0
    asgari_kv_orani: float = 10.0  # 2025: %10
    asgari_kv_istisna_tutar: float = 0.0  # asgari KV'den istisna
    # Istisna kazanclar
    kvk_5_1_e_istisna: float = 0.0  # Gayrimenkul satis kazanci
    kvk_5_1_d_istisna: float = 0.0  # Yatirim fon/ortaklik kazanci
    kvk_5_b_istisna: float = 0.0  # Sinai mulkiyet haklari
    serbest_bolge_istisna: float = 0.0  # 3218 sayili Kanun
    teknokent_istisna: float = 0.0  # 4691 sayili Kanun
    arge_indirimi: float = 0.0  # 5746 sayili Kanun
    kvk_10_1_h_indirimi: float = 0.0  # Nakdi sermaye artisi indirimi
    yillara_yaygin_insaat: float = 0.0
    diger_istisna: float = 0.0  # Diger istisna/indirimler

@dataclass
class DevredenKatki:
    devreden_katki: float = 0.0; devreden_yil: int = 0
    yufe_harcama_ayi: float = 0.0; yufe_kullanim_donemi: float = 0.0
    yatirim_doneminde_kullanilan: float = 0.0; isletme_doneminde_kullanilan: float = 0.0

@dataclass
class OzelDurumlar:
    satis_var: bool = False; satis_tarihi: str = ""; satis_tutari: float = 0.0
    devir_var: bool = False; sat_kirala_geri_al: bool = False
    belge_revize: bool = False; revize_tarihi: str = ""; revize_aciklama: str = ""
    iptal_var: bool = False; iptal_tarihi: str = ""
    sure_uzatma_var: bool = False; sure_uzatma_tarihi: str = ""
    kismi_tamamlama: bool = False

@dataclass
class DonemHesapSonuc:
    donem_adi: str = ""; donem_turu: str = ""; yil: int = 0
    kazanc: float = 0.0; kv_orani: float = 25.0
    gerceklesen_harcama_kum: float = 0.0  # kitap: 2. sinir
    sinir1_ykt: float = 0.0  # kitap: 1. sinir
    sinir2_harcama: float = 0.0  # kitap: 2. sinir
    kullanilan_sinir: float = 0.0  # min(sinir1, sinir2)
    sk_tevsi_orani: Optional[float] = None
    sk_indirimli_matrah: float = 0.0; sk_indirimli_kv: float = 0.0
    sk_normal_kv: float = 0.0; sk_toplam_kv: float = 0.0; sk_katki_kullanimi: float = 0.0
    sk_genel_matrah: float = 0.0
    hs_tevsi_orani: Optional[float] = None
    hs_indirimli_matrah: float = 0.0; hs_indirimli_kv: float = 0.0
    hs_normal_kv: float = 0.0; hs_toplam_kv: float = 0.0; hs_katki_kullanimi: float = 0.0
    hs_genel_matrah: float = 0.0
    ihracat_indirim_tutari: float = 0.0; uretim_indirim_tutari: float = 0.0
    istisna_dusulecek: float = 0.0
    # Asgari KV (32/C)
    asgari_kv: float = 0.0; asgari_kv_orani: float = 0.0
    asgari_kv_farki: float = 0.0  # Asgari KV - Hesaplanan KV (pozitifse ek odeme)
    # Endeks & Kalan
    endeks_eklenen: float = 0.0; kalan_katki: float = 0.0
    # Beyanname kodlari
    beyanname_1063: float = 0.0  # Indirimli KV matrahi
    beyanname_1064: float = 0.0  # Normal KV matrahi
    beyanname_1065: float = 0.0  # Indirimli KV tutari
    # Sure siniri uyarisi
    sure_siniri_uyari: str = ""


# ============================================================================
# FIRMA KAYIT SISTEMI
# ============================================================================

class FirmaVeriYoneticisi:
    """Firma bazli JSON kaydetme/yukleme."""

    def __init__(self):
        self.klasor = VERI_KLASORU
        self.klasor.mkdir(parents=True, exist_ok=True)

    def firma_listesi(self):
        firmalar = []
        for f in sorted(self.klasor.glob("*.json")):
            try:
                with open(f, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                    firmalar.append(data.get("firma_adi", f.stem))
            except Exception:
                firmalar.append(f.stem)
        return firmalar

    def firma_dosya(self, firma_adi):
        safe = "".join(c if c.isalnum() or c in "_ -" else "_" for c in firma_adi)
        return self.klasor / f"{safe}.json"

    def kaydet(self, firma_adi, veri_dict):
        veri_dict["firma_adi"] = firma_adi
        dosya = self.firma_dosya(firma_adi)
        with open(dosya, "w", encoding="utf-8") as f:
            json.dump(veri_dict, f, ensure_ascii=False, indent=2, default=str)
        return dosya

    def yukle(self, firma_adi):
        dosya = self.firma_dosya(firma_adi)
        if not dosya.exists():
            return None
        with open(dosya, "r", encoding="utf-8") as f:
            return json.load(f)

    def sil(self, firma_adi):
        dosya = self.firma_dosya(firma_adi)
        if dosya.exists():
            dosya.unlink()


# ============================================================================
# HESAPLAMA MOTORU
# ============================================================================

class HesaplamaMotoru:
    def __init__(self, belge: TesvikBelgesi):
        self.belge = belge
        ek = NAKDI_SERMAYE_EK_KATKI if belge.nakdi_sermaye else 0
        # OSB icerisinde: bolgesel tesviklerde ek 1 bolge avantaji (oranlar zaten girilmis olabilir)
        self.osb_ek_puan = belge.osb_icerisinde  # bilgi icin sakla
        self.efektif_katki_orani = belge.katki_orani + ek
        self.katki_tutari = round(belge.toplam_sabit_yatirim * self.efektif_katki_orani / 100, 2)
        self.kullanilan_katki_yatirim = 0.0
        self.kullanilan_katki_isletme = 0.0
        self.endeks_toplam = 0.0
        self.donemler: list[DonemHesapSonuc] = []
        self.tevsi = TevsiVerileri()
        self.devreden = DevredenKatki()
        self.istisna = IstisnaEtkilesim()
        self.harcamalar: list[DonemselHarcama] = []
        self.ozel = OzelDurumlar()

    @property
    def kullanilan_katki(self):
        return self.kullanilan_katki_yatirim + self.kullanilan_katki_isletme

    @property
    def toplam_katki(self):
        return self.katki_tutari + self.endeks_toplam + self.devreden.devreden_katki

    @property
    def kalan_katki(self):
        return max(0, self.toplam_katki - self.kullanilan_katki)

    @property
    def kumulatif_harcama(self):
        return sum(h.uygun_harcama for h in self.harcamalar)

    @property
    def kumulatif_toplam_harcama(self):
        return sum(h.toplam_harcama for h in self.harcamalar)

    def indirimli_kv_orani(self, yil_kv_orani=None):
        kv = yil_kv_orani or VARSAYILAN_KV_ORANI
        oran = 100 if self.belge.yuzde_100_indirim else self.belge.indirim_orani
        return round(kv * (1 - oran / 100), 4)

    def endeksle_yufe(self, yufe_h, yufe_k):
        kalan = self.kalan_katki
        if kalan <= 0 or yufe_h <= 0 or yufe_k <= yufe_h: return 0
        eklenen = round(kalan * (yufe_k - yufe_h) / yufe_h, 2)
        self.endeks_toplam += eklenen
        return eklenen

    def endeksle_ydo(self, ydo):
        kalan = self.kalan_katki
        if kalan <= 0 or ydo <= 0: return 0
        eklenen = round(kalan * ydo / 100, 2)
        self.endeks_toplam += eklenen
        return eklenen

    def donem_hesapla(self, kd: KazancMatrah, endeks_ydo=0.0,
                      yufe_h=0.0, yufe_k=0.0,
                      istisna: Optional[IstisnaEtkilesim] = None):
        # Endeksleme
        endeks_eklenen = 0.0
        if yufe_h > 0 and yufe_k > yufe_h:
            endeks_eklenen = self.endeksle_yufe(yufe_h, yufe_k)
        elif endeks_ydo > 0:
            endeks_eklenen = self.endeksle_ydo(endeks_ydo)

        yil = kd.yil
        kv_or = kv_orani_yil(yil)
        ind_kv = self.indirimli_kv_orani(kv_or)
        hesaplanan = kd.ticari_kar + kd.kkeg - kd.istisna_kazanclar - kd.gecmis_yil_zarari
        kazanc = kd.kv_matrahi if kd.kv_matrahi > 0 else max(0, hesaplanan)
        yatirim_kazanci_girdi = max(0, kd.yatirim_kazanci)
        diger_kazanc_girdi = max(0, kd.diger_faaliyet_kazanci)
        kazanc_ayrimi_var = yatirim_kazanci_girdi > 0 or diger_kazanc_girdi > 0
        ist = istisna or self.istisna
        istisna_dusulecek = (ist.kvk_5_1_e_istisna + ist.kvk_5_1_d_istisna +
                             ist.kvk_5_b_istisna + ist.serbest_bolge_istisna +
                             ist.teknokent_istisna + ist.arge_indirimi +
                             ist.kvk_10_1_h_indirimi + ist.diger_istisna)

        donem_adi = f"{yil}"
        if kd.gecici_donem != "Yillik": donem_adi += f" {kd.gecici_donem}"

        # ====================================================================
        # KITAP: IKI SINIR KURALI
        # 1. sinir: Toplam YKT * yatirim donemi orani (yatirim doneminde)
        # 2. sinir: Gerceklestirilen yatirim harcamasi (kumulatif)
        # Her iki sinirdan kucuk olani kullanilir
        # ====================================================================
        sinir1_ykt = self.katki_tutari * self.belge.yatirim_donemi_orani / 100
        sinir2_harcama = kd.gerceklesen_harcama_kumulatif if kd.gerceklesen_harcama_kumulatif > 0 else self.kumulatif_harcama

        sonuc = DonemHesapSonuc(
            donem_adi=donem_adi, donem_turu=kd.donem_turu, yil=yil,
            kazanc=kazanc, kv_orani=kv_or,
            gerceklesen_harcama_kum=sinir2_harcama,
            sinir1_ykt=sinir1_ykt, sinir2_harcama=sinir2_harcama,
            istisna_dusulecek=istisna_dusulecek, endeks_eklenen=endeks_eklenen,
        )

        if kazanc <= 0:
            sonuc.kalan_katki = self.kalan_katki
            self.donemler.append(sonuc); return sonuc

        kalan = self.kalan_katki
        if kalan <= 0:
            nkv = round(kazanc * kv_or / 100, 2)
            sonuc.sk_normal_kv = nkv; sonuc.sk_toplam_kv = nkv
            sonuc.hs_normal_kv = nkv; sonuc.hs_toplam_kv = nkv
            sonuc.kalan_katki = 0
            self.donemler.append(sonuc); return sonuc

        # Kullanilabilir katki
        if kd.donem_turu == "Yatirim":
            # Kitaptaki iki sinir: min(sinir1, sinir2)
            ust_sinir = min(sinir1_ykt, sinir2_harcama) if sinir2_harcama > 0 else sinir1_ykt
            sonuc.kullanilan_sinir = ust_sinir
            kullanilabilir = min(kalan, max(0, ust_sinir - self.kullanilan_katki_yatirim))
        else:
            kullanilabilir = kalan

        normal_kv_tam = round(kazanc * kv_or / 100, 2)
        fark_oran = (kv_or - ind_kv) / 100

        # SK Yontemi
        sk_kazanc = kazanc
        sk_genel_matrah = 0.0
        if kd.donem_turu == "Isletme" and kazanc_ayrimi_var:
            sk_kazanc = min(kazanc, yatirim_kazanci_girdi)
            sk_genel_matrah = max(0, kazanc - sk_kazanc)
        sk = self._yontem(sk_kazanc, kullanilabilir, kv_or, ind_kv, fark_oran,
                          self.tevsi.tevsi_aktif_kiymet,
                          self.tevsi.mevcut_sabit_kiymet + self.tevsi.tevsi_aktif_kiymet)
        sk["toplam_kv"] = round(sk["toplam_kv"] + sk_genel_matrah * kv_or / 100, 2)
        sk["genel_matrah"] = round(sk_genel_matrah + sk.get("normal_matrah", 0), 2)
        sonuc.sk_tevsi_orani = sk["tevsi_orani"]; sonuc.sk_indirimli_matrah = sk["indirimli_matrah"]
        sonuc.sk_indirimli_kv = sk["indirimli_kv"]; sonuc.sk_normal_kv = normal_kv_tam
        sonuc.sk_toplam_kv = sk["toplam_kv"]; sonuc.sk_katki_kullanimi = sk["katki_kullanimi"]
        sonuc.sk_genel_matrah = sk["genel_matrah"]

        # HS Yontemi
        hs_kazanc = kazanc
        hs_genel_matrah = 0.0
        if kd.donem_turu == "Isletme" and kazanc_ayrimi_var:
            hs_kazanc = min(kazanc, yatirim_kazanci_girdi)
            hs_genel_matrah = max(0, kazanc - hs_kazanc)
        hs = self._yontem(hs_kazanc, kullanilabilir, kv_or, ind_kv, fark_oran,
                          self.tevsi.tevsi_hasilat, self.tevsi.toplam_hasilat)
        hs["toplam_kv"] = round(hs["toplam_kv"] + hs_genel_matrah * kv_or / 100, 2)
        hs["genel_matrah"] = round(hs_genel_matrah + hs.get("normal_matrah", 0), 2)
        sonuc.hs_tevsi_orani = hs["tevsi_orani"]; sonuc.hs_indirimli_matrah = hs["indirimli_matrah"]
        sonuc.hs_indirimli_kv = hs["indirimli_kv"]; sonuc.hs_normal_kv = normal_kv_tam
        sonuc.hs_toplam_kv = hs["toplam_kv"]; sonuc.hs_katki_kullanimi = hs["katki_kullanimi"]
        sonuc.hs_genel_matrah = hs["genel_matrah"]

        if kd.ihracat_kazanci > 0:
            sonuc.ihracat_indirim_tutari = round(min(kd.ihracat_kazanci, kazanc) * IHRACAT_URETIM_INDIRIM / 100, 2)
        if kd.uretim_kazanci > 0:
            sonuc.uretim_indirim_tutari = round(min(kd.uretim_kazanci, kazanc) * URETIM_INDIRIM / 100, 2)

        # Asgari KV (32/C) hesaplama — 2025+
        if yil >= 2025:
            akv_orani = ist.asgari_kv_orani or ASGARI_KV_ORANI.get(yil, ASGARI_KV_VARSAYILAN)
            sonuc.asgari_kv_orani = akv_orani
            if ist.asgari_kv_matrahi > 0:
                asgari_kv_ham = round(ist.asgari_kv_matrahi * akv_orani / 100, 2)
                asgari_kv_net = max(0, asgari_kv_ham - ist.asgari_kv_istisna_tutar)
                sonuc.asgari_kv = asgari_kv_net
                # Hesaplanan KV ile karsilastir (SK yontemi baz)
                sonuc.asgari_kv_farki = max(0, round(asgari_kv_net - sk["toplam_kv"], 2))

        # Beyanname kodlari (SK yontemi baz)
        sonuc.beyanname_1063 = round(sk["indirimli_matrah"], 2)
        sonuc.beyanname_1064 = round(kazanc - sk["indirimli_matrah"], 2)
        sonuc.beyanname_1065 = round(sk["indirimli_matrah"] * ind_kv / 100, 2)

        # 10 yil sure siniri kontrolu
        if self.belge.belge_tarihi:
            try:
                from datetime import datetime
                bt = datetime.strptime(self.belge.belge_tarihi, "%d.%m.%Y")
                bitis = bt.year + YATIRIM_SURESI_YIL
                if yil > bitis:
                    sonuc.sure_siniri_uyari = f"UYARI: {YATIRIM_SURESI_YIL} yil suresi asildi (belge: {self.belge.belge_tarihi})"
            except (ValueError, TypeError):
                pass

        if kd.donem_turu == "Yatirim":
            self.kullanilan_katki_yatirim += sk["katki_kullanimi"]
        else:
            self.kullanilan_katki_isletme += sk["katki_kullanimi"]

        sonuc.kalan_katki = self.kalan_katki
        self.donemler.append(sonuc); return sonuc

    def _yontem(self, kazanc, kullanilabilir, kv_or, ind_kv, fark_oran, t_pay, t_payda):
        r = {"tevsi_orani": None, "indirimli_matrah": 0, "indirimli_kv": 0,
             "toplam_kv": 0, "katki_kullanimi": 0, "normal_matrah": 0}
        yt = YATIRIM_TURU_MAP.get(self.belge.yatirim_turu, "komple")
        is_tevsi = yt in ("tevsi", "modernizasyon", "urun_cesitlendirme")
        if is_tevsi and t_pay and t_payda and t_payda > 0:
            oran = t_pay / t_payda
            r["tevsi_orani"] = round(oran * 100, 2)
            ind_matrah = kazanc * oran
        else:
            ind_matrah = kazanc
        pot = round(ind_matrah * fark_oran, 2)
        if fark_oran > 0 and pot > kullanilabilir:
            fiili = min(kullanilabilir / fark_oran, ind_matrah); katki = kullanilabilir
        else:
            fiili = ind_matrah; katki = pot
        n_matrah = kazanc - fiili
        ikv = round(fiili * ind_kv / 100, 2); nkv = round(n_matrah * kv_or / 100, 2)
        r["indirimli_matrah"] = round(fiili, 2); r["indirimli_kv"] = ikv
        r["normal_matrah"] = round(n_matrah, 2)
        r["toplam_kv"] = round(ikv + nkv, 2); r["katki_kullanimi"] = round(katki, 2)
        return r

    def sifirla(self):
        self.kullanilan_katki_yatirim = 0.0; self.kullanilan_katki_isletme = 0.0
        self.endeks_toplam = 0.0; self.donemler = []

    def to_dict(self):
        return {
            "belge": asdict(self.belge),
            "efektif_katki_orani": self.efektif_katki_orani,
            "katki_tutari": self.katki_tutari,
            "kullanilan_katki_yatirim": self.kullanilan_katki_yatirim,
            "kullanilan_katki_isletme": self.kullanilan_katki_isletme,
            "endeks_toplam": self.endeks_toplam,
            "donemler": [asdict(d) for d in self.donemler],
            "tevsi": asdict(self.tevsi),
            "devreden": asdict(self.devreden),
            "istisna": asdict(self.istisna),
            "harcamalar": [asdict(h) for h in self.harcamalar],
            "ozel": asdict(self.ozel),
        }

    @classmethod
    def from_dict(cls, d):
        belge = TesvikBelgesi(**d["belge"])
        m = cls(belge)
        m.kullanilan_katki_yatirim = d.get("kullanilan_katki_yatirim", 0)
        m.kullanilan_katki_isletme = d.get("kullanilan_katki_isletme", 0)
        m.endeks_toplam = d.get("endeks_toplam", 0)
        m.donemler = [DonemHesapSonuc(**s) for s in d.get("donemler", [])]
        if "tevsi" in d: m.tevsi = TevsiVerileri(**d["tevsi"])
        if "devreden" in d: m.devreden = DevredenKatki(**d["devreden"])
        if "istisna" in d: m.istisna = IstisnaEtkilesim(**d["istisna"])
        m.harcamalar = [DonemselHarcama(**h) for h in d.get("harcamalar", [])]
        if "ozel" in d: m.ozel = OzelDurumlar(**d["ozel"])
        return m


# ============================================================================
# SCROLLABLE FRAME
# ============================================================================

class ScrollFrame(ttk.Frame):
    def __init__(self, parent, **kw):
        super().__init__(parent, **kw)
        self.canvas = tk.Canvas(self, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = ttk.Frame(self.canvas)
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        self.canvas.bind_all("<MouseWheel>", self._mw)
    def _mw(self, e): self.canvas.yview_scroll(int(-1*(e.delta/120)), "units")


# ============================================================================
# TKINTER GUI
# ============================================================================

class KVKApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("KVK 32/A - Indirimli Kurumlar Vergisi Hesaplama")
        self.geometry("1220x780")
        self.minsize(1050, 680)

        self.motor = None
        self.belgeler = []
        self._donem_girdileri = []
        self.firma_adi = ""
        self._firma_meta = {}  # unvan, vkn, vergi_dairesi
        self.veri_mgr = FirmaVeriYoneticisi()

        st = ttk.Style(self)
        st.configure("Title.TLabel", font=("Segoe UI", 11, "bold"))
        st.configure("Header.TLabel", font=("Segoe UI", 9, "bold"))
        st.configure("Result.TLabel", font=("Segoe UI", 10, "bold"), foreground="#1a5276")
        st.configure("Small.TLabel", font=("Segoe UI", 8), foreground="#666")
        st.configure("YKT.TLabel", font=("Segoe UI", 10, "bold"), foreground="#c0392b")
        st.configure("Info.TLabel", font=("Segoe UI", 9), foreground="#2c3e50")

        self._build_ui()

    def _le(self, p, label, row, col=0, width=20, default="", colspan=1, sticky="ew"):
        ttk.Label(p, text=label).grid(row=row, column=col, sticky="w", padx=3, pady=2)
        e = ttk.Entry(p, width=width)
        e.grid(row=row, column=col+1, columnspan=colspan, sticky=sticky, padx=3, pady=2)
        if default: e.insert(0, str(default))
        return e

    def _lc(self, p, label, row, col=0, values=None, width=18, default=0):
        ttk.Label(p, text=label).grid(row=row, column=col, sticky="w", padx=3, pady=2)
        c = ttk.Combobox(p, values=values or [], state="readonly", width=width)
        c.grid(row=row, column=col+1, sticky="w", padx=3, pady=2)
        if values: c.current(default)
        return c

    def _build_ui(self):
        # Ust bar: Firma Yonetimi
        top = ttk.Frame(self, padding=(6, 4))
        top.pack(fill="x")
        ttk.Label(top, text="Firma:", style="Header.TLabel").pack(side="left", padx=(0, 5))
        self.cmb_firma = ttk.Combobox(top, width=25, values=self.veri_mgr.firma_listesi())
        self.cmb_firma.pack(side="left", padx=2)
        ttk.Button(top, text="Yukle", command=self._firma_yukle).pack(side="left", padx=2)
        ttk.Button(top, text="Kaydet", command=self._firma_kaydet).pack(side="left", padx=2)
        ttk.Button(top, text="Yeni Firma", command=self._firma_yeni).pack(side="left", padx=2)
        ttk.Button(top, text="Sil", command=self._firma_sil).pack(side="left", padx=2)

        # YKT Durum Paneli
        ykt_frame = ttk.LabelFrame(self, text="YKT DURUM PANELI - Gecmis Donem Bilgileri", padding=5)
        ykt_frame.pack(fill="x", padx=6, pady=(0, 4))
        self.lbl_ykt = ttk.Label(ykt_frame, text="Henuz hesaplama olusturulmadi.", style="YKT.TLabel")
        self.lbl_ykt.pack(fill="x")
        self.lbl_ykt_detay = ttk.Label(ykt_frame, text="", style="Info.TLabel", wraplength=1100)
        self.lbl_ykt_detay.pack(fill="x")

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=6, pady=(0, 6))
        self.notebook = nb

        self.tab1 = ttk.Frame(nb); nb.add(self.tab1, text=" A: Tesvik Belgesi ")
        self.tab2 = ttk.Frame(nb); nb.add(self.tab2, text=" B: Yat. Harcama ")
        self.tab3 = ttk.Frame(nb); nb.add(self.tab3, text=" C: Tevsi ")
        self.tab4 = ttk.Frame(nb); nb.add(self.tab4, text=" D: Kazanc/Matrah ")
        self.tab5 = ttk.Frame(nb); nb.add(self.tab5, text=" E-F: Istisna/Endeks ")
        self.tab6 = ttk.Frame(nb); nb.add(self.tab6, text=" G-H: Param./Ozel ")
        self.tab7 = ttk.Frame(nb); nb.add(self.tab7, text=" Rapor ")
        self.tab8 = ttk.Frame(nb); nb.add(self.tab8, text=" Coklu Belge ")
        self.tab9 = ttk.Frame(nb); nb.add(self.tab9, text=" Belge Yukle ")

        self._build_tab1(); self._build_tab2(); self._build_tab3()
        self._build_tab4(); self._build_tab5(); self._build_tab6()
        self._build_tab7(); self._build_tab8(); self._build_tab9()

    # ---- FIRMA ISLEMLERI ----
    def _firma_kaydet(self):
        adi = self.cmb_firma.get().strip()
        if not adi:
            messagebox.showwarning("Uyari", "Firma adi giriniz.")
            return
        self.firma_adi = adi
        veri = {"firma_adi": adi, "belgeler": []}
        # Firma meta bilgilerini ekle
        if self._firma_meta:
            veri["unvan"] = self._firma_meta.get("unvan", "")
            veri["vkn"] = self._firma_meta.get("vkn", "")
            veri["vergi_dairesi"] = self._firma_meta.get("vergi_dairesi", "")
        if self.motor:
            veri["aktif_motor"] = self.motor.to_dict()
        for m in self.belgeler:
            veri["belgeler"].append(m.to_dict())
        dosya = self.veri_mgr.kaydet(adi, veri)
        self.cmb_firma["values"] = self.veri_mgr.firma_listesi()
        messagebox.showinfo("Basarili", f"Firma kaydedildi:\n{dosya}")

    def _firma_yukle(self):
        adi = self.cmb_firma.get().strip()
        if not adi:
            messagebox.showwarning("Uyari", "Firma seciniz.")
            return
        veri = self.veri_mgr.yukle(adi)
        if not veri:
            messagebox.showerror("Hata", "Firma verisi bulunamadi.")
            return
        self.firma_adi = adi
        self._firma_meta = {
            "unvan": veri.get("unvan", ""),
            "vkn": veri.get("vkn", ""),
            "vergi_dairesi": veri.get("vergi_dairesi", ""),
        }
        if "aktif_motor" in veri:
            self.motor = HesaplamaMotoru.from_dict(veri["aktif_motor"])
        self.belgeler = [HesaplamaMotoru.from_dict(b) for b in veri.get("belgeler", [])]
        self._formu_doldur()
        self._ykt_paneli_guncelle()
        self._donem_tablosu_doldur()
        messagebox.showinfo("Basarili", f"'{adi}' firmasinin verileri yuklendi.")

    def _firma_yeni(self):
        self.firma_adi = ""
        self._firma_meta = {}
        self.motor = None; self.belgeler = []
        self._donem_girdileri = []
        self.cmb_firma.set("")
        self._ykt_paneli_guncelle()
        for item in self.tree_d.get_children(): self.tree_d.delete(item)
        messagebox.showinfo("Bilgi", "Yeni firma icin formlar temizlendi.")

    def _firma_sil(self):
        adi = self.cmb_firma.get().strip()
        if not adi: return
        if messagebox.askyesno("Onay", f"'{adi}' firmasinin tum verileri silinecek. Emin misiniz?"):
            self.veri_mgr.sil(adi)
            self.cmb_firma["values"] = self.veri_mgr.firma_listesi()
            self.cmb_firma.set("")
            self._firma_yeni()

    def _formu_doldur(self):
        """Motor verilerinden GUI formlarini doldurur."""
        if not self.motor: return
        b = self.motor.belge
        def _set(e, v):
            e.delete(0, "end"); e.insert(0, str(v) if v else "")
        _set(self.a_belge_no, b.belge_no); _set(self.a_belge_tarihi, b.belge_tarihi)
        try: self.a_yatirim_turu.set(b.yatirim_turu)
        except: pass
        try: self.a_tesvik_turu.set(b.tesvik_turu)
        except: pass
        try: self.a_karar.set(b.karar_turu)
        except: pass
        try: self.a_bolge.set(str(b.bolge))
        except: pass
        _set(self.a_konu, b.yatirim_konusu)
        self.a_imalat.set(b.imalat_sanayi)
        self.a_osb.set(b.osb_icerisinde)
        _set(self.a_sabit_yatirim, pf(b.toplam_sabit_yatirim))
        _set(self.a_katki_oran, b.katki_orani); _set(self.a_indirim_oran, b.indirim_orani)
        _set(self.a_yd_oran, b.yatirim_donemi_orani)
        _set(self.a_baslama, b.baslama_tarihi); _set(self.a_tamamlama, b.tamamlama_tarihi)
        _set(self.a_kismen, b.kismen_isletme_tarihi)
        try: self.a_vizesi.set(b.tamamlama_vizesi)
        except: pass
        self.a_yuzde100.set(b.yuzde_100_indirim)
        _set(self.a_belge_insaat, pf(b.belge_insaat_tutari)); _set(self.a_belge_makine, pf(b.belge_makine_tutari))
        _set(self.a_gercek_insaat, pf(b.gerceklesen_insaat)); _set(self.a_gercek_makine, pf(b.gerceklesen_makine))
        self.a_nakdi.set(b.nakdi_sermaye)
        _set(self.a_nakdi_tutar, pf(b.nakdi_sermaye_tutari) if b.nakdi_sermaye_tutari else "")
        _set(self.a_nakdi_tarih, b.nakdi_sermaye_tarihi)
        # Gecmis YKT gir
        _set(self.f_devreden, pf(self.motor.devreden.devreden_katki))

    def _donem_tablosu_doldur(self):
        """Kaydedilmis donemleri tabloya yukler."""
        for item in self.tree_d.get_children(): self.tree_d.delete(item)
        if not self.motor: return
        for s in self.motor.donemler:
            sk_m = pf(s.sk_indirimli_matrah)
            hs_m = pf(s.hs_indirimli_matrah)
            if s.sk_tevsi_orani is not None: sk_m += f"({s.sk_tevsi_orani:.0f}%)"
            if s.hs_tevsi_orani is not None: hs_m += f"({s.hs_tevsi_orani:.0f}%)"
            self.tree_d.insert("", "end", values=(
                s.donem_adi, s.donem_turu[:3], pf(s.kazanc), f"%{s.kv_orani}",
                sk_m, pf(s.sk_toplam_kv), pf(s.sk_katki_kullanimi),
                hs_m, pf(s.hs_toplam_kv), pf(s.hs_katki_kullanimi),
                pf(s.endeks_eklenen) if s.endeks_eklenen > 0 else "-", pf(s.kalan_katki),
            ))

    # ---- YKT DURUM PANELI ----
    def _ykt_paneli_guncelle(self):
        if not self.motor:
            firma_info = ""
            if self._firma_meta:
                parts = []
                if self._firma_meta.get("unvan"):
                    parts.append(self._firma_meta["unvan"])
                if self._firma_meta.get("vkn"):
                    parts.append(f"VKN: {self._firma_meta['vkn']}")
                if parts:
                    firma_info = " | ".join(parts) + " | "
            self.lbl_ykt.configure(text=f"{firma_info}Henuz hesaplama olusturulmadi.")
            self.lbl_ykt_detay.configure(text="")
            return
        m = self.motor
        self.lbl_ykt.configure(
            text=f"TOPLAM YKT: {pf(m.toplam_katki)} TL  |  "
                 f"KULLANILAN: {pf(m.kullanilan_katki)} TL  |  "
                 f"KALAN: {pf(m.kalan_katki)} TL"
        )
        detay_parts = []
        detay_parts.append(f"Yat.Don. Kullanilan: {pf(m.kullanilan_katki_yatirim)} TL")
        detay_parts.append(f"Isl.Don. Kullanilan: {pf(m.kullanilan_katki_isletme)} TL")
        if m.endeks_toplam > 0:
            detay_parts.append(f"Endeks Eklenen: {pf(m.endeks_toplam)} TL")
        if m.devreden.devreden_katki > 0:
            detay_parts.append(f"Devreden: {pf(m.devreden.devreden_katki)} TL")
        detay_parts.append(f"Uygun Harcama: {pf(m.kumulatif_harcama)} TL")
        if m.kumulatif_toplam_harcama != m.kumulatif_harcama:
            fark = m.kumulatif_toplam_harcama - m.kumulatif_harcama
            detay_parts.append(f"Kapsam Disi/Ayrilan: {pf(fark)} TL")
        if m.donemler:
            son = m.donemler[-1]
            detay_parts.append(f"Son Donem: {son.donem_adi}")
        self.lbl_ykt_detay.configure(text="  |  ".join(detay_parts))

    # ---- TAB 1: TESVIK BELGESI ----
    def _build_tab1(self):
        sf = ScrollFrame(self.tab1); sf.pack(fill="both", expand=True)
        f = sf.inner
        ttk.Label(f, text="A - Yatirim Tesvik Belgesi Bilgileri", style="Title.TLabel").grid(
            row=0, column=0, columnspan=4, sticky="w", padx=5, pady=(5,10))
        r = 1
        self.a_belge_no = self._le(f, "1. Belge No:", r); r+=1
        self.a_belge_tarihi = self._le(f, "2. Belge Tarihi:", r); r+=1
        self.a_yatirim_turu = self._lc(f, "3. Yatirim Turu:", r, values=YATIRIM_TURU_LIST)
        self.a_yatirim_turu.bind("<<ComboboxSelected>>", self._on_a_changed); r+=1
        self.a_tesvik_turu = self._lc(f, "4. Tesvik Turu:", r, values=TESVIK_TURU_LIST)
        self.a_tesvik_turu.bind("<<ComboboxSelected>>", self._on_a_changed); r+=1
        self.a_karar = self._lc(f, "5. Karar Turu:", r, values=KARAR_LIST)
        self.a_karar.bind("<<ComboboxSelected>>", self._on_a_changed); r+=1
        self.a_bolge = self._lc(f, "6. Bolge:", r, values=BOLGE_LIST, width=5)
        self.a_bolge.bind("<<ComboboxSelected>>", self._on_a_changed); r+=1
        self.a_konu = self._le(f, "7. Yatirim Konusu/Sektor:", r, width=30); r+=1
        self.a_imalat = tk.BooleanVar()
        ttk.Checkbutton(f, text="8. Imalat Sanayii Yatirimi", variable=self.a_imalat).grid(
            row=r, column=0, columnspan=2, sticky="w", padx=3); r+=1
        self.a_osb = tk.BooleanVar()
        ttk.Checkbutton(f, text="8b. OSB Icerisinde (ek bolge avantaji)", variable=self.a_osb).grid(
            row=r, column=0, columnspan=3, sticky="w", padx=3); r+=1
        self.a_sabit_yatirim = self._le(f, "9. Toplam Sabit Yatirim (TL):", r); r+=1
        ttk.Separator(f, orient="horizontal").grid(row=r, column=0, columnspan=4, sticky="ew", pady=8); r+=1
        ttk.Label(f, text="Oranlar (otomatik, duzenlenebilir)", style="Header.TLabel").grid(
            row=r, column=0, columnspan=2, sticky="w", padx=3); r+=1
        self.a_katki_oran = self._le(f, "10. Yatirima Katki Orani (%):", r, width=10); r+=1
        self.a_indirim_oran = self._le(f, "11. Vergi Indirim Orani (%):", r, width=10); r+=1
        self.a_yd_oran = self._le(f, "12. Yat. Donemi Orani (%):", r, width=10); r+=1
        ttk.Separator(f, orient="horizontal").grid(row=r, column=0, columnspan=4, sticky="ew", pady=8); r+=1
        self.a_baslama = self._le(f, "13. Fiilen Baslama Tarihi:", r); r+=1
        self.a_tamamlama = self._le(f, "14. Tamamlama Vize Tarihi:", r); r+=1
        self.a_kismen = self._le(f, "15. Kismen Isletme Tarihi:", r); r+=1
        self.a_vizesi = self._lc(f, "15b. Tamamlama Vizesi:", r, values=TAMAMLAMA_VIZESI_LIST); r+=1
        self.a_yuzde100 = tk.BooleanVar()
        ttk.Checkbutton(f, text="16. %100 Vergi Indirimi (2017-2022 imalat/turizm)",
                        variable=self.a_yuzde100).grid(row=r, column=0, columnspan=3, sticky="w", padx=3); r+=1
        ttk.Separator(f, orient="horizontal").grid(row=r, column=0, columnspan=4, sticky="ew", pady=8); r+=1
        ttk.Label(f, text="Belge / Gerceklesen Harcama", style="Header.TLabel").grid(
            row=r, column=0, columnspan=3, sticky="w", padx=3); r+=1
        self.a_belge_insaat = self._le(f, "17. Belge Insaat Tutari:", r); r+=1
        self.a_belge_makine = self._le(f, "18. Belge Makine Tutari:", r); r+=1
        self.a_gercek_insaat = self._le(f, "19. Gerceklesen Insaat:", r); r+=1
        self.a_gercek_makine = self._le(f, "20. Gerceklesen Makine:", r); r+=1
        self.a_nakdi = tk.BooleanVar()
        ttk.Checkbutton(f, text="Nakdi Sermaye Artisi (+5 puan)", variable=self.a_nakdi).grid(
            row=r, column=0, columnspan=3, sticky="w", padx=3); r+=1
        self.a_nakdi_tutar = self._le(f, "   Nakdi Sermaye Tutari:", r); r+=1
        self.a_nakdi_tarih = self._le(f, "   Sermaye Artis Tarihi:", r); r+=1
        ttk.Separator(f, orient="horizontal").grid(row=r, column=0, columnspan=4, sticky="ew", pady=8); r+=1
        btn = ttk.Frame(f); btn.grid(row=r, column=0, columnspan=4, sticky="ew", pady=5)
        ttk.Button(btn, text="Hesaplamayi Olustur", command=self._olustur).pack(side="left", padx=5)
        ttk.Button(btn, text="Oranlari Yukle", command=self._on_a_changed).pack(side="left", padx=5)
        r+=1
        self.a_ozet = tk.Text(f, wrap="word", font=("Consolas", 9), height=6, bg="#f0f4f8", relief="flat", state="disabled")
        self.a_ozet.grid(row=r, column=0, columnspan=4, sticky="ew", padx=5, pady=5)
        self._on_a_changed()

    def _on_a_changed(self, event=None):
        karar = KARAR_MAP.get(self.a_karar.get()); tesvik = TESVIK_MAP.get(self.a_tesvik_turu.get())
        bolge = int(self.a_bolge.get() or "1")
        # OSB icerisinde bolgesel tesviklerde ek 1 bolge avantaji
        if self.a_osb.get() and tesvik == "bolgesel" and bolge > 1:
            eff_bolge = bolge - 1  # bir ust bolge oranlari
        else:
            eff_bolge = bolge
        if karar and tesvik:
            k, i = karar[tesvik][eff_bolge]; yd = karar["yatirim_donemi"][eff_bolge]
            self.a_katki_oran.delete(0,"end"); self.a_katki_oran.insert(0, str(k))
            self.a_indirim_oran.delete(0,"end"); self.a_indirim_oran.insert(0, str(i))
            self.a_yd_oran.delete(0,"end"); self.a_yd_oran.insert(0, str(yd))

    def _olustur(self):
        try:
            belge = TesvikBelgesi(
                belge_no=self.a_belge_no.get().strip(), belge_tarihi=self.a_belge_tarihi.get().strip(),
                yatirim_turu=self.a_yatirim_turu.get(), tesvik_turu=self.a_tesvik_turu.get(),
                karar_turu=self.a_karar.get(), bolge=int(self.a_bolge.get()),
                yatirim_konusu=self.a_konu.get().strip(), imalat_sanayi=self.a_imalat.get(),
                osb_icerisinde=self.a_osb.get(),
                toplam_sabit_yatirim=pt(self.a_sabit_yatirim.get()),
                katki_orani=float(self.a_katki_oran.get()), indirim_orani=float(self.a_indirim_oran.get()),
                yatirim_donemi_orani=float(self.a_yd_oran.get()),
                baslama_tarihi=self.a_baslama.get().strip(), tamamlama_tarihi=self.a_tamamlama.get().strip(),
                kismen_isletme_tarihi=self.a_kismen.get().strip(),
                tamamlama_vizesi=self.a_vizesi.get() or "Devam Ediyor",
                yuzde_100_indirim=self.a_yuzde100.get(),
                belge_insaat_tutari=pt(self.a_belge_insaat.get()), belge_makine_tutari=pt(self.a_belge_makine.get()),
                gerceklesen_insaat=pt(self.a_gercek_insaat.get()), gerceklesen_makine=pt(self.a_gercek_makine.get()),
                nakdi_sermaye=self.a_nakdi.get(),
                nakdi_sermaye_tutari=pt(self.a_nakdi_tutar.get()),
                nakdi_sermaye_tarihi=self.a_nakdi_tarih.get().strip(),
            )
        except (ValueError, TypeError) as e:
            messagebox.showerror("Hata", f"Veri hatasi: {e}"); return
        if belge.toplam_sabit_yatirim <= 0:
            messagebox.showerror("Hata", "Sabit yatirim sifirdan buyuk olmali."); return
        self.motor = HesaplamaMotoru(belge)
        self._donem_girdileri = []
        self._tevsi_guncelle(); self._ef_kaydet_sessiz()
        h = self.motor; b = h.belge
        txt = (f"Belge: {b.belge_no or '-'}  |  {b.karar_turu}  |  {b.tesvik_turu}\n"
               f"Bolge: {b.bolge}.  |  Tur: {b.yatirim_turu}\n"
               f"Sabit Yatirim : {pf(b.toplam_sabit_yatirim)} TL\n"
               f"Katki Orani   : %{h.efektif_katki_orani}"
               + (f" (nakdi +{NAKDI_SERMAYE_EK_KATKI})" if b.nakdi_sermaye else "") +
               f"\nKatki Tutari  : {pf(h.katki_tutari)} TL\n"
               f"Indirimli KV  : %{h.indirimli_kv_orani()}\n"
               f"Yat.Don.Orani : %{b.yatirim_donemi_orani}")
        if b.yuzde_100_indirim: txt += "\n*** %100 VERGI INDIRIMI ***"
        self.a_ozet.configure(state="normal"); self.a_ozet.delete("1.0","end")
        self.a_ozet.insert("1.0", txt); self.a_ozet.configure(state="disabled")
        self._ykt_paneli_guncelle()
        messagebox.showinfo("Basarili", "Hesaplama olusturuldu.")
        self.notebook.select(self.tab4)

    # ---- TAB 2: HARCAMA ----
    def _build_tab2(self):
        sf = ScrollFrame(self.tab2); sf.pack(fill="both", expand=True); f = sf.inner
        ttk.Label(f, text="B - Donemsel Yatirim Harcamasi", style="Title.TLabel").grid(
            row=0, column=0, columnspan=4, sticky="w", padx=5, pady=(5,10))
        r = 1
        self.b_yil = self._le(f, "1. Yil:", r, width=8, default="2024"); r+=1
        self.b_gecici = self._lc(f, "2. GV Donemi:", r, values=GECICI_DONEM_LIST); r+=1
        self.b_toplam = self._le(f, "3. Toplam Harcama (TL):", r); r+=1
        ttk.Label(f, text="Alt Kirilimlar:", style="Header.TLabel").grid(row=r, column=0, columnspan=2, sticky="w", padx=3, pady=(8,2)); r+=1
        self.b_makine = self._le(f, "  Makine-Techizat:", r); r+=1
        self.b_insaat = self._le(f, "  Bina-Insaat:", r); r+=1
        self.b_arazi = self._le(f, "  Arazi-Arsa:", r); r+=1
        self.b_diger = self._le(f, "  Diger:", r); r+=1
        ttk.Separator(f, orient="horizontal").grid(row=r, column=0, columnspan=4, sticky="ew", pady=5); r+=1
        self.b_kur = self._le(f, "4. Kur Farki/Fin. Gid.:", r); r+=1
        self.b_finkira = self._le(f, "5. Finansal Kiralama:", r); r+=1
        self.b_avans = self._le(f, "6. Avans Odemeleri:", r); r+=1
        self.b_kapsam_disi = self._le(f, "7. Kapsam Disi:", r); r+=1
        r+=1; btn = ttk.Frame(f); btn.grid(row=r, column=0, columnspan=4, sticky="ew", pady=5)
        ttk.Button(btn, text="Harcama Ekle", command=self._harcama_ekle).pack(side="left", padx=5)
        ttk.Button(btn, text="Secili Sil", command=self._harcama_sil).pack(side="left", padx=5)
        r+=1
        cols = ("yil","donem","toplam","uygun","makine","insaat","arazi","diger","kur","finkira","avans","kdisi")
        self.tree_harc = ttk.Treeview(f, columns=cols, show="headings", height=6)
        hdrs = {"yil":("Yil",50),"donem":("Donem",90),"toplam":("Toplam",100),
                "uygun":("Uygun",100),"makine":("Makine",90),"insaat":("Insaat",90),"arazi":("Arazi",80),
                "diger":("Diger",80),"kur":("Kur/Fin",80),"finkira":("Fin.Kir",80),
                "avans":("Avans",80),"kdisi":("K.Disi",80)}
        for c,(h,w) in hdrs.items():
            self.tree_harc.heading(c, text=h); self.tree_harc.column(c, width=w, anchor="e")
        self.tree_harc.grid(row=r, column=0, columnspan=4, sticky="nsew", padx=5)
        r+=1
        self.lbl_kum_harc = ttk.Label(f, text="Kumulatif Harcama: 0,00 TL", style="Result.TLabel")
        self.lbl_kum_harc.grid(row=r, column=0, columnspan=4, sticky="w", padx=5, pady=5)

    def _harcama_ekle(self):
        if not self.motor:
            messagebox.showwarning("Uyari", "Once hesaplama olusturunuz."); return
        try:
            h = DonemselHarcama(yil=int(self.b_yil.get()), gecici_donem=self.b_gecici.get(),
                toplam_harcama=pt(self.b_toplam.get()), makine_techizat=pt(self.b_makine.get()),
                bina_insaat=pt(self.b_insaat.get()), arazi_arsa=pt(self.b_arazi.get()),
                diger_harcama=pt(self.b_diger.get()), kur_farki_finansman=pt(self.b_kur.get()),
                finansal_kiralama=pt(self.b_finkira.get()), avans_odemeleri=pt(self.b_avans.get()),
                kapsam_disi=pt(self.b_kapsam_disi.get()))
        except (ValueError, TypeError) as e:
            messagebox.showerror("Hata", str(e)); return
        self.motor.harcamalar.append(h)
        self.tree_harc.insert("","end", values=(h.yil, h.gecici_donem, pf(h.toplam_harcama),
            pf(h.uygun_harcama),
            pf(h.makine_techizat), pf(h.bina_insaat), pf(h.arazi_arsa), pf(h.diger_harcama),
            pf(h.kur_farki_finansman), pf(h.finansal_kiralama), pf(h.avans_odemeleri), pf(h.kapsam_disi)))
        self.lbl_kum_harc.configure(text=f"Uygun Harcama: {pf(self.motor.kumulatif_harcama)} TL | Toplam: {pf(self.motor.kumulatif_toplam_harcama)} TL")
        self._ykt_paneli_guncelle()

    def _harcama_sil(self):
        sel = self.tree_harc.selection()
        if sel:
            idx = self.tree_harc.index(sel[0]); self.tree_harc.delete(sel[0])
            if self.motor and idx < len(self.motor.harcamalar):
                self.motor.harcamalar.pop(idx)
                self.lbl_kum_harc.configure(text=f"Uygun Harcama: {pf(self.motor.kumulatif_harcama)} TL | Toplam: {pf(self.motor.kumulatif_toplam_harcama)} TL")
                self._ykt_paneli_guncelle()

    # ---- TAB 3: TEVSI ----
    def _build_tab3(self):
        sf = ScrollFrame(self.tab3); sf.pack(fill="both", expand=True); f = sf.inner
        ttk.Label(f, text="C - Tevsi Yatirimlara Ozgu Veriler", style="Title.TLabel").grid(
            row=0, column=0, columnspan=4, sticky="w", padx=5, pady=(5,10))
        r = 1
        ttk.Label(f, text="Sabit Kiymet Yontemi (Teblig)", style="Header.TLabel").grid(row=r, column=0, columnspan=3, sticky="w", padx=5); r+=1
        self.c_mevcut_sk = self._le(f, "1. Mevcut Toplam SK:", r); r+=1
        self.c_tevsi_sk = self._le(f, "2. Tevsi Aktif SK:", r); r+=1
        self.c_tevsi_oran_m = self._le(f, "3. Manuel Oran (%):", r, width=10); r+=1
        self.c_yd_var = tk.BooleanVar()
        ttk.Checkbutton(f, text="4. Yeniden Degerleme?", variable=self.c_yd_var).grid(row=r, column=0, columnspan=2, sticky="w", padx=3); r+=1
        self.c_yd_tutar = self._le(f, "   Yeniden Degerli Tut.:", r); r+=1
        ttk.Separator(f, orient="horizontal").grid(row=r, column=0, columnspan=4, sticky="ew", pady=10); r+=1
        ttk.Label(f, text="Hasilat Yontemi (Ozelge)", style="Header.TLabel").grid(row=r, column=0, columnspan=3, sticky="w", padx=5); r+=1
        self.c_tevsi_hs = self._le(f, "5. Tevsi Hasilat:", r); r+=1
        self.c_toplam_hs = self._le(f, "6. Toplam Hasilat:", r); r+=1
        r+=1; ttk.Button(f, text="Tevsi Kaydet", command=self._tevsi_guncelle).grid(row=r, column=0, padx=5, pady=10)
        r+=1; self.c_ozet = ttk.Label(f, text="", style="Result.TLabel")
        self.c_ozet.grid(row=r, column=0, columnspan=4, sticky="w", padx=5)

    def _tevsi_guncelle(self, event=None):
        if not self.motor: return
        try:
            m = pt(self.c_mevcut_sk.get()); t = pt(self.c_tevsi_sk.get())
            mn = self.c_tevsi_oran_m.get().strip()
            th = pt(self.c_tevsi_hs.get()); tph = pt(self.c_toplam_hs.get())
        except: return
        self.motor.tevsi = TevsiVerileri(mevcut_sabit_kiymet=m, tevsi_aktif_kiymet=t,
            tevsi_orani_manuel=float(mn) if mn else None, yeniden_degerleme=self.c_yd_var.get(),
            yeniden_degerli_tutar=pt(self.c_yd_tutar.get()), tevsi_hasilat=th, toplam_hasilat=tph)
        sk_o = (t/(m+t)*100) if (m+t)>0 else 0; hs_o = (th/tph*100) if tph>0 else 0
        self.c_ozet.configure(text=f"SK Orani: %{sk_o:.2f}  |  HS Orani: %{hs_o:.2f}")

    # ---- TAB 4: KAZANC/MATRAH ----
    def _build_tab4(self):
        container = ttk.Frame(self.tab4, padding=5); container.pack(fill="both", expand=True)
        inp = ttk.LabelFrame(container, text="D - Kazanc/Matrah + Gecmis YKT Bilgisi", padding=5); inp.pack(fill="x")

        # GECMIS YKT BILGI PANELI
        ykt_info = ttk.Frame(inp)
        ykt_info.grid(row=0, column=0, columnspan=4, sticky="ew", pady=(0,5))
        self.lbl_d_ykt = ttk.Label(ykt_info, text="", style="YKT.TLabel")
        self.lbl_d_ykt.pack(fill="x")

        r = 1
        self.d_yil = self._le(inp, "1. Yil:", r, width=8, default="2024")
        self.d_gecici = self._lc(inp, "GV Donemi:", r, col=2, values=GECICI_DONEM_LIST); r+=1
        self.d_donem_turu = self._lc(inp, "Donem Turu:", r, values=DONEM_TURU_LIST, default=1); r+=1
        self.d_ticari = self._le(inp, "2. Ticari Kar/(Zarar):", r)
        self.d_kkeg = self._le(inp, "KKEG:", r, col=2); r+=1
        self.d_istisna = self._le(inp, "3. Istisna Kazanclar:", r)
        self.d_gecmis_zarar = self._le(inp, "Gecmis Yil Zarari:", r, col=2); r+=1
        self.d_kv_matrah = self._le(inp, "4. KV Matrahi (elle):", r)
        ttk.Label(inp, text="(bos=otomatik)", style="Small.TLabel").grid(row=r, column=3, sticky="w"); r+=1
        self.d_yatirim_kaz = self._le(inp, "5. Yatirimdan Kazanc:", r)
        self.d_diger_kaz = self._le(inp, "Diger Faal. Kaz.:", r, col=2); r+=1
        self.d_ihracat = self._le(inp, "6. Ihracat Kazanci:", r)
        self.d_uretim = self._le(inp, "Uretim Kazanci:", r, col=2); r+=1

        # Gecmis donem faydalanilan YKT gosterimi
        ttk.Separator(inp, orient="horizontal").grid(row=r, column=0, columnspan=4, sticky="ew", pady=5); r+=1
        ttk.Label(inp, text="Gecmis Donemde Faydalanilan YKT (bilgi alani)", style="Header.TLabel").grid(
            row=r, column=0, columnspan=4, sticky="w", padx=3); r+=1
        self.d_gecmis_ykt_yat = self._le(inp, "Yat.Don. Kull. YKT:", r, width=15, default="0")
        self.d_gecmis_ykt_isl = self._le(inp, "Isl.Don. Kull. YKT:", r, col=2, width=15, default="0"); r+=1

        ttk.Separator(inp, orient="horizontal").grid(row=r, column=0, columnspan=4, sticky="ew", pady=5); r+=1
        ttk.Label(inp, text="Endeksleme", style="Header.TLabel").grid(row=r, column=0, columnspan=2, sticky="w", padx=3); r+=1
        self.d_ydo = self._le(inp, "YDO (%):", r, width=8, default="0")
        self.d_yufe_h = self._le(inp, "Yi-UFE Harc:", r, col=2, width=10, default="0"); r+=1
        self.d_yufe_k = self._le(inp, "Yi-UFE Kull:", r, width=10, default="0")
        self.d_kum_harc = self._le(inp, "Kum. Harcama:", r, col=2, width=15, default="0"); r+=1

        btn = ttk.Frame(inp); btn.grid(row=r, column=0, columnspan=4, sticky="ew", pady=5)
        ttk.Button(btn, text="Hesapla ve Ekle", command=self._donem_ekle).pack(side="left", padx=5)
        ttk.Button(btn, text="Secili Sil", command=self._donem_sil).pack(side="left", padx=5)
        ttk.Button(btn, text="Tumu Temizle", command=self._donem_temizle).pack(side="left", padx=5)
        ttk.Button(btn, text="Raporu Goster", command=self._rapor_olustur).pack(side="right", padx=5)

        cols = ("donem","tur","kazanc","kv","sk_matrah","sk_kv","sk_katki",
                "hs_matrah","hs_kv","hs_katki","endeks","kalan")
        self.tree_d = ttk.Treeview(container, columns=cols, show="headings", height=8)
        hdrs = {"donem":("Donem",90),"tur":("Tur",40),"kazanc":("Kazanc",100),
                "kv":("KV%",35),"sk_matrah":("SK Matrah",95),"sk_kv":("SK TopKV",90),
                "sk_katki":("SK Katki",90),"hs_matrah":("HS Matrah",95),"hs_kv":("HS TopKV",90),
                "hs_katki":("HS Katki",90),"endeks":("End.(+)",75),"kalan":("Kalan",100)}
        for c,(h,w) in hdrs.items():
            self.tree_d.heading(c, text=h); self.tree_d.column(c, width=w, anchor="e")
        self.tree_d.column("donem", anchor="w"); self.tree_d.column("tur", anchor="center"); self.tree_d.column("kv", anchor="center")
        scr = ttk.Scrollbar(container, orient="vertical", command=self.tree_d.yview)
        self.tree_d.configure(yscrollcommand=scr.set)
        self.tree_d.pack(side="left", fill="both", expand=True, pady=(5,0))
        scr.pack(side="right", fill="y", pady=(5,0))

    def _d_ykt_bilgi_guncelle(self):
        if not self.motor:
            self.lbl_d_ykt.configure(text=""); return
        m = self.motor
        self.lbl_d_ykt.configure(
            text=f"KALAN YKT: {pf(m.kalan_katki)} TL  |  "
                 f"Yat: {pf(m.kullanilan_katki_yatirim)}  |  Isl: {pf(m.kullanilan_katki_isletme)}  |  "
                 f"Toplam Kull: {pf(m.kullanilan_katki)}")
        # Gecmis ykt alanlarini guncelle
        self.d_gecmis_ykt_yat.delete(0,"end"); self.d_gecmis_ykt_yat.insert(0, pf(m.kullanilan_katki_yatirim))
        self.d_gecmis_ykt_isl.delete(0,"end"); self.d_gecmis_ykt_isl.insert(0, pf(m.kullanilan_katki_isletme))
        # Kumulatif harcama
        self.d_kum_harc.delete(0,"end"); self.d_kum_harc.insert(0, pf(m.kumulatif_harcama))

    def _donem_ekle(self):
        if not self.motor:
            messagebox.showwarning("Uyari", "Once Tab A'dan hesaplama olusturunuz."); return
        try:
            kd = KazancMatrah(yil=int(self.d_yil.get()), gecici_donem=self.d_gecici.get(),
                donem_turu=self.d_donem_turu.get(), ticari_kar=pt(self.d_ticari.get()),
                kkeg=pt(self.d_kkeg.get()), istisna_kazanclar=pt(self.d_istisna.get()),
                gecmis_yil_zarari=pt(self.d_gecmis_zarar.get()), kv_matrahi=pt(self.d_kv_matrah.get()),
                yatirim_kazanci=pt(self.d_yatirim_kaz.get()), diger_faaliyet_kazanci=pt(self.d_diger_kaz.get()),
                ihracat_kazanci=pt(self.d_ihracat.get()), uretim_kazanci=pt(self.d_uretim.get()),
                gerceklesen_harcama_kumulatif=pt(self.d_kum_harc.get()))
            ydo = float(self.d_ydo.get() or "0")
            yh = float(self.d_yufe_h.get() or "0"); yk = float(self.d_yufe_k.get() or "0")
        except (ValueError, TypeError) as e:
            messagebox.showerror("Hata", str(e)); return
        ist = self._istisna_oku()
        s = self.motor.donem_hesapla(kd, endeks_ydo=ydo, yufe_h=yh, yufe_k=yk, istisna=ist)
        self._donem_girdileri.append((deepcopy(kd), ydo, yh, yk, deepcopy(ist)))
        sk_m = pf(s.sk_indirimli_matrah); hs_m = pf(s.hs_indirimli_matrah)
        if s.sk_tevsi_orani is not None: sk_m += f"({s.sk_tevsi_orani:.0f}%)"
        if s.hs_tevsi_orani is not None: hs_m += f"({s.hs_tevsi_orani:.0f}%)"
        self.tree_d.insert("","end", values=(
            s.donem_adi, s.donem_turu[:3], pf(s.kazanc), f"%{s.kv_orani}",
            sk_m, pf(s.sk_toplam_kv), pf(s.sk_katki_kullanimi),
            hs_m, pf(s.hs_toplam_kv), pf(s.hs_katki_kullanimi),
            pf(s.endeks_eklenen) if s.endeks_eklenen > 0 else "-", pf(s.kalan_katki)))
        try:
            y = int(self.d_yil.get()); self.d_yil.delete(0,"end"); self.d_yil.insert(0, str(y+1))
        except: pass
        self._ykt_paneli_guncelle(); self._d_ykt_bilgi_guncelle()
        if self.motor.kalan_katki <= 0:
            messagebox.showinfo("Bilgi", "YKT tamamen kullanildi.")

    def _donem_sil(self):
        sel = self.tree_d.selection()
        if not sel:
            return
        idx = self.tree_d.index(sel[0])
        if not self.motor or idx >= len(self._donem_girdileri):
            if self.motor and idx < len(self.motor.donemler):
                self.motor.donemler.pop(idx)
                self.motor.kullanilan_katki_yatirim = sum(s.sk_katki_kullanimi for s in self.motor.donemler if s.donem_turu == "Yatirim")
                self.motor.kullanilan_katki_isletme = sum(s.sk_katki_kullanimi for s in self.motor.donemler if s.donem_turu != "Yatirim")
                self.motor.endeks_toplam = sum(s.endeks_eklenen for s in self.motor.donemler)
                self._donem_tablosu_doldur()
                self._ykt_paneli_guncelle(); self._d_ykt_bilgi_guncelle()
                return
            messagebox.showwarning("Uyari", "Silinecek donem bulunamadi.")
            return
        self._donem_girdileri.pop(idx)
        girdiler = list(self._donem_girdileri)
        self.motor.sifirla()
        self._donem_girdileri = []
        for item in self.tree_d.get_children():
            self.tree_d.delete(item)
        for kd, ydo, yh, yk, ist in girdiler:
            s = self.motor.donem_hesapla(kd, endeks_ydo=ydo, yufe_h=yh, yufe_k=yk, istisna=ist)
            self._donem_girdileri.append((deepcopy(kd), ydo, yh, yk, deepcopy(ist)))
            sk_m = pf(s.sk_indirimli_matrah); hs_m = pf(s.hs_indirimli_matrah)
            if s.sk_tevsi_orani is not None: sk_m += f"({s.sk_tevsi_orani:.0f}%)"
            if s.hs_tevsi_orani is not None: hs_m += f"({s.hs_tevsi_orani:.0f}%)"
            self.tree_d.insert("","end", values=(
                s.donem_adi, s.donem_turu[:3], pf(s.kazanc), f"%{s.kv_orani}",
                sk_m, pf(s.sk_toplam_kv), pf(s.sk_katki_kullanimi),
                hs_m, pf(s.hs_toplam_kv), pf(s.hs_katki_kullanimi),
                pf(s.endeks_eklenen) if s.endeks_eklenen > 0 else "-", pf(s.kalan_katki)))
        self._ykt_paneli_guncelle(); self._d_ykt_bilgi_guncelle()

    def _donem_temizle(self):
        for item in self.tree_d.get_children(): self.tree_d.delete(item)
        if self.motor: self.motor.sifirla()
        self._donem_girdileri = []
        self._ykt_paneli_guncelle(); self._d_ykt_bilgi_guncelle()

    # ---- TAB 5: ISTISNA/ENDEKS ----
    def _build_tab5(self):
        sf = ScrollFrame(self.tab5); sf.pack(fill="both", expand=True); f = sf.inner
        ttk.Label(f, text="E - Diger Indirim/Istisna Etkilesim", style="Title.TLabel").grid(
            row=0, column=0, columnspan=4, sticky="w", padx=5, pady=(5,10))
        r = 1
        ttk.Label(f, text="Asgari KV (KVK 32/C) — 2025+", style="Header.TLabel").grid(
            row=r, column=0, columnspan=3, sticky="w", padx=5); r+=1
        self.e_asgari = self._le(f, "1. Asgari KV Matrahi:", r); r+=1
        self.e_asgari_oran = self._le(f, "   Asgari KV Orani (%):", r, width=8, default="10"); r+=1
        self.e_asgari_istisna = self._le(f, "   Asgari KV Istisna Tutar:", r); r+=1
        ttk.Separator(f, orient="horizontal").grid(row=r, column=0, columnspan=4, sticky="ew", pady=5); r+=1
        ttk.Label(f, text="Istisna Kazanclar", style="Header.TLabel").grid(
            row=r, column=0, columnspan=3, sticky="w", padx=5); r+=1
        self.e_5_1_e = self._le(f, "2. KVK 5/1-e (GMSi satis):", r); r+=1
        self.e_5_1_d = self._le(f, "3. KVK 5/1-d (Yat.fon/ort.):", r); r+=1
        self.e_5_b = self._le(f, "4. KVK 5/B (Sinai mulkiyet):", r); r+=1
        self.e_serbest = self._le(f, "5. Serbest Bolge (3218):", r); r+=1
        self.e_teknokent = self._le(f, "6. Teknokent (4691):", r); r+=1
        self.e_arge = self._le(f, "7. Ar-Ge Indirimi (5746):", r); r+=1
        self.e_10_1_h = self._le(f, "8. Nakdi Serm. Ind. (10/1-h):", r); r+=1
        self.e_yillara = self._le(f, "9. Yillara Yaygin Insaat:", r); r+=1
        self.e_diger_ist = self._le(f, "10. Diger Istisna/Indirim:", r); r+=1
        ttk.Separator(f, orient="horizontal").grid(row=r, column=0, columnspan=4, sticky="ew", pady=10); r+=1
        ttk.Label(f, text="F - Devreden Katki ve Endeksleme", style="Title.TLabel").grid(
            row=r, column=0, columnspan=4, sticky="w", padx=5, pady=(5,10)); r+=1
        self.f_devreden = self._le(f, "1. Devreden Katki Tutari:", r); r+=1
        self.f_dev_yil = self._le(f, "2. Devreden Yil:", r, width=8); r+=1
        self.f_yufe_h = self._le(f, "3. Yi-UFE Harcama Ayi:", r); r+=1
        self.f_yufe_k = self._le(f, "4. Yi-UFE Kullanim Don.:", r); r+=1
        self.f_yat_kull = self._le(f, "5. Yat.Don. Kullanilan:", r); r+=1
        self.f_isl_kull = self._le(f, "6. Isl.Don. Kullanilan:", r); r+=1
        r+=1; ttk.Button(f, text="Kaydet", command=self._ef_kaydet).grid(row=r, column=0, padx=5, pady=10)

    def _istisna_oku(self):
        try:
            return IstisnaEtkilesim(
                asgari_kv_matrahi=pt(self.e_asgari.get()),
                asgari_kv_orani=float(self.e_asgari_oran.get() or "10"),
                asgari_kv_istisna_tutar=pt(self.e_asgari_istisna.get()),
                kvk_5_1_e_istisna=pt(self.e_5_1_e.get()),
                kvk_5_1_d_istisna=pt(self.e_5_1_d.get()),
                kvk_5_b_istisna=pt(self.e_5_b.get()),
                serbest_bolge_istisna=pt(self.e_serbest.get()),
                teknokent_istisna=pt(self.e_teknokent.get()),
                arge_indirimi=pt(self.e_arge.get()),
                kvk_10_1_h_indirimi=pt(self.e_10_1_h.get()),
                yillara_yaygin_insaat=pt(self.e_yillara.get()),
                diger_istisna=pt(self.e_diger_ist.get()),
            )
        except: return IstisnaEtkilesim()

    def _ef_kaydet(self):
        self._ef_kaydet_sessiz()
        messagebox.showinfo("Bilgi", "Kaydedildi.")

    def _ef_kaydet_sessiz(self):
        if not self.motor: return
        self.motor.istisna = self._istisna_oku()
        try:
            self.motor.devreden = DevredenKatki(devreden_katki=pt(self.f_devreden.get()),
                devreden_yil=int(self.f_dev_yil.get() or "0"),
                yufe_harcama_ayi=pt(self.f_yufe_h.get()), yufe_kullanim_donemi=pt(self.f_yufe_k.get()),
                yatirim_doneminde_kullanilan=pt(self.f_yat_kull.get()),
                isletme_doneminde_kullanilan=pt(self.f_isl_kull.get()))
        except: pass

    # ---- TAB 6: G-H ----
    def _build_tab6(self):
        sf = ScrollFrame(self.tab6); sf.pack(fill="both", expand=True); f = sf.inner
        ttk.Label(f, text="G - Genel Parametreler", style="Title.TLabel").grid(
            row=0, column=0, columnspan=4, sticky="w", padx=5, pady=(5,10))
        r = 1
        ttk.Label(f, text="Yillara Gore KV Oranlari:", style="Header.TLabel").grid(row=r, column=0, columnspan=3, sticky="w", padx=5); r+=1
        self.g_kv = {}
        for yil in sorted(KV_ORANLARI.keys()):
            ttk.Label(f, text=f"  {yil}:").grid(row=r, column=0, sticky="w", padx=3)
            e = ttk.Entry(f, width=6); e.grid(row=r, column=1, sticky="w", padx=3); e.insert(0, str(KV_ORANLARI[yil]))
            self.g_kv[yil] = e; r+=1
        r+=1; self.g_ihr = self._le(f, "Ihracat/Uretim Ind. (%):", r, width=6, default=str(IHRACAT_URETIM_INDIRIM)); r+=1
        self.g_hesap = self._lc(f, "Hesap Donemi:", r, values=["Normal","Ozel"]); r+=1
        r+=1; ttk.Button(f, text="Kaydet", command=self._g_kaydet).grid(row=r, column=0, padx=5, pady=5); r+=1
        ttk.Separator(f, orient="horizontal").grid(row=r, column=0, columnspan=4, sticky="ew", pady=10); r+=1
        ttk.Label(f, text="H - Satis/Devir/Ozel Durumlar", style="Title.TLabel").grid(
            row=r, column=0, columnspan=4, sticky="w", padx=5, pady=(5,10)); r+=1
        self.h_satis = tk.BooleanVar()
        ttk.Checkbutton(f, text="1. Satis Var?", variable=self.h_satis).grid(row=r, column=0, columnspan=2, sticky="w", padx=3); r+=1
        self.h_satis_tarih = self._le(f, "   Tarih:", r); r+=1
        self.h_satis_tutar = self._le(f, "   Tutar:", r); r+=1
        self.h_devir = tk.BooleanVar()
        ttk.Checkbutton(f, text="2. Devir Var?", variable=self.h_devir).grid(row=r, column=0, columnspan=2, sticky="w", padx=3); r+=1
        self.h_satkirala = tk.BooleanVar()
        ttk.Checkbutton(f, text="3. Sat-Kirala-Geri Al?", variable=self.h_satkirala).grid(row=r, column=0, columnspan=2, sticky="w", padx=3); r+=1
        self.h_revize = tk.BooleanVar()
        ttk.Checkbutton(f, text="4. Belge Revize?", variable=self.h_revize).grid(row=r, column=0, columnspan=2, sticky="w", padx=3); r+=1
        self.h_rev_tarih = self._le(f, "   Revize Tarih:", r); r+=1
        self.h_rev_acik = self._le(f, "   Aciklama:", r, width=30); r+=1
        self.h_iptal = tk.BooleanVar()
        ttk.Checkbutton(f, text="5. Belge Iptal?", variable=self.h_iptal).grid(row=r, column=0, columnspan=2, sticky="w", padx=3); r+=1
        self.h_iptal_tarih = self._le(f, "   Iptal Tarihi:", r); r+=1
        self.h_sure_uzatma = tk.BooleanVar()
        ttk.Checkbutton(f, text="6. Sure Uzatma Var?", variable=self.h_sure_uzatma).grid(row=r, column=0, columnspan=2, sticky="w", padx=3); r+=1
        self.h_sure_tarih = self._le(f, "   Uzatma Tarihi:", r); r+=1
        self.h_kismi_tam = tk.BooleanVar()
        ttk.Checkbutton(f, text="7. Kismi Tamamlama?", variable=self.h_kismi_tam).grid(row=r, column=0, columnspan=2, sticky="w", padx=3); r+=1

    def _g_kaydet(self):
        for yil, e in self.g_kv.items():
            try: KV_ORANLARI[yil] = float(e.get())
            except: pass
        messagebox.showinfo("Bilgi", "Kaydedildi.")

    # ---- TAB 7: RAPOR ----
    def _build_tab7(self):
        container = ttk.Frame(self.tab7, padding=5); container.pack(fill="both", expand=True)
        self.txt_rapor = scrolledtext.ScrolledText(container, wrap="word", font=("Consolas", 9), bg="#f7f9fb")
        self.txt_rapor.pack(fill="both", expand=True)
        btn = ttk.Frame(container); btn.pack(fill="x", pady=5)
        ttk.Button(btn, text="Raporu Yenile", command=self._rapor_olustur).pack(side="left", padx=3)
        ttk.Button(btn, text="Panoya Kopyala", command=self._rapor_kopyala).pack(side="left", padx=3)

    def _rapor_olustur(self):
        if not self.motor or not self.motor.donemler:
            messagebox.showwarning("Uyari", "Hesaplama yok."); return
        self.notebook.select(self.tab7)
        m = self.motor; b = m.belge; d = m.donemler; L = []
        L.append("="*76)
        L.append("  KVK 32/A INDIRIMLI KURUMLAR VERGISI HESAPLAMA RAPORU")
        L.append("="*76)
        if self.firma_adi: L.append(f"  Firma: {self.firma_adi}")
        L.append(f"  Belge: {b.belge_no or '-'}  |  Tarih: {b.belge_tarihi or '-'}")
        L.append(f"  Karar: {b.karar_turu}  |  Tesvik: {b.tesvik_turu}")
        osb_txt = " (OSB ici)" if b.osb_icerisinde else ""
        L.append(f"  Tur: {b.yatirim_turu}  |  Bolge: {b.bolge}.{osb_txt}  |  Vize: {b.tamamlama_vizesi}")
        L.append(f"  Sabit Yatirim  : {pf(b.toplam_sabit_yatirim)} TL")
        L.append(f"  Katki Orani    : %{m.efektif_katki_orani}" + (f" (nakdi+{NAKDI_SERMAYE_EK_KATKI})" if b.nakdi_sermaye else ""))
        L.append(f"  Katki Tutari   : {pf(m.katki_tutari)} TL")
        L.append(f"  Indirim Orani  : %{b.indirim_orani}" + (" (%100)" if b.yuzde_100_indirim else ""))
        L.append(f"  Yat.Don. Orani : %{b.yatirim_donemi_orani}")
        if m.devreden.devreden_katki > 0: L.append(f"  Devreden Katki : {pf(m.devreden.devreden_katki)} TL")
        if m.endeks_toplam > 0: L.append(f"  Endeks Eklenen : {pf(m.endeks_toplam)} TL")
        L.append(f"  Toplam Katki   : {pf(m.toplam_katki)} TL")
        L.append(f"  Kum. Harcama   : {pf(m.kumulatif_harcama)} TL")
        L.append("")

        # Kitaptaki iki sinir
        if any(s.donem_turu == "Yatirim" for s in d):
            L.append("-"*76)
            L.append("  YATIRIM DONEMI - IKI SINIR KURALI (Kitap Bolum I.6)")
            L.append("-"*76)
            s1 = m.katki_tutari * b.yatirim_donemi_orani / 100
            s2 = m.kumulatif_harcama
            L.append(f"  1. Sinir (YKT x Yat.Don.Orani): {pf(s1)} TL")
            L.append(f"  2. Sinir (Gerceklesen Harcama) : {pf(s2)} TL")
            L.append(f"  Kullanilacak Sinir: {pf(min(s1, s2) if s2 > 0 else s1)} TL")
            L.append("")

        # SK tablosu
        L.append("-"*76); L.append("  SABIT KIYMET YONTEMI (Teblig)"); L.append("-"*76)
        hdr = f"  {'Donem':<14} {'Tur':<5} {'KV%':>4} {'Kazanc':>14} {'Ind.Mat':>14} {'TopKV':>14} {'Katki':>14}"
        L.append(hdr); L.append("  "+"-"*73)
        tn = ts = tk_ = 0
        for s in d:
            t = "Yat" if s.donem_turu=="Yatirim" else "Isl"
            sm = pf(s.sk_indirimli_matrah)
            if s.sk_tevsi_orani is not None: sm += f"({s.sk_tevsi_orani:.0f}%)"
            L.append(f"  {s.donem_adi:<14} {t:<5} {s.kv_orani:>3.0f} {pf(s.kazanc):>14} {sm:>14} {pf(s.sk_toplam_kv):>14} {pf(s.sk_katki_kullanimi):>14}")
            tn += s.sk_normal_kv; ts += s.sk_toplam_kv; tk_ += s.sk_katki_kullanimi
        L.append("  "+"-"*73)
        L.append(f"  Normal KV (indirim olmasaydi) : {pf(tn)} TL")
        L.append(f"  Odenen KV (SK)               : {pf(ts)} TL")
        L.append(f"  Tasarruf (SK)                : {pf(tn-ts)} TL")

        # HS tablosu
        has_var = any(s.hs_tevsi_orani is not None for s in d)
        if has_var:
            L.append(""); L.append("-"*76); L.append("  HASILAT YONTEMI (Ozelge)"); L.append("-"*76)
            L.append(hdr); L.append("  "+"-"*73)
            thkv = thk = 0
            for s in d:
                t = "Yat" if s.donem_turu=="Yatirim" else "Isl"
                hm = pf(s.hs_indirimli_matrah)
                if s.hs_tevsi_orani is not None: hm += f"({s.hs_tevsi_orani:.0f}%)"
                L.append(f"  {s.donem_adi:<14} {t:<5} {s.kv_orani:>3.0f} {pf(s.kazanc):>14} {hm:>14} {pf(s.hs_toplam_kv):>14} {pf(s.hs_katki_kullanimi):>14}")
                thkv += s.hs_toplam_kv; thk += s.hs_katki_kullanimi
            L.append("  "+"-"*73)
            L.append(f"  Odenen KV (HS) : {pf(thkv)} TL | Tasarruf: {pf(tn-thkv)} TL")
            fark = ts - thkv; av = "Hasilat" if fark>0 else ("Sabit Kiymet" if fark<0 else "Esit")
            L.append(f"  Fark: {pf(abs(fark))} TL ({av} yontemi avantajli)")

        # Asgari KV (32/C) etkilesimi
        has_asgari = any(s.asgari_kv > 0 for s in d)
        if has_asgari:
            L.append(""); L.append("-"*76); L.append("  ASGARI KURUMLAR VERGISI (KVK 32/C)"); L.append("-"*76)
            for s in d:
                if s.asgari_kv > 0:
                    L.append(f"  {s.donem_adi:<14} Asgari KV: {pf(s.asgari_kv)} TL (oran: %{s.asgari_kv_orani})")
                    if s.asgari_kv_farki > 0:
                        L.append(f"  {'':14} *** EK ODEME: {pf(s.asgari_kv_farki)} TL (Asgari KV > Hesaplanan KV)")
                    else:
                        L.append(f"  {'':14} Indirimli KV >= Asgari KV (ek odeme yok)")

        # Beyanname kodlari
        L.append(""); L.append("-"*76); L.append("  BEYANNAME KODLARI (SK Yontemi Baz)"); L.append("-"*76)
        for s in d:
            if s.beyanname_1063 > 0 or s.beyanname_1064 > 0:
                L.append(f"  {s.donem_adi:<14} 1063 (Ind.Mat): {pf(s.beyanname_1063)} | "
                         f"1064 (Nor.Mat): {pf(s.beyanname_1064)} | "
                         f"1065 (Ind.KV): {pf(s.beyanname_1065)}")

        # Sure siniri uyarilari
        uyarilar = [s for s in d if s.sure_siniri_uyari]
        if uyarilar:
            L.append(""); L.append("-"*76); L.append("  !!! SURE SINIRI UYARILARI !!!"); L.append("-"*76)
            for s in uyarilar:
                L.append(f"  {s.donem_adi}: {s.sure_siniri_uyari}")

        # Endeksleme
        if any(s.endeks_eklenen > 0 for s in d):
            L.append(""); L.append("-"*76); L.append("  ENDEKSLEME"); L.append("-"*76)
            for s in d:
                if s.endeks_eklenen > 0: L.append(f"  {s.donem_adi:<14} +{pf(s.endeks_eklenen)} TL")
            L.append(f"  Toplam: {pf(m.endeks_toplam)} TL")

        # Ozet
        L.append(""); L.append("="*76); L.append("  GENEL OZET"); L.append("="*76)
        L.append(f"  Katki (baslangic)    : {pf(m.katki_tutari)} TL")
        L.append(f"  Devreden             : {pf(m.devreden.devreden_katki)} TL")
        L.append(f"  Endeks               : {pf(m.endeks_toplam)} TL")
        L.append(f"  TOPLAM KATKI         : {pf(m.toplam_katki)} TL")
        L.append(f"  Yat.Don. Kullanilan  : {pf(m.kullanilan_katki_yatirim)} TL")
        L.append(f"  Isl.Don. Kullanilan  : {pf(m.kullanilan_katki_isletme)} TL")
        L.append(f"  TOPLAM KULLANILAN    : {pf(m.kullanilan_katki)} TL")
        L.append(f"  KALAN KATKI          : {pf(m.kalan_katki)} TL")
        L.append("="*76)

        rapor = "\n".join(L)
        self.txt_rapor.configure(state="normal"); self.txt_rapor.delete("1.0","end")
        self.txt_rapor.insert("1.0", rapor); self.txt_rapor.configure(state="disabled")

    def _rapor_kopyala(self):
        c = self.txt_rapor.get("1.0","end").strip()
        if c: self.clipboard_clear(); self.clipboard_append(c); messagebox.showinfo("Bilgi","Panoya kopyalandi.")

    # ---- TAB 8: COKLU BELGE ----
    def _build_tab8(self):
        container = ttk.Frame(self.tab8, padding=5); container.pack(fill="both", expand=True)
        btn = ttk.Frame(container); btn.pack(fill="x")
        ttk.Button(btn, text="Aktifi Ekle", command=self._belge_ekle).pack(side="left", padx=3)
        ttk.Button(btn, text="Secili Aktif Yap", command=self._belge_aktif).pack(side="left", padx=3)
        ttk.Button(btn, text="Secili Sil", command=self._belge_sil).pack(side="left", padx=3)
        cols = ("no","belge","karar","tesvik","tur","bolge","yatirim","katki","kullanilan","kalan")
        self.tree_belge = ttk.Treeview(container, columns=cols, show="headings", height=8)
        hdrs = {"no":("#",30),"belge":("Belge",100),"karar":("Karar",140),"tesvik":("Tesvik",120),
                "tur":("Tur",90),"bolge":("B.",30),"yatirim":("Yatirim",110),"katki":("Katki",110),
                "kullanilan":("Kullanilan",110),"kalan":("Kalan",110)}
        for c,(h,w) in hdrs.items():
            self.tree_belge.heading(c, text=h); self.tree_belge.column(c, width=w, anchor="e")
        self.tree_belge.column("no", anchor="center", width=30); self.tree_belge.column("belge", anchor="w")
        self.tree_belge.pack(fill="both", expand=True, pady=(10,0))
        self.lbl_coklu = ttk.Label(container, text="", style="Result.TLabel")
        self.lbl_coklu.pack(fill="x", pady=(5,0))

    def _belge_ekle(self):
        if not self.motor: messagebox.showwarning("Uyari","Aktif hesaplama yok."); return
        self.belgeler.append(deepcopy(self.motor)); self._coklu_guncelle()

    def _belge_aktif(self):
        sel = self.tree_belge.selection()
        if not sel: return
        idx = self.tree_belge.index(sel[0])
        if idx < len(self.belgeler):
            self.motor = self.belgeler[idx]
            self._formu_doldur(); self._ykt_paneli_guncelle(); self._donem_tablosu_doldur()
            messagebox.showinfo("Bilgi", f"Belge aktif yapildi.")

    def _belge_sil(self):
        sel = self.tree_belge.selection()
        if not sel: return
        idx = self.tree_belge.index(sel[0])
        if idx < len(self.belgeler): self.belgeler.pop(idx); self._coklu_guncelle()

    def _coklu_guncelle(self):
        for item in self.tree_belge.get_children(): self.tree_belge.delete(item)
        tt = tu = tk_ = 0
        for i, m in enumerate(self.belgeler, 1):
            b = m.belge
            self.tree_belge.insert("","end", values=(i, b.belge_no or f"Belge {i}", b.karar_turu,
                b.tesvik_turu, b.yatirim_turu, f"{b.bolge}", pf(b.toplam_sabit_yatirim),
                pf(m.toplam_katki), pf(m.kullanilan_katki), pf(m.kalan_katki)))
            tt += m.toplam_katki; tu += m.kullanilan_katki; tk_ += m.kalan_katki
        self.lbl_coklu.configure(text=f"{len(self.belgeler)} belge | Katki: {pf(tt)} | Kull: {pf(tu)} | Kalan: {pf(tk_)}")


    # ---- TAB 9: BELGE YUKLE ----
    def _build_tab9(self):
        container = ttk.Frame(self.tab9, padding=5)
        container.pack(fill="both", expand=True)

        # Ust: iki panel yan yana
        paned = ttk.PanedWindow(container, orient="horizontal")
        paned.pack(fill="both", expand=True)

        # SOL PANEL: KV Beyannamesi
        left = ttk.LabelFrame(paned, text="KV Beyannamesi (PDF)", padding=5)
        paned.add(left, weight=1)

        btn_bey = ttk.Frame(left)
        btn_bey.pack(fill="x")
        ttk.Button(btn_bey, text="PDF Yukle", command=self._beyanname_yukle).pack(side="left", padx=3)
        ttk.Button(btn_bey, text="Verileri Uygula", command=self._beyanname_uygula).pack(side="left", padx=3)
        ttk.Button(btn_bey, text="YKT Kontrol", command=self._beyanname_ykt_kontrol).pack(side="left", padx=3)
        ttk.Button(btn_bey, text="Temizle", command=self._beyanname_temizle).pack(side="right", padx=3)

        # Beyanname listesi (birden fazla donem yuklenebilir)
        self.tree_bey = ttk.Treeview(left, columns=("donem", "matrah", "ind_matrah", "ind_kv",
                                                      "hes_kv", "ykt_kull", "dosya"),
                                      show="headings", height=5)
        bey_hdrs = {"donem": ("Donem", 60), "matrah": ("KV Matrah", 100),
                    "ind_matrah": ("Ind.Matrah", 100), "ind_kv": ("Ind.KV", 90),
                    "hes_kv": ("Hes.KV", 90), "ykt_kull": ("YKT Kull.", 100),
                    "dosya": ("Dosya", 120)}
        for c, (h, w) in bey_hdrs.items():
            self.tree_bey.heading(c, text=h)
            self.tree_bey.column(c, width=w, anchor="e")
        self.tree_bey.column("dosya", anchor="w")
        self.tree_bey.pack(fill="x", pady=(5, 0))
        self.tree_bey.bind("<<TreeviewSelect>>", self._beyanname_secim)

        # Beyanname detay
        self.txt_bey = scrolledtext.ScrolledText(left, wrap="word", font=("Consolas", 8),
                                                  height=12, bg="#f8f9fa")
        self.txt_bey.pack(fill="both", expand=True, pady=(5, 0))

        # YKT kontrol sonucu
        self.lbl_bey_ykt = ttk.Label(left, text="", style="YKT.TLabel", wraplength=500)
        self.lbl_bey_ykt.pack(fill="x", pady=(3, 0))

        # SAG PANEL: Tesvik Belgesi
        right = ttk.LabelFrame(paned, text="Yatirim Tesvik Belgesi (Word)", padding=5)
        paned.add(right, weight=1)

        btn_tsv = ttk.Frame(right)
        btn_tsv.pack(fill="x")
        ttk.Button(btn_tsv, text="Word Yukle", command=self._tesvik_word_yukle).pack(side="left", padx=3)
        ttk.Button(btn_tsv, text="Tab A'ya Aktar", command=self._tesvik_word_aktar).pack(side="left", padx=3)
        ttk.Button(btn_tsv, text="Temizle", command=self._tesvik_word_temizle).pack(side="right", padx=3)

        # Tespit edilen alanlar tablosu
        self.tree_tsv = ttk.Treeview(right, columns=("alan", "deger"), show="headings", height=12)
        self.tree_tsv.heading("alan", text="Alan")
        self.tree_tsv.heading("deger", text="Tespit Edilen Deger")
        self.tree_tsv.column("alan", width=180)
        self.tree_tsv.column("deger", width=280)
        self.tree_tsv.pack(fill="x", pady=(5, 0))

        # Ham metin onizleme
        self.txt_tsv = scrolledtext.ScrolledText(right, wrap="word", font=("Consolas", 8),
                                                  height=8, bg="#f8f9fa")
        self.txt_tsv.pack(fill="both", expand=True, pady=(5, 0))

        self.lbl_tsv_durum = ttk.Label(right, text="", style="Result.TLabel")
        self.lbl_tsv_durum.pack(fill="x", pady=(3, 0))

        # Dahili veri
        self._beyanname_verileri = []  # her donem icin parse sonucu
        self._tesvik_parse = None  # son parse sonucu

    # ---- BEYANNAME ISLEMLERI ----
    def _beyanname_yukle(self):
        if not PDF_OK:
            messagebox.showerror("Hata", "pdfplumber yuklu degil.\nTerminalden: pip install pdfplumber")
            return
        dosya = filedialog.askopenfilename(
            title="KV Beyannamesi PDF Sec",
            filetypes=[("PDF", "*.pdf"), ("Tum Dosyalar", "*.*")])
        if not dosya:
            return

        result = BeyannameParser.parse(dosya)
        if "hata" in result:
            messagebox.showerror("Hata", f"PDF okunamadi:\n{result['hata']}")
            return

        v = result["veriler"]
        donem = v.get("donem_yil", "?")
        matrah = v.get("kv_matrahi", 0)
        ind_matrah = v.get("indirimli_matrah", 0)
        ind_kv = v.get("indirimli_kv", 0)
        hes_kv = v.get("hesaplanan_kv", 0)

        # --- FIRMA TANIMLAMA ---
        unvan = v.get("unvan", "").strip()
        vkn = v.get("vkn", "").strip()
        vergi_dairesi = v.get("vergi_dairesi", "").strip()
        eslesen = None

        if unvan or vkn:
            # Firma adini belirle: unvan varsa unvan, yoksa VKN
            firma_adi = unvan if unvan else f"VKN_{vkn}"

            # Mevcut firma combobox'ta var mi?
            mevcut_firmalar = self.veri_mgr.firma_listesi()
            eslesen = None
            for mf in mevcut_firmalar:
                # VKN veya unvan ile eslesme ara
                mevcut_veri = self.veri_mgr.yukle(mf)
                if mevcut_veri and mevcut_veri.get("vkn") == vkn and vkn:
                    eslesen = mf
                    break
                if mf.lower() == firma_adi.lower():
                    eslesen = mf
                    break

            if eslesen:
                # Mevcut firma bulundu, sec
                self.cmb_firma.set(eslesen)
                self.firma_adi = eslesen
                # Firma verisini yukle
                veri = self.veri_mgr.yukle(eslesen)
                if veri and "aktif_motor" in veri:
                    self.motor = HesaplamaMotoru.from_dict(veri["aktif_motor"])
                    self.belgeler = [HesaplamaMotoru.from_dict(b) for b in veri.get("belgeler", [])]
                    self._formu_doldur()
                    self._ykt_paneli_guncelle()
                    self._donem_tablosu_doldur()
            else:
                # Yeni firma olustur
                self.cmb_firma.set(firma_adi)
                self.firma_adi = firma_adi
                self.motor = None
                self.belgeler = []

            # Firma meta bilgilerini sakla (kaydetme sirasinda JSON'a yazilacak)
            self._firma_meta = {"unvan": unvan, "vkn": vkn, "vergi_dairesi": vergi_dairesi}

        # Matrahtan YKT hesapla
        kv_orani = kv_orani_yil(donem) if isinstance(donem, int) else VARSAYILAN_KV_ORANI
        if ind_matrah > 0 and self.motor:
            ind_kv_orani = self.motor.indirimli_kv_orani(kv_orani)
            ykt_kull = BeyannameParser.matrahtan_ykt_hesapla(ind_matrah, kv_orani, ind_kv_orani)
        else:
            ykt_kull = 0

        result["ykt_hesaplanan"] = ykt_kull
        self._beyanname_verileri.append(result)

        # Tabloya ekle
        dosya_adi = Path(dosya).name
        self.tree_bey.insert("", "end", values=(
            donem, pf(matrah), pf(ind_matrah), pf(ind_kv),
            pf(hes_kv), pf(ykt_kull), dosya_adi))

        # Detay goster
        self._beyanname_detay_goster(result)

        # Bilgilendirme mesaji
        firma_bilgi = ""
        if unvan:
            firma_bilgi += f"\nFirma: {unvan}"
        if vkn:
            firma_bilgi += f"\nVKN: {vkn}"
        if vergi_dairesi:
            firma_bilgi += f"\nVergi Dairesi: {vergi_dairesi}"
        if eslesen:
            firma_bilgi += "\n(Mevcut firma eslesti, verileri yuklendi)"
        elif unvan or vkn:
            firma_bilgi += "\n(Yeni firma tanimlandi)"

        # IKV tablosu varsa Tab A'ya otomatik aktar
        ikv_aktarildi = False
        if v.get("ikv_belge_no") and not self.motor:
            self._ikv_tab_a_aktar(v)
            ikv_aktarildi = True
            firma_bilgi += "\nIKV tablosu -> Tab A aktarildi"

        messagebox.showinfo("Basarili", f"{donem} donemi beyannamesi yuklendi.\n"
                            f"Tespit edilen alan: {len(v)}{firma_bilgi}")

        # IKV aktarildiysa otomatik hesaplama olustur
        if ikv_aktarildi:
            if messagebox.askyesno("Hesaplama", "Tesvik belgesi bilgileri aktarildi.\n"
                                   "Hesaplamayi otomatik olusturmak ister misiniz?"):
                self._olustur()

    def _ikv_tab_a_aktar(self, v):
        """Beyannamedeki IKV tablosu verilerini Tab A'ya aktar."""
        def _set(e, val):
            e.delete(0, "end")
            if val is not None:
                e.insert(0, pf(val) if isinstance(val, float) else str(val))

        _set(self.a_belge_no, v.get("ikv_belge_no", ""))
        _set(self.a_baslama, v.get("ikv_baslama", ""))
        _set(self.a_sabit_yatirim, v.get("ikv_toplam_yatirim", 0))

        # Yatirim turu esleme
        turu1 = v.get("ikv_yatirim_turu1", "")
        for yt in YATIRIM_TURU_LIST:
            if turu1.lower() in yt.lower() or yt.lower() in turu1.lower():
                self.a_yatirim_turu.set(yt)
                break

        # Tesvik turu esleme
        turu2 = v.get("ikv_yatirim_turu2", "")
        for tt in TESVIK_TURU_LIST:
            if any(kw in turu2.lower() for kw in tt.lower().split()):
                self.a_tesvik_turu.set(tt)
                break

        # Karar
        karar = v.get("ikv_karar", "")
        if "3305" in karar:
            self.a_karar.set("2012/3305 sayili BKK")
        elif "9903" in karar:
            self.a_karar.set("9903 sayili CB Karari")

        # Bolge
        bolge = v.get("ikv_bolge")
        if bolge:
            self.a_bolge.set(str(int(bolge)))

        # Oranlar
        if v.get("ikv_katki_orani"):
            _set(self.a_katki_oran, str(int(v["ikv_katki_orani"])))
        if v.get("ikv_indirim_orani"):
            _set(self.a_indirim_oran, str(int(v["ikv_indirim_orani"])))

        # %100 indirim kontrolu
        if v.get("ikv_indirim_orani") and int(v["ikv_indirim_orani"]) == 100:
            self.a_yuzde100.set(True)

    def _beyanname_secim(self, event=None):
        sel = self.tree_bey.selection()
        if sel:
            idx = self.tree_bey.index(sel[0])
            if idx < len(self._beyanname_verileri):
                self._beyanname_detay_goster(self._beyanname_verileri[idx])

    def _beyanname_detay_goster(self, result):
        self.txt_bey.configure(state="normal")
        self.txt_bey.delete("1.0", "end")
        v = result["veriler"]
        lines = ["=" * 50, "  BEYANNAME PARSE SONUCU", "=" * 50, ""]

        # Firma bilgileri
        if v.get("unvan") or v.get("vkn"):
            lines.append("  --- FIRMA BILGILERI ---")
            if v.get("unvan"):
                lines.append(f"  {'Unvan':<25}: {v['unvan']}")
            if v.get("vkn"):
                lines.append(f"  {'VKN':<25}: {v['vkn']}")
            if v.get("vergi_dairesi"):
                lines.append(f"  {'Vergi Dairesi':<25}: {v['vergi_dairesi']}")
            lines.append("")
            lines.append("  --- MALI VERILER ---")

        alan_labels = {
            "donem_yil": "Donem Yili", "ticari_kar": "Ticari Kar",
            "kkeg": "KKEG", "kv_matrahi": "KV Matrahi",
            "hesaplanan_kv": "Hesaplanan KV", "indirimli_matrah": "32/A Ind. Matrah",
            "indirimli_kv_orani": "32/A Ind. KV Orani (%)",
            "normal_matrah": "Genel Orana Tabi Matrah", "indirimli_kv": "Ind. KV (1065)",
            "gecmis_zarar": "Gecmis Yil Zarari", "istisna_kazanc": "Istisna Kazanclar",
            "ykt_toplam_ykt": "YKT Toplam", "ykt_donemde_kullanilan": "YKT Don. Kull.",
            "ykt_kumulatif_kullanilan": "YKT Kum. Kull.", "ykt_kalan_ykt": "YKT Kalan",
            "ykt_belge_no": "YKT Belge No",
        }

        # IKV Tablosu alanlari
        ikv_labels = {
            "ikv_belge_no": "Tesvik Belge No",
            "ikv_karar": "Karar",
            "ikv_baslama": "Yat. Baslama Tarihi",
            "ikv_yatirim_turu1": "Yatirim Turu 1",
            "ikv_yatirim_turu2": "Yatirim Turu 2",
            "ikv_toplam_yatirim": "Toplam Yatirim Tutari",
            "ikv_katki_orani": "Katki Orani (%)",
            "ikv_indirim_orani": "Indirim Orani (%)",
            "ikv_bolge": "Bolge",
            "ikv_indirimli_kv_orani": "Indirimli KV Orani (%)",
            "ikv_toplam_ykt": "Toplam YKT",
            "ikv_cari_harcama": "Cari Yil Harcama",
            "ikv_kumulatif_harcama": "Kumulatif Harcama",
            "ikv_hak_kazanilan_ykt": "Hak Kaz. YKT (Harcama)",
            "ikv_endeks_ykt": "Endeks YKT",
            "ikv_onceki_ykt_yatirim": "Onceki Don. YKT (Yatirim)",
            "ikv_onceki_ykt_diger": "Onceki Don. YKT (Diger)",
            "ikv_onceki_ykt_toplam": "Onceki Don. YKT (Toplam)",
            "ikv_cari_ykt_yatirim": "Cari Don. YKT (Yatirim)",
            "ikv_cari_ykt_diger": "Cari Don. YKT (Diger)",
            "ikv_cari_ykt_toplam": "Cari Don. YKT (Toplam)",
            "ikv_toplam_yararlanan": "Toplam Yararlanan YKT",
        }
        for key, label in alan_labels.items():
            if key in v:
                val = v[key]
                if isinstance(val, float):
                    lines.append(f"  {label:<25}: {pf(val)} TL")
                else:
                    lines.append(f"  {label:<25}: {val}")

        if result.get("ykt_hesaplanan"):
            lines.append("")
            lines.append(f"  {'MATRAHTAN HESAPLANAN YKT':<25}: {pf(result['ykt_hesaplanan'])} TL")

        # IKV Tablosu verileri
        ikv_keys = [k for k in v if k.startswith("ikv_")]
        if ikv_keys:
            lines.append("")
            lines.append("-" * 50)
            lines.append("  INDIRIMLI KV TABLOSU (32/A)")
            lines.append("-" * 50)
            for key, label in ikv_labels.items():
                if key in v:
                    val = v[key]
                    if isinstance(val, float):
                        lines.append(f"  {label:<30}: {pf(val)} TL")
                    else:
                        lines.append(f"  {label:<30}: {val}")

        # YKT tablo satirlari
        if result.get("ykt_tablosu"):
            lines.append("")
            lines.append("-" * 50)
            lines.append("  BEYANNAME EKI YKT TABLOSU")
            lines.append("-" * 50)
            for row in result["ykt_tablosu"]:
                lines.append("  " + " | ".join(row))

        self.txt_bey.insert("1.0", "\n".join(lines))
        self.txt_bey.configure(state="disabled")

    def _beyanname_ykt_kontrol(self):
        """Matrahtan hesaplanan YKT ile beyanname ekindeki YKT tablosunu karsilastirir."""
        if not self._beyanname_verileri:
            messagebox.showwarning("Uyari", "Once beyanname yukleyiniz.")
            return
        if not self.motor:
            messagebox.showwarning("Uyari", "Once hesaplama olusturunuz (Tab A).")
            return

        lines = []
        toplam_kull_bey = 0  # beyannameye gore toplam
        toplam_kull_hes = 0  # matrahtan hesaplanan toplam

        for r in self._beyanname_verileri:
            v = r["veriler"]
            donem = v.get("donem_yil", "?")
            ind_matrah = v.get("indirimli_matrah", 0)
            ykt_bey = v.get("ykt_donemde_kullanilan", 0)  # beyannameye yazilan
            ykt_hes = r.get("ykt_hesaplanan", 0)  # matrahtan hesaplanan

            toplam_kull_bey += ykt_bey
            toplam_kull_hes += ykt_hes

            fark = abs(ykt_bey - ykt_hes)
            durum = "OK" if fark < 1 else f"FARK: {pf(fark)} TL"
            lines.append(f"{donem}: Beyanname={pf(ykt_bey)} | Hesaplanan={pf(ykt_hes)} | {durum}")

        lines.append("")
        lines.append(f"TOPLAM: Beyanname={pf(toplam_kull_bey)} | Hesaplanan={pf(toplam_kull_hes)}")

        # Motor ile karsilastir
        if self.motor:
            motor_kull = self.motor.kullanilan_katki
            lines.append(f"Programdaki Kullanilan YKT: {pf(motor_kull)}")
            fark_motor = abs(motor_kull - toplam_kull_bey)
            if fark_motor > 1:
                lines.append(f"!!! Program/Beyanname Farki: {pf(fark_motor)} TL")
            else:
                lines.append("Program ile beyanname uyumlu.")

        self.lbl_bey_ykt.configure(text=" | ".join(lines[:2]))

        # Detaya yaz
        self.txt_bey.configure(state="normal")
        self.txt_bey.delete("1.0", "end")
        header = ["=" * 50, "  YKT CAPRAZ KONTROL RAPORU", "=" * 50, ""]
        self.txt_bey.insert("1.0", "\n".join(header + lines))
        self.txt_bey.configure(state="disabled")

    def _beyanname_uygula(self):
        """Secili beyannamenin verilerini hesaplamaya aktarir."""
        sel = self.tree_bey.selection()
        if not sel:
            messagebox.showwarning("Uyari", "Tablodan bir beyanname seciniz.")
            return
        idx = self.tree_bey.index(sel[0])
        if idx >= len(self._beyanname_verileri):
            return
        if not self.motor:
            messagebox.showwarning("Uyari", "Once hesaplama olusturunuz (Tab A).")
            return

        v = self._beyanname_verileri[idx]["veriler"]
        ykt_hes = self._beyanname_verileri[idx].get("ykt_hesaplanan", 0)

        # D sekmesine kazanc/matrah verilerini aktar
        def _set(e, val):
            e.delete(0, "end")
            if val:
                e.insert(0, pf(val) if isinstance(val, float) else str(val))

        donem_yil = v.get("donem_yil")
        if donem_yil:
            _set(self.d_yil, str(donem_yil))
        if v.get("ticari_kar"):
            _set(self.d_ticari, v["ticari_kar"])
        if v.get("kkeg"):
            _set(self.d_kkeg, v["kkeg"])
        if v.get("istisna_kazanc"):
            _set(self.d_istisna, v["istisna_kazanc"])
        if v.get("gecmis_zarar"):
            _set(self.d_gecmis_zarar, v["gecmis_zarar"])
        if v.get("kv_matrahi"):
            _set(self.d_kv_matrah, v["kv_matrahi"])

        # Devreden katki ve kullanilan bilgilerini guncelle
        if v.get("ykt_kumulatif_kullanilan"):
            self.motor.kullanilan_katki_isletme = v["ykt_kumulatif_kullanilan"]
        if v.get("ykt_kalan_ykt"):
            self.motor.devreden.devreden_katki = v["ykt_kalan_ykt"]

        # D tabindaki bilgi alanlarini guncelle
        self._ykt_paneli_guncelle()
        self._d_ykt_bilgi_guncelle()

        # F tabindaki devreden alanini guncelle
        if v.get("ykt_kalan_ykt"):
            self.f_devreden.delete(0, "end")
            self.f_devreden.insert(0, pf(v["ykt_kalan_ykt"]))

        # D sekmesine otomatik gec
        self.notebook.select(self.tab4)

        messagebox.showinfo("Basarili",
                            f"Beyanname verileri D sekmesine aktarildi.\n"
                            f"Matrahtan hesaplanan YKT: {pf(ykt_hes)} TL\n"
                            f"Kazanc/matrah alanlari dolduruldu.")

    def _beyanname_temizle(self):
        self._beyanname_verileri = []
        for item in self.tree_bey.get_children():
            self.tree_bey.delete(item)
        self.txt_bey.configure(state="normal")
        self.txt_bey.delete("1.0", "end")
        self.txt_bey.configure(state="disabled")
        self.lbl_bey_ykt.configure(text="")

    # ---- TESVIK BELGESI WORD ISLEMLERI ----
    def _tesvik_word_yukle(self):
        if not DOCX_OK:
            messagebox.showerror("Hata", "python-docx yuklu degil.\nTerminalden: pip install python-docx")
            return
        dosya = filedialog.askopenfilename(
            title="Yatirim Tesvik Belgesi Word Sec",
            filetypes=[("Word", "*.docx"), ("Tum Dosyalar", "*.*")])
        if not dosya:
            return

        result = TesvikBelgesiParser.parse(dosya)
        if "hata" in result:
            messagebox.showerror("Hata", f"Word okunamadi:\n{result['hata']}")
            return

        self._tesvik_parse = result
        v = result["veriler"]

        # Tabloyu doldur
        for item in self.tree_tsv.get_children():
            self.tree_tsv.delete(item)

        alan_labels = {
            "belge_no": "Belge No", "belge_tarihi": "Belge Tarihi",
            "yatirim_konusu": "Yatirim Konusu", "yatirim_turu": "Yatirim Turu (ham)",
            "yatirim_turu_mapped": "Yatirim Turu (eslenen)", "yatirim_yeri": "Yatirim Yeri",
            "toplam_sabit_yatirim": "Toplam Sabit Yatirim", "baslama_tarihi": "Baslama Tarihi",
            "bitis_tarihi": "Bitis Tarihi", "katki_orani": "Katki Orani (%)",
            "indirim_orani": "Indirim Orani (%)", "tesvik_unsuru": "Tesvik Unsuru",
            "makine_tutar_tablo": "Makine Tutari (tablo)", "insaat_tutar_tablo": "Insaat Tutari (tablo)",
        }
        for key, label in alan_labels.items():
            if key in v:
                val = v[key]
                if isinstance(val, float):
                    self.tree_tsv.insert("", "end", values=(label, pf(val)))
                else:
                    self.tree_tsv.insert("", "end", values=(label, val))

        if result.get("bolge_tahmini"):
            self.tree_tsv.insert("", "end", values=("Bolge (tahmini)", f"{result['bolge_tahmini']}. Bolge"))

        # Ham metin
        self.txt_tsv.configure(state="normal")
        self.txt_tsv.delete("1.0", "end")
        ham = result.get("ham_metin", "")
        if len(ham) > 3000:
            ham = ham[:3000] + "\n... (kesildi)"
        self.txt_tsv.insert("1.0", ham)
        self.txt_tsv.configure(state="disabled")

        self.lbl_tsv_durum.configure(text=f"{len(v)} alan tespit edildi. 'Tab A'ya Aktar' ile uygulayabilirsiniz.")
        messagebox.showinfo("Basarili", f"Tesvik belgesi okundu: {len(v)} alan tespit edildi.")

    def _tesvik_word_aktar(self):
        """Tespit edilen verileri Tab A'ya aktarir."""
        if not self._tesvik_parse:
            messagebox.showwarning("Uyari", "Once Word dosyasi yukleyiniz.")
            return
        v = self._tesvik_parse["veriler"]

        def _set(entry, val):
            entry.delete(0, "end")
            if val:
                entry.insert(0, str(val))

        if "belge_no" in v:
            _set(self.a_belge_no, v["belge_no"])
        if "belge_tarihi" in v:
            _set(self.a_belge_tarihi, v["belge_tarihi"])
        if "yatirim_konusu" in v:
            _set(self.a_konu, v["yatirim_konusu"])
        if "yatirim_turu_mapped" in v:
            try:
                self.a_yatirim_turu.set(v["yatirim_turu_mapped"])
            except:
                pass
        if "toplam_sabit_yatirim" in v:
            _set(self.a_sabit_yatirim, pf(v["toplam_sabit_yatirim"]))
        if "baslama_tarihi" in v:
            _set(self.a_baslama, v["baslama_tarihi"])
        if "bitis_tarihi" in v:
            _set(self.a_tamamlama, v["bitis_tarihi"])
        if "katki_orani" in v:
            _set(self.a_katki_oran, v["katki_orani"])
        if "indirim_orani" in v:
            _set(self.a_indirim_oran, v["indirim_orani"])
        if "makine_tutar_tablo" in v:
            _set(self.a_belge_makine, pf(v["makine_tutar_tablo"]))
        if "insaat_tutar_tablo" in v:
            _set(self.a_belge_insaat, pf(v["insaat_tutar_tablo"]))

        # Bolge tahmini
        bolge = self._tesvik_parse.get("bolge_tahmini")
        if bolge:
            try:
                self.a_bolge.set(str(bolge))
            except:
                pass

        self.notebook.select(self.tab1)
        messagebox.showinfo("Basarili",
                            f"{len(v)} alan Tab A'ya aktarildi.\n"
                            "Lutfen kontrol edip eksikleri tamamlayiniz.")

    def _tesvik_word_temizle(self):
        self._tesvik_parse = None
        for item in self.tree_tsv.get_children():
            self.tree_tsv.delete(item)
        self.txt_tsv.configure(state="normal")
        self.txt_tsv.delete("1.0", "end")
        self.txt_tsv.configure(state="disabled")
        self.lbl_tsv_durum.configure(text="")


# ============================================================================
# ANA GIRIS
# ============================================================================

if __name__ == "__main__":
    app = KVKApp()
    app.mainloop()
