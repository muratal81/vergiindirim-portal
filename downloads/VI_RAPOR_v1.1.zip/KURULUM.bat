@echo off
REM Gerekli Python paketlerini yukler (ilk kurulum icin)
echo Tam Tasdik Raporu - Hesap Incelemeleri programi icin
echo gerekli Python paketleri yukleniyor...
echo.
py -m pip install python-docx openpyxl pdfplumber flask
echo.
echo Kurulum tamamlandi. Artik su dosyalardan birini calistirabilirsiniz:
echo   - BASLAT_MASAUSTU.bat  (tkinter penceresi)
echo   - BASLAT_WEB.bat       (tarayicidan kullanim)
echo.
pause
