@echo off
REM ====================================================================
REM   TT Hesap Incelemeleri - MASAUSTU (tkinter) Modu Baslatici
REM ====================================================================
cd /d "%~dp0TT_HESAP_INCELEMELERI"
echo.
echo  Tam Tasdik Raporu - Hesap Incelemeleri
echo  Masaustu (tkinter) modu baslatiliyor...
echo.
py tt_hesap_incelemeleri.py
if errorlevel 1 (
    echo.
    echo  HATA: Program baslatilamadi.
    echo  Olasilikla Python veya gerekli paketler yuklu degil.
    echo  Lutfen su komutu calistirin:
    echo     py -m pip install python-docx openpyxl pdfplumber flask
    echo.
    pause
)
