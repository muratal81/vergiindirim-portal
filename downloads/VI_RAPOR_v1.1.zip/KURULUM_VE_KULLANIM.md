# Vİ Rapor — Hesap İncelemeleri Otomasyonu

Mizan (Excel) ve Kurumlar Vergisi Beyannamesi (PDF) dosyalarini okuyarak,
**"III- Hesap Incelemeleri"** (A. Bilanço Hesaplari + B. Gelir Tablosu Hesaplari)
bolumunu Microsoft Word (.docx) formatinda otomatik uretir.

- **Marka:** Vİ Rapor
- **Surum:** 1.1
- **Yayinci:** Murat Alan · https://vergiindirim.com.tr
- **Lisans:** Ticari (1 yil) · Lisans anahtariniza ve ZIP parolaniza yetkili
  bayinin onay mailinden ulasin.

---

## A. ZIP'i Acmak (ONEMLI)

Indirdiginiz ZIP **AES-256 ile sifrelidir**. Windows'un yerlesik ZIP destegi
AES-256'yi acamaz; bu yuzden once **7-Zip** (ucretsiz) kurmaniz gerekir:

1. https://www.7-zip.org/download.html adresinden indirin (Windows 64-bit MSI).
2. ZIP dosyasina sag tik -> **7-Zip -> Buraya cikar** veya **Buraya cikar (kendi
   klasoru ile)**.
3. Aciliste **ZIP Parolasi** istenir; onay mailindeki parolayi yapistirin.
4. Ciktida soyle bir klasor olusur:

```
VI_RAPOR_v1.1/
├── KURULUM.bat                 <- ilk kurulum
├── BASLAT_MASAUSTU.bat         <- tkinter masaustu modu
├── BASLAT_WEB.bat              <- tarayicidan kullanim modu
├── KURULUM_VE_KULLANIM.md      <- bu dosya
└── TT_HESAP_INCELEMELERI/      <- program kodu
    ├── tt_hesap_incelemeleri.py
    ├── docx_writer/
    ├── engine/
    ├── parsers/
    └── web/
```

---

## B. Ilk Kurulum

1. **Python 3.11+** yuklu olmali (yoksa https://python.org adresinden indirin;
   kurulum sirasinda **"Add Python to PATH"** kutusunu mutlaka isaretleyin).
2. Cikardiginiz klasorde **`KURULUM.bat`** dosyasina **cift tiklayin**.
3. Su paketler otomatik yuklenir: `python-docx`, `openpyxl`, `pdfplumber`,
   `flask`.
4. Kurulum bittiginde pencere **"Kurulum tamamlandi"** yazar; herhangi bir tusa
   basip kapatin.

---

## C. Calistirma

Iki kullanim sekli vardir; tercihinize gore birini secin.

### Yontem 1 — Web (Tarayici) Modu (TAVSIYE EDILEN)

1. **`BASLAT_WEB.bat`** dosyasina cift tiklayin.
2. Varsayilan tarayiciniz otomatik olarak `http://localhost:5000` adresini acar.
3. Form uzerinden:
   - **Dosyalar:** Mizan Excel + Beyanname PDF yukleyin
   - **Mukellef:** beyannameden otomatik dolar
   - **Kur:** 31.12.2024 icin 580 No.lu VUK GT kurlari hazirdir
   - **Raporu Uret:** butona basinca .docx otomatik indirilir
4. Sunucuyu kapatmak icin **BASLAT_WEB.bat** penceresinde **Ctrl+C** basin.

### Yontem 2 — Masaustu (tkinter) Modu

1. **`BASLAT_MASAUSTU.bat`** dosyasina cift tiklayin.
2. Sekmeler arasinda gezinerek dosyalari ve bilgileri girin.
3. **"RAPORU URET"** butonuna basin.
4. Cikti, programin bulundugu klasor altindaki gecici klasore kaydedilir.

---

## D. Lisans ve Online Dogrulama

- Lisansiniz 1 yil gecerlidir. Program **her acilista** internete cikip
  `https://vergiindirim.com.tr/api/lisans-dogrula` adresinden anahtarinizi
  kontrol eder.
- Lisans iptal edildiyse veya suresi gectiyse program calismaz.
- ZIP icindeki `_LISANS.txt` dosyasi sizin lisans bilgilerinizi tasir; bu
  dosyayi **silmeyin** veya degistirmeyin.
- Lisans ve parola **kisiseldir**; paylasilamaz, kopyalanamaz.
  Telif hakki ihlali 5846 sk. m.71 uyarinca yaptirima tabidir.

---

## E. Cikti Yapisi

Uretilen Word dosyasi:

- Kapak sayfasi (mukellef, donem, rapor no, yetkili)
- Mutabakat bulgulari tablosu (varsa - sari/kirmizi uyarilar)
- **III- HESAP INCELEMELERI**
  - **A. Bilanco Hesaplarina Iliskin Incelemeler**
    - Yabanci para hesaplari + doviz tablolari
    - Diger bilanco hesaplari (Cekler, Menkul Kiymetler, Supheli Alacaklar,
      Stoklar, MDV, MODV, Borclar)
    - Ozkaynaklar (Sermaye, Yedekler, Ozel Fonlar, Donem Kari)
  - **B. Gelir Tablosu Hesaplari**
    - Satislar, Maliyetler, Faaliyet Giderleri
    - Diger Olagan Gelir/Giderler
    - Finansman Giderleri (KVK m.11/1-i FGK hesabi otomatik)
    - Olagandisi kalemler
    - Donem Kari ve Vergi Karsiligi

---

## F. Onemli Notlar

- **Veri uydurmaz:** Eksik veride ilgili bolum bos kalir veya uyari uretir.
- **Capraz mutabakat:** Program kesin rapor metni uretmeden once
  beyanname-mizan capraz kontrolu yapar. Kritik fark varsa bulgular tablosunda
  kirmizi olarak listelenir.
- **Tutar formati:** `1.234.567,89-TL`; negatifler `(1.234.567,89-TL)`.
- **Yabanci para hesaplari** icin 28.01.2025 tarih ve 580 No.lu VUK GT
  ekindeki kurlar varsayilan; gerekirse arayuzden degistirilebilir.

---

## G. MVP Sinirlamalari

Su kalemler **manuel kontrol/ekleme** gerektirir (mevcut surum henuz
uretmiyor; takip eden surumlerde eklenecek):

- C. Diger Incelemeler (Gecici Vergi, Tevkifat, KKEG, Istisnalar)
- EK-1 Bilanco / EK-2 Gelir Tablosu mali tablo ekleri
- KKM Istisnasi (KVK Gecici m.14) detay tablosu
- AR-GE indirimi detayi (5746 SK)
- Yatirim Tesvik Belgesi kapsaminda Indirimli Kurumlar Vergisi
- Bagis ve Yardimlar detayi
- 7440 SK matrah artirimi
- Banka bazinda stopaj/tevkifat tablosu

---

## H. Destek

- **E-posta:** info@vergiindirim.com.tr
- **Telefon:** 0532 177 47 95
- **Web:** https://vergiindirim.com.tr
- **Adres:** Kizilirmak Mah. Muhsin Yazicioglu Cd. No: 29/19 Cankaya / Ankara
