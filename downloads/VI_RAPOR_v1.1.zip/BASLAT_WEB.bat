@echo off
REM ====================================================================
REM   TT Hesap Incelemeleri - WEB (Flask) Modu Baslatici
REM ====================================================================
cd /d "%~dp0TT_HESAP_INCELEMELERI"
echo.
echo  Tam Tasdik Raporu - Hesap Incelemeleri
echo  Web sunucusu baslatiliyor... (Otomatik olarak tarayicida acilacak)
echo  Adres: http://localhost:5000
echo.
echo  Sunucuyu kapatmak icin Ctrl+C basin veya bu pencereyi kapatin.
echo.
py web\server.py
if errorlevel 1 (
    echo.
    echo  HATA: Web sunucusu baslatilamadi.
    echo  Olasilikla Python veya Flask yuklu degil.
    echo  Lutfen su komutu calistirin:
    echo     py -m pip install python-docx openpyxl pdfplumber flask
    echo.
    pause
)
