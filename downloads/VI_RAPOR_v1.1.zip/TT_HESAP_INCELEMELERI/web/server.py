"""Flask web sunucusu - TT Hesap Incelemeleri Raporu icin tarayici arayuzu.

Calistirma:
    py web/server.py

Tarayicida acin:
    http://localhost:5000
"""
import os
import sys
import tempfile
import threading
import webbrowser
from datetime import datetime
from pathlib import Path

from flask import Flask, render_template, request, send_file, jsonify

# Modul yolu - bir ust dizini ekle (TT_HESAP_INCELEMELERI/)
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from parsers.mizan_parser import parse_mizan, parse_dovizli_mizan
from parsers.kur_hesaplama_parser import parse_kur_hesaplama
from parsers.bilanco_parser import parse_bilanco, parse_gelir_tablosu
from parsers.beyanname_parser import parse_beyanname
from engine.data_model import RaporVerisi, MukellefBilgileri, KurTablosu, BeyannameVerisi
from engine.mutabakat import kontrolleri_calistir
from engine.rapor_motoru import hesap_incelemeleri_uret
from docx_writer.rapor_yazici import yaz_word_raporu

# Kalici cikti klasoru (program klasoru altinda)
OUTPUT_DIR = BASE_DIR / "ornek_ciktilar"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__, template_folder=str(Path(__file__).parent / "templates"),
            static_folder=str(Path(__file__).parent / "static"))
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024  # 100 MB upload limiti


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/onizle-beyanname", methods=["POST"])
def onizle_beyanname():
    """Beyanname yuklendiginde mukellef bilgilerini cikarir."""
    f = request.files.get("beyanname")
    if not f:
        return jsonify({"error": "Beyanname yuklenmedi"}), 400
    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tf:
        f.save(tf.name)
        tmp_path = tf.name
    try:
        bv = parse_beyanname(tmp_path)
        donem_baslangic = ""
        donem_bitis = ""
        if bv.donem and "-" in bv.donem:
            parts = bv.donem.split("-")
            if len(parts) == 2:
                donem_baslangic = parts[0]
                donem_bitis = parts[1]
        return jsonify({
            "vergi_no": bv.vergi_no,
            "unvan": bv.unvan,
            "vergi_dairesi": bv.vergi_dairesi,
            "donem_baslangic": donem_baslangic,
            "donem_bitis": donem_bitis,
            "ticari_bilanco_kari": bv.ticari_bilanco_kari,
            "kkeg_toplam": bv.kkeg_toplam,
            "matrah": bv.matrah,
            "hesaplanan_vergi": bv.hesaplanan_vergi,
            "yil_ici_kesinti": bv.yil_ici_kesinti,
        })
    finally:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass


@app.route("/api/rapor-uret", methods=["POST"])
def rapor_uret():
    """Mizan + Beyanname + form verileriyle Word raporu uret."""
    mizan_file = request.files.get("mizan")
    kur_hesaplama_file = request.files.get("kur_hesaplama")
    beyanname_file = request.files.get("beyanname")
    if not mizan_file:
        return jsonify({"error": "Mizan Excel dosyasi zorunludur."}), 400

    form = request.form

    # Mizan dosyasini gecici olarak kaydet
    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tf:
        mizan_file.save(tf.name)
        mizan_tmp = tf.name

    beyanname_tmp = None
    kur_hesaplama_tmp = None
    if kur_hesaplama_file and kur_hesaplama_file.filename:
        with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tf:
            kur_hesaplama_file.save(tf.name)
            kur_hesaplama_tmp = tf.name

    if beyanname_file:
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tf:
            beyanname_file.save(tf.name)
            beyanname_tmp = tf.name

    try:
        mizan_sheet = form.get("mizan_sheet", "Mizan")
        dovizli_sheet = form.get("dovizli_mizan_sheet", "Dövizli Mizan")
        bilanco_sheet = form.get("bilanco_sheet", "Bilanço")
        gelir_sheet = form.get("gelir_tablosu_sheet", "Gelir Tablosu")
        hedef_donem = form.get("hedef_donem", "31.12.2024")

        mizan = parse_mizan(mizan_tmp, sheet_name=mizan_sheet)
        dovizli = parse_dovizli_mizan(mizan_tmp, sheet_name=dovizli_sheet)
        kur_hesaplama_satirlari = parse_kur_hesaplama(kur_hesaplama_tmp) if kur_hesaplama_tmp else []
        try:
            bilanco = parse_bilanco(mizan_tmp, sheet_name=bilanco_sheet, hedef_donem=hedef_donem)
        except Exception:
            bilanco = []
        try:
            gelir = parse_gelir_tablosu(mizan_tmp, sheet_name=gelir_sheet, hedef_donem=hedef_donem)
        except Exception:
            gelir = []

        if beyanname_tmp:
            beyanname = parse_beyanname(beyanname_tmp)
        else:
            beyanname = BeyannameVerisi()

        def _to_float(s):
            try:
                return float(str(s).replace(",", "."))
            except Exception:
                return 0.0

        mukellef = MukellefBilgileri(
            vergi_no=form.get("vergi_no", "") or beyanname.vergi_no,
            unvan=form.get("unvan", "") or beyanname.unvan,
            vergi_dairesi=form.get("vergi_dairesi", "") or beyanname.vergi_dairesi,
            donem_baslangic=form.get("donem_baslangic", "01.01.2024"),
            donem_bitis=form.get("donem_bitis", "31.12.2024"),
            rapor_no=form.get("rapor_no", ""),
            ymm_adi=form.get("ymm_adi", ""),
        )
        kurlar = KurTablosu(
            teblig_tarihi=form.get("kur_teblig_tarihi", "28.01.2025"),
            teblig_no=form.get("kur_teblig_no", "580"),
            usd_alis=_to_float(form.get("usd_alis", "35.2233")),
            usd_efektif_alis=_to_float(form.get("usd_efektif", "35.1987")),
            eur_alis=_to_float(form.get("eur_alis", "36.7429")),
            eur_efektif_alis=_to_float(form.get("eur_efektif", "36.7172")),
            gbp_alis=_to_float(form.get("gbp_alis", "44.2458")),
            chf_alis=_to_float(form.get("chf_alis", "38.9510")),
        )

        rapor = RaporVerisi(
            mukellef=mukellef,
            mizan=mizan,
            dovizli_mizan=dovizli,
            bilanco=bilanco,
            gelir_tablosu=gelir,
            beyanname=beyanname,
            kurlar=kurlar,
            kur_hesaplama_satirlari=kur_hesaplama_satirlari,
        )
        kontrolleri_calistir(rapor)
        bloklar = hesap_incelemeleri_uret(rapor)

        tarih_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        unvan_kisa = (mukellef.unvan or "RAPOR").replace(" ", "_").replace("/", "_")[:40]
        out_filename = f"TT_Hesap_Incelemeleri_{unvan_kisa}_{tarih_str}.docx"
        out_path = OUTPUT_DIR / out_filename
        yaz_word_raporu(rapor, bloklar, str(out_path))

        return send_file(
            str(out_path),
            as_attachment=True,
            download_name=out_filename,
            mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )

    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        return jsonify({"error": str(e), "traceback": tb}), 500
    finally:
        try:
            os.unlink(mizan_tmp)
        except Exception:
            pass
        if beyanname_tmp:
            try:
                os.unlink(beyanname_tmp)
            except Exception:
                pass
        if kur_hesaplama_tmp:
            try:
                os.unlink(kur_hesaplama_tmp)
            except Exception:
                pass


def _open_browser():
    webbrowser.open("http://localhost:5000")


def main():
    # Tarayiciyi otomatik ac
    threading.Timer(1.5, _open_browser).start()
    app.run(host="127.0.0.1", port=5000, debug=False)


if __name__ == "__main__":
    main()
