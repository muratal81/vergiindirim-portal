"""TAM TASDIK RAPORU - HESAP INCELEMELERI OTOMASYONU

Mizan (Excel) + Kurumlar Vergisi Beyannamesi (PDF) okuyarak
III- Hesap Incelemeleri bolumunu Word olarak ureten masaustu program.

Kullanim: py tt_hesap_incelemeleri.py
"""
import os
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path
from datetime import datetime

# Modul yolu
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from parsers.mizan_parser import parse_mizan, parse_dovizli_mizan
from parsers.kur_hesaplama_parser import parse_kur_hesaplama
from parsers.yeniden_degerleme_parser import parse_yeniden_degerleme
from parsers.bilanco_parser import parse_bilanco, parse_gelir_tablosu
from parsers.beyanname_parser import parse_beyanname
from parsers.gecici_vergi_parser import parse_gecici_vergi
from engine.data_model import RaporVerisi, MukellefBilgileri, KurTablosu
from engine.mutabakat import kontrolleri_calistir
from engine.rapor_motoru import hesap_incelemeleri_uret
from docx_writer.rapor_yazici import yaz_word_raporu


class TTHesapIncelemeleriApp:
    # Kurumsal renk paleti (lacivert / altin)
    NAVY = "#102A43"
    NAVY_2 = "#1B3A5B"
    GOLD = "#C8A24B"
    GOLD_DK = "#A9863A"
    BG = "#EEF2F6"
    CARD = "#FFFFFF"
    INK = "#1F2937"
    MUTED = "#64748B"
    LINE = "#D7DEE6"
    GREEN = "#1E7E34"
    RED = "#C0392B"
    ORANGE = "#C77700"

    def __init__(self, root):
        self.root = root
        self.root.title("Tam Tasdik Raporu — Hesap İncelemeleri Otomasyonu v1.0")
        self.root.geometry("1000x780")
        self.root.minsize(940, 720)
        self.status_labels = {}

        self.mizan_path = tk.StringVar()
        self.kur_hesaplama_path = tk.StringVar()
        self.yeniden_degerleme_path = tk.StringVar()
        self.beyanname_path = tk.StringVar()
        self.gecici_vergi_paths = []  # list[str] - secilen KGV PDF'leri
        self.output_dir = tk.StringVar(value=str(Path.cwd()))
        self.mizan_sheet = tk.StringVar(value="Mizan")
        self.dovizli_mizan_sheet = tk.StringVar(value="Dövizli Mizan")
        self.bilanco_sheet = tk.StringVar(value="Bilanço")
        self.gelir_tablosu_sheet = tk.StringVar(value="Gelir Tablosu")
        self.hedef_donem = tk.StringVar(value="31.12.2024")

        self.vergi_no = tk.StringVar()
        self.unvan = tk.StringVar()
        self.vergi_dairesi = tk.StringVar(value="ANKARA KURUMLAR")
        self.donem_baslangic = tk.StringVar(value="01.01.2024")
        self.donem_bitis = tk.StringVar(value="31.12.2024")
        self.rapor_no = tk.StringVar()
        self.ymm_adi = tk.StringVar()

        self.kur_teblig_tarihi = tk.StringVar(value="28.01.2025")
        self.kur_teblig_no = tk.StringVar(value="580")
        self.usd_alis = tk.StringVar(value="35.2233")
        self.usd_efektif = tk.StringVar(value="35.1987")
        self.eur_alis = tk.StringVar(value="36.7429")
        self.eur_efektif = tk.StringVar(value="36.7172")
        self.gbp_alis = tk.StringVar(value="44.2458")
        self.chf_alis = tk.StringVar(value="38.9510")

        self._build_ui()

    def _build_ui(self):
        self._configure_styles()
        self._build_header()

        notebook = ttk.Notebook(self.root)
        notebook.pack(fill="both", expand=True, padx=16, pady=12)

        # Sekme 1: Dosya secimi
        tab1 = ttk.Frame(notebook)
        notebook.add(tab1, text="  1 · Dosyalar  ")
        self._build_files_tab(tab1)

        # Sekme 2: Mukellef bilgileri
        tab2 = ttk.Frame(notebook)
        notebook.add(tab2, text="  2 · Mükellef  ")
        self._build_mukellef_tab(tab2)

        # Sekme 3: Kur parametreleri
        tab3 = ttk.Frame(notebook)
        notebook.add(tab3, text="  3 · Döviz Kurları  ")
        self._build_kur_tab(tab3)

        # Sekme 4: Calistir
        tab4 = ttk.Frame(notebook)
        notebook.add(tab4, text="  4 · Rapor Üret  ")
        self._build_run_tab(tab4)

        self._build_statusbar()

        # Dosya alanlari degistikce durum gostergelerini guncelle
        for var in (self.mizan_path, self.beyanname_path, self.kur_hesaplama_path,
                    self.yeniden_degerleme_path, self.output_dir):
            var.trace_add("write", self._update_status)
        self._update_status()

    def _configure_styles(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        self.root.configure(bg=self.BG)

        style.configure(".", font=("Segoe UI", 10))
        style.configure("TFrame", background=self.BG)
        style.configure("TLabel", background=self.BG, foreground=self.INK)
        style.configure("TSeparator", background=self.LINE)

        # Beyaz "kart" gorunumlu LabelFrame
        style.configure("Card.TLabelframe", background=self.CARD, relief="solid",
                        borderwidth=1, padding=14)
        style.configure("Card.TLabelframe.Label", background=self.CARD,
                        foreground=self.NAVY, font=("Segoe UI Semibold", 11))
        style.configure("Card.TLabel", background=self.CARD, foreground=self.INK)
        style.configure("Hint.TLabel", background=self.CARD, foreground=self.MUTED,
                        font=("Segoe UI", 9))
        style.configure("FieldHint.TLabel", background=self.BG, foreground=self.MUTED,
                        font=("Segoe UI", 9))

        # Giris alanlari
        style.configure("TEntry", fieldbackground="#FFFFFF", bordercolor=self.LINE,
                        relief="solid", padding=4)

        # Notebook sekmeleri
        style.configure("TNotebook", background=self.BG, borderwidth=0, tabmargins=(4, 6, 4, 0))
        style.configure("TNotebook.Tab", padding=(18, 10), font=("Segoe UI Semibold", 10),
                        background="#DCE3EB", foreground=self.MUTED, borderwidth=0)
        style.map("TNotebook.Tab",
                  background=[("selected", self.CARD)],
                  foreground=[("selected", self.NAVY)],
                  expand=[("selected", (1, 1, 1, 0))])

        # Butonlar
        style.configure("TButton", padding=(12, 6), font=("Segoe UI", 10),
                        background="#E2E8F0", foreground=self.INK, borderwidth=0)
        style.map("TButton", background=[("active", "#CBD5E1")])

        # Ikincil (Sec...) buton
        style.configure("Pick.TButton", padding=(14, 6), font=("Segoe UI Semibold", 10),
                        background=self.NAVY, foreground="#FFFFFF", borderwidth=0)
        style.map("Pick.TButton", background=[("active", self.NAVY_2)])

        # Ana eylem butonu (altin) - goze carpan
        style.configure("Accent.TButton", font=("Segoe UI Semibold", 13),
                        foreground=self.NAVY, background=self.GOLD,
                        padding=(16, 14), borderwidth=0)
        style.map("Accent.TButton",
                  background=[("active", self.GOLD_DK)],
                  foreground=[("active", "#FFFFFF")])

    def _build_header(self):
        header = tk.Frame(self.root, bg=self.NAVY, height=78)
        header.pack(fill="x", side="top")
        header.pack_propagate(False)
        inner = tk.Frame(header, bg=self.NAVY)
        inner.pack(fill="both", expand=True, padx=22, pady=12)
        tk.Label(inner, text="Tam Tasdik Raporu — Hesap İncelemeleri",
                 bg=self.NAVY, fg="#FFFFFF", font=("Segoe UI Semibold", 17)).pack(anchor="w")
        tk.Label(inner,
                 text="Mizan + Kurumlar Vergisi Beyannamesi  →  “III- Hesap İncelemeleri” Word çıktısı",
                 bg=self.NAVY, fg=self.GOLD, font=("Segoe UI", 10)).pack(anchor="w", pady=(2, 0))
        # Altin vurgu seridi
        tk.Frame(self.root, bg=self.GOLD, height=3).pack(fill="x", side="top")

    def _build_statusbar(self):
        bar = tk.Frame(self.root, bg="#DDE4EC", height=30)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)
        self.status_label = tk.Label(bar, text="Hazır", bg="#DDE4EC", fg="#334155",
                                     font=("Segoe UI", 9), anchor="w")
        self.status_label.pack(side="left", padx=14)

    # ------------------ DURUM GOSTERGELERI --------------------
    def _status_dot(self, parent, key, row, col):
        lbl = tk.Label(parent, text="●  Seçilmedi", bg=self.CARD, fg="#9AA7B5",
                       font=("Segoe UI Semibold", 9))
        lbl.grid(row=row, column=col, padx=10, sticky="w")
        self.status_labels[key] = lbl

    def _update_status(self, *args):
        for key, var, is_dir in (
            ("mizan", self.mizan_path, False),
            ("beyanname", self.beyanname_path, False),
            ("kur", self.kur_hesaplama_path, False),
            ("yd", self.yeniden_degerleme_path, False),
            ("output", self.output_dir, True),
        ):
            lbl = self.status_labels.get(key)
            if lbl is None:
                continue
            val = var.get()
            ok = bool(val) and (is_dir or os.path.exists(val))
            if ok:
                lbl.config(text="●  Yüklendi", fg=self.GREEN)
            else:
                lbl.config(text="●  Seçilmedi", fg="#9AA7B5")
        gv = self.status_labels.get("gv")
        if gv is not None:
            n = len(self.gecici_vergi_paths)
            gv.config(text=(f"●  {n} dosya" if n else "●  Seçilmedi"),
                      fg=(self.GREEN if n else "#9AA7B5"))
        if getattr(self, "status_label", None) is not None:
            if self.mizan_path.get():
                self.status_label.config(text="Mizan seçildi — raporu üretebilirsiniz (4 · Rapor Üret).")
            else:
                self.status_label.config(text="Başlamak için 1 · Dosyalar sekmesinden Mizan Excel dosyasını seçin.")

    def _build_files_tab(self, parent):
        wrap = ttk.Frame(parent)
        wrap.pack(fill="both", expand=True, padx=14, pady=10)

        # 1) Mizan / Bilanco Excel
        frm = ttk.LabelFrame(wrap, text="① Mizan / Bilanço Excel Dosyası  (zorunlu)",
                             style="Card.TLabelframe")
        frm.pack(fill="x", pady=(0, 12))
        frm.columnconfigure(0, weight=1)
        ttk.Entry(frm, textvariable=self.mizan_path).grid(row=0, column=0, padx=(0, 8), pady=4, sticky="ew")
        ttk.Button(frm, text="Seç…", style="Pick.TButton", command=self._sec_mizan).grid(row=0, column=1)
        self._status_dot(frm, "mizan", row=0, col=2)

        sheets = ttk.Frame(frm, style="Card.TLabelframe")
        sheets.grid(row=1, column=0, columnspan=3, sticky="ew", pady=(8, 0))
        for i, (lbl, var) in enumerate([
            ("Mizan sayfası", self.mizan_sheet),
            ("Dövizli Mizan sayfası", self.dovizli_mizan_sheet),
            ("Bilanço sayfası", self.bilanco_sheet),
            ("Gelir Tablosu sayfası", self.gelir_tablosu_sheet),
            ("Hedef dönem (gg.aa.yyyy)", self.hedef_donem),
        ]):
            r, c = divmod(i, 2)
            cell = ttk.Frame(sheets, style="Card.TLabelframe")
            cell.grid(row=r, column=c, sticky="w", padx=(0, 24), pady=3)
            ttk.Label(cell, text=lbl + ":", style="Card.TLabel",
                      width=24, anchor="w").pack(side="left")
            ttk.Entry(cell, textvariable=var, width=22).pack(side="left")

        # 2) Kur hesaplama Excel
        frm_kur = ttk.LabelFrame(wrap, text="② Kur Hesaplama / Yabancı Para Excel Dosyası  (opsiyonel)",
                                 style="Card.TLabelframe")
        frm_kur.pack(fill="x", pady=(0, 12))
        frm_kur.columnconfigure(0, weight=1)
        ttk.Entry(frm_kur, textvariable=self.kur_hesaplama_path).grid(row=0, column=0, padx=(0, 8), pady=4, sticky="ew")
        ttk.Button(frm_kur, text="Seç…", style="Pick.TButton", command=self._sec_kur_hesaplama).grid(row=0, column=1)
        self._status_dot(frm_kur, "kur", row=0, col=2)
        ttk.Label(frm_kur, style="Hint.TLabel", wraplength=860, text=(
            "Dövizli mizan yoksa yabancı para tabloları öncelikle bu Excel'den okunur; "
            "kur ve TL karşılıkları VUK kurlarıyla kontrol edilir."
        )).grid(row=1, column=0, columnspan=3, sticky="w", pady=(6, 0))

        # 3) Yeniden Degerleme Tablosu Excel (VUK Muk. 298/C)
        frm_yd = ttk.LabelFrame(wrap, text="③ Yeniden Değerleme Tablosu Excel (VUK Mük. 298/Ç)  (opsiyonel)",
                                style="Card.TLabelframe")
        frm_yd.pack(fill="x", pady=(0, 12))
        frm_yd.columnconfigure(0, weight=1)
        ttk.Entry(frm_yd, textvariable=self.yeniden_degerleme_path).grid(row=0, column=0, padx=(0, 8), pady=4, sticky="ew")
        ttk.Button(frm_yd, text="Seç…", style="Pick.TButton", command=self._sec_yeniden_degerleme).grid(row=0, column=1)
        self._status_dot(frm_yd, "yd", row=0, col=2)
        ttk.Label(frm_yd, style="Hint.TLabel", wraplength=860, text=(
            "Sabit kıymet bazlı yeniden değerleme listesi yüklenirse, Sermaye Yedekleri (522) bölümüne "
            "hesap bazında özet tablo (aktif değerleme, birikmiş amortisman artışı, net değerleme) eklenir."
        )).grid(row=1, column=0, columnspan=3, sticky="w", pady=(6, 0))

        # 4) Kurumlar Vergisi Beyannamesi PDF
        frm2 = ttk.LabelFrame(wrap, text="④ Kurumlar Vergisi Beyannamesi PDF  (önerilir)",
                              style="Card.TLabelframe")
        frm2.pack(fill="x", pady=(0, 12))
        frm2.columnconfigure(0, weight=1)
        ttk.Entry(frm2, textvariable=self.beyanname_path).grid(row=0, column=0, padx=(0, 8), pady=4, sticky="ew")
        ttk.Button(frm2, text="Seç…", style="Pick.TButton", command=self._sec_beyanname).grid(row=0, column=1)
        self._status_dot(frm2, "beyanname", row=0, col=2)
        ttk.Label(frm2, style="Hint.TLabel", wraplength=860, text=(
            "Yüklendiğinde mükellef bilgileri ve yabancı para pozisyonu otomatik okunur."
        )).grid(row=1, column=0, columnspan=3, sticky="w", pady=(6, 0))

        # 5) Gecici Vergi
        frm_gv = ttk.LabelFrame(wrap, text="⑤ Geçici Vergi Beyannameleri (KGV PDF — çoklu)  (opsiyonel)",
                                style="Card.TLabelframe")
        frm_gv.pack(fill="x", pady=(0, 12))
        frm_gv.columnconfigure(0, weight=1)
        self.gecici_vergi_listbox = tk.Listbox(frm_gv, height=4, relief="solid", borderwidth=1,
                                               highlightthickness=0, font=("Segoe UI", 9))
        self.gecici_vergi_listbox.grid(row=0, column=0, padx=(0, 8), pady=4, sticky="ew")
        btn_frm = ttk.Frame(frm_gv, style="Card.TLabelframe")
        btn_frm.grid(row=0, column=1, sticky="n")
        ttk.Button(btn_frm, text="Ekle…", style="Pick.TButton", command=self._sec_gecici_vergi).pack(fill="x", pady=(0, 4))
        ttk.Button(btn_frm, text="Temizle", command=self._temizle_gecici_vergi).pack(fill="x")
        self._status_dot(frm_gv, "gv", row=0, col=2)
        ttk.Label(frm_gv, style="Hint.TLabel", wraplength=860, text=(
            "1./2./3./4. dönem beyannameleri 'C. Diğer İncelemeler' bölümünde dönem-kolonlu tablo olur."
        )).grid(row=1, column=0, columnspan=3, sticky="w", pady=(6, 0))

        # 6) Cikti klasoru
        frm3 = ttk.LabelFrame(wrap, text="⑥ Çıktı Klasörü", style="Card.TLabelframe")
        frm3.pack(fill="x")
        frm3.columnconfigure(0, weight=1)
        ttk.Entry(frm3, textvariable=self.output_dir).grid(row=0, column=0, padx=(0, 8), pady=4, sticky="ew")
        ttk.Button(frm3, text="Seç…", style="Pick.TButton", command=self._sec_output).grid(row=0, column=1)
        self._status_dot(frm3, "output", row=0, col=2)

    def _build_mukellef_tab(self, parent):
        wrap = ttk.Frame(parent)
        wrap.pack(fill="both", expand=True, padx=14, pady=10)
        frm = ttk.LabelFrame(wrap, text="Mükellef ve Dönem Bilgileri", style="Card.TLabelframe")
        frm.pack(fill="x")
        row = 0
        for label, var, width in [
            ("Vergi Kimlik Numarası", self.vergi_no, 25),
            ("Ünvan", self.unvan, 60),
            ("Vergi Dairesi", self.vergi_dairesi, 40),
            ("Dönem Başlangıç (gg.aa.yyyy)", self.donem_baslangic, 20),
            ("Dönem Bitiş (gg.aa.yyyy)", self.donem_bitis, 20),
            ("Rapor Numarası", self.rapor_no, 40),
            ("YMM Adı", self.ymm_adi, 50),
        ]:
            ttk.Label(frm, text=label + ":", style="Card.TLabel", width=28, anchor="w").grid(
                row=row, column=0, sticky="w", pady=6)
            ttk.Entry(frm, textvariable=var, width=width).grid(row=row, column=1, sticky="w", pady=6)
            row += 1

        ttk.Label(wrap, style="FieldHint.TLabel", justify="left", text=(
            "Bu bilgiler raporun kapağında kullanılır. Beyanname yüklendiğinde otomatik doldurulur; "
            "dilediğiniz gibi düzeltebilirsiniz."
        )).pack(anchor="w", pady=(12, 0))

    def _build_kur_tab(self, parent):
        wrap = ttk.Frame(parent)
        wrap.pack(fill="both", expand=True, padx=14, pady=10)
        frm = ttk.LabelFrame(wrap, text="Yıl Sonu Döviz Kurları (VUK Genel Tebliği)",
                             style="Card.TLabelframe")
        frm.pack(fill="x")
        row = 0
        for label, var, width in [
            ("Tebliğ Tarihi (gg.aa.yyyy)", self.kur_teblig_tarihi, 20),
            ("Tebliğ Sıra No", self.kur_teblig_no, 10),
            ("USD Döviz Alış Kuru", self.usd_alis, 15),
            ("USD Efektif Alış Kuru", self.usd_efektif, 15),
            ("EUR Döviz Alış Kuru", self.eur_alis, 15),
            ("EUR Efektif Alış Kuru", self.eur_efektif, 15),
            ("GBP Döviz Alış Kuru", self.gbp_alis, 15),
            ("CHF Döviz Alış Kuru", self.chf_alis, 15),
        ]:
            ttk.Label(frm, text=label + ":", style="Card.TLabel", width=26, anchor="w").grid(
                row=row, column=0, sticky="w", pady=6)
            ttk.Entry(frm, textvariable=var, width=width).grid(row=row, column=1, sticky="w", pady=6)
            row += 1
        ttk.Label(wrap, style="FieldHint.TLabel", justify="left", text=(
            "Bu kurlar, metin üretiminde “Vergi Usul Kanunu Genel Tebliği'nin ekinde yer alan döviz "
            "kurları” ifadesi için kullanılır. Varsayılan değerler 31.12.2024 içindir."
        )).pack(anchor="w", pady=(12, 0))

    def _build_run_tab(self, parent):
        frm = ttk.Frame(parent)
        frm.pack(fill="both", expand=True, padx=14, pady=12)

        ttk.Button(frm, text="RAPORU ÜRET   ·   Word olarak kaydet", command=self._calistir,
                   style="Accent.TButton").pack(pady=(0, 14), fill="x")

        ttk.Label(frm, text="İşlem Günlüğü", style="FieldHint.TLabel",
                  font=("Segoe UI Semibold", 10)).pack(anchor="w", pady=(0, 4))

        log_wrap = tk.Frame(frm, bg=self.LINE, bd=0)
        log_wrap.pack(fill="both", expand=True)
        self.log_text = tk.Text(log_wrap, height=22, wrap="word", relief="flat",
                                bg="#0F1B2A", fg="#E2E8F0", insertbackground="#E2E8F0",
                                font=("Consolas", 10), padx=12, pady=10, borderwidth=0)
        self.log_text.pack(side="left", fill="both", expand=True, padx=1, pady=1)
        scrollbar = ttk.Scrollbar(log_wrap, command=self.log_text.yview)
        scrollbar.pack(side="right", fill="y")
        self.log_text.configure(yscrollcommand=scrollbar.set)

        # Renkli gunluk etiketleri
        self.log_text.tag_configure("ok", foreground="#5BD68A")
        self.log_text.tag_configure("err", foreground="#FF6B6B")
        self.log_text.tag_configure("warn", foreground="#FFC857")
        self.log_text.tag_configure("head", foreground=self.GOLD, font=("Consolas", 10, "bold"))
        self.log_text.tag_configure("muted", foreground="#8AA0B6")

    # ------------------ EVENT HANDLERS --------------------
    def _sec_mizan(self):
        path = filedialog.askopenfilename(
            title="Mizan/Bilanco Excel dosyasini secin",
            filetypes=[("Excel dosyalari", "*.xlsx *.xlsm"), ("Tum dosyalar", "*.*")],
        )
        if path:
            self.mizan_path.set(path)
            # Cikti klasorunu Excel'in bulundugu yere ayarla
            if not self.output_dir.get() or self.output_dir.get() == str(Path.cwd()):
                self.output_dir.set(str(Path(path).parent))

    def _sec_beyanname(self):
        path = filedialog.askopenfilename(
            title="Kurumlar Vergisi Beyannamesi PDF secin",
            filetypes=[("PDF dosyalari", "*.pdf"), ("Tum dosyalar", "*.*")],
        )
        if path:
            self.beyanname_path.set(path)
            # Mukellef bilgilerini doldur
            try:
                bv = parse_beyanname(path)
                if bv.vergi_no:
                    self.vergi_no.set(bv.vergi_no)
                if bv.unvan:
                    self.unvan.set(bv.unvan)
                if bv.vergi_dairesi:
                    self.vergi_dairesi.set(bv.vergi_dairesi)
                if bv.donem:
                    # 01.01.2024-31.12.2024 formatinda
                    parts = bv.donem.split("-")
                    if len(parts) == 2:
                        self.donem_baslangic.set(parts[0])
                        self.donem_bitis.set(parts[1])
                self._log(f"Beyanname yuklendi: VKN={bv.vergi_no}, Unvan={bv.unvan}")
                self._log(f"  Ticari Bilanco Kari: {bv.ticari_bilanco_kari:,.2f}")
                self._log(f"  KKEG: {bv.kkeg_toplam:,.2f}")
                self._log(f"  Matrah: {bv.matrah:,.2f}")
                self._log(f"  Hesaplanan Vergi: {bv.hesaplanan_vergi:,.2f}")
            except Exception as e:
                self._log(f"Beyanname onizleme hatasi: {e}")

    def _sec_kur_hesaplama(self):
        path = filedialog.askopenfilename(
            title="Kur hesaplama / yabanci para Excel dosyasini secin",
            filetypes=[("Excel dosyalari", "*.xlsx *.xlsm"), ("Tum dosyalar", "*.*")],
        )
        if path:
            self.kur_hesaplama_path.set(path)

    def _sec_yeniden_degerleme(self):
        path = filedialog.askopenfilename(
            title="Yeniden degerleme tablosu Excel dosyasini secin",
            filetypes=[("Excel dosyalari", "*.xlsx *.xlsm"), ("Tum dosyalar", "*.*")],
        )
        if path:
            self.yeniden_degerleme_path.set(path)

    def _sec_gecici_vergi(self):
        paths = filedialog.askopenfilenames(
            title="Gecici Vergi (KGV) beyanname PDF'lerini secin",
            filetypes=[("PDF dosyalari", "*.pdf"), ("Tum dosyalar", "*.*")],
        )
        for p in paths:
            if p and p not in self.gecici_vergi_paths:
                self.gecici_vergi_paths.append(p)
                self.gecici_vergi_listbox.insert("end", os.path.basename(p))
        self._update_status()

    def _temizle_gecici_vergi(self):
        self.gecici_vergi_paths = []
        self.gecici_vergi_listbox.delete(0, "end")
        self._update_status()

    def _sec_output(self):
        path = filedialog.askdirectory(title="Cikti klasorunu secin")
        if path:
            self.output_dir.set(path)

    def _log(self, msg: str, tag: str = ""):
        # Tag verilmediyse icerikten otomatik sec
        if not tag:
            low = msg.lower()
            if msg.startswith("=") or "başliyor" in low or "başlıyor" in low:
                tag = "head"
            elif "başari" in low or "başarı" in low:
                tag = "ok"
            elif "hata" in low:
                tag = "err"
            elif "uyari" in low or "uyarı" in low:
                tag = "warn"
        self.log_text.insert("end", msg + "\n", tag)
        self.log_text.see("end")
        self.root.update_idletasks()

    def _to_float(self, s: str) -> float:
        try:
            return float(s.replace(",", "."))
        except Exception:
            return 0.0

    def _calistir(self):
        self.log_text.delete("1.0", "end")
        self._log("═" * 64, "head")
        self._log("  RAPOR ÜRETİMİ BAŞLIYOR", "head")
        self._log("═" * 64, "head")

        mizan_p = self.mizan_path.get()
        kur_hesaplama_p = self.kur_hesaplama_path.get()
        yeniden_degerleme_p = self.yeniden_degerleme_path.get()
        beyanname_p = self.beyanname_path.get()
        outdir = self.output_dir.get()

        if not mizan_p or not os.path.exists(mizan_p):
            messagebox.showerror("Hata", "Mizan Excel dosyasi secilmedi veya bulunamadi.")
            return
        if not beyanname_p or not os.path.exists(beyanname_p):
            messagebox.showwarning("Uyari", "Beyanname PDF secilmedi - bos beyanname verisiyle devam ediliyor.")

        try:
            self._log(f"[1/6] Mizan okunuyor: {os.path.basename(mizan_p)}")
            mizan = parse_mizan(mizan_p, sheet_name=self.mizan_sheet.get())
            self._log(f"      {len(mizan)} satir okundu.")

            self._log(f"[2/6] Dovizli Mizan okunuyor...")
            dovizli = parse_dovizli_mizan(mizan_p, sheet_name=self.dovizli_mizan_sheet.get())
            self._log(f"      {len(dovizli)} satir okundu.")

            kur_hesaplama_satirlari = []
            if kur_hesaplama_p and os.path.exists(kur_hesaplama_p):
                self._log(f"      Kur hesaplama Excel'i okunuyor: {os.path.basename(kur_hesaplama_p)}")
                kur_hesaplama_satirlari = parse_kur_hesaplama(kur_hesaplama_p)
                self._log(f"      {len(kur_hesaplama_satirlari)} yabanci para/kur satiri okundu.")

            yeniden_degerleme_satirlari = []
            if yeniden_degerleme_p and os.path.exists(yeniden_degerleme_p):
                self._log(f"      Yeniden degerleme tablosu okunuyor: {os.path.basename(yeniden_degerleme_p)}")
                try:
                    yeniden_degerleme_satirlari = parse_yeniden_degerleme(yeniden_degerleme_p)
                    net = sum(s.net_degerleme_tutari for s in yeniden_degerleme_satirlari)
                    self._log(f"      {len(yeniden_degerleme_satirlari)} hesap; net deger artisi {net:,.2f}")
                except Exception as e:
                    self._log(f"      UYARI: Yeniden degerleme tablosu okunamadi: {e}")

            self._log(f"[3/6] Bilanco okunuyor (donem={self.hedef_donem.get()})...")
            try:
                bilanco = parse_bilanco(mizan_p, sheet_name=self.bilanco_sheet.get(),
                                        hedef_donem=self.hedef_donem.get())
                self._log(f"      {len(bilanco)} satir okundu.")
            except Exception as e:
                self._log(f"      UYARI: Bilanco okunamadi: {e}")
                bilanco = []

            self._log(f"[4/6] Gelir Tablosu okunuyor...")
            try:
                gelir = parse_gelir_tablosu(mizan_p, sheet_name=self.gelir_tablosu_sheet.get(),
                                           hedef_donem=self.hedef_donem.get())
                self._log(f"      {len(gelir)} satir okundu.")
            except Exception as e:
                self._log(f"      UYARI: Gelir tablosu okunamadi: {e}")
                gelir = []

            self._log(f"[5/6] Beyanname okunuyor...")
            if beyanname_p and os.path.exists(beyanname_p):
                from engine.data_model import BeyannameVerisi
                beyanname = parse_beyanname(beyanname_p)
                self._log(f"      Ticari Kar: {beyanname.ticari_bilanco_kari:,.2f}, Matrah: {beyanname.matrah:,.2f}")
            else:
                from engine.data_model import BeyannameVerisi
                beyanname = BeyannameVerisi()

            gecici_vergi_donemleri = []
            if self.gecici_vergi_paths:
                self._log(f"      Geçici vergi beyannameleri okunuyor ({len(self.gecici_vergi_paths)} dosya)...")
                for gp in self.gecici_vergi_paths:
                    try:
                        gv = parse_gecici_vergi(gp)
                        gecici_vergi_donemleri.append(gv)
                        self._log(f"        {os.path.basename(gp)} -> {gv.donem_no}. Dönem ({gv.donem_adi})")
                    except Exception as e:
                        self._log(f"        UYARI: {os.path.basename(gp)} okunamadi: {e}")

            mukellef = MukellefBilgileri(
                vergi_no=self.vergi_no.get(),
                unvan=self.unvan.get(),
                vergi_dairesi=self.vergi_dairesi.get(),
                donem_baslangic=self.donem_baslangic.get(),
                donem_bitis=self.donem_bitis.get(),
                rapor_no=self.rapor_no.get(),
                ymm_adi=self.ymm_adi.get(),
            )

            kurlar = KurTablosu(
                teblig_tarihi=self.kur_teblig_tarihi.get(),
                teblig_no=self.kur_teblig_no.get(),
                usd_alis=self._to_float(self.usd_alis.get()),
                usd_efektif_alis=self._to_float(self.usd_efektif.get()),
                eur_alis=self._to_float(self.eur_alis.get()),
                eur_efektif_alis=self._to_float(self.eur_efektif.get()),
                gbp_alis=self._to_float(self.gbp_alis.get()),
                chf_alis=self._to_float(self.chf_alis.get()),
            )

            rapor = RaporVerisi(
                mukellef=mukellef,
                mizan=mizan,
                dovizli_mizan=dovizli,
                bilanco=bilanco,
                gelir_tablosu=gelir,
                beyanname=beyanname,
                kurlar=kurlar,
                kur_hesaplama_satirlari=kur_hesaplama_satirlari,
                gecici_vergi_donemleri=gecici_vergi_donemleri,
                yeniden_degerleme_satirlari=yeniden_degerleme_satirlari,
            )

            self._log("[6/6] Mutabakat kontrolleri calisiyor...")
            bulgular = kontrolleri_calistir(rapor)
            kritik = sum(1 for b in bulgular if b.onem == "kritik")
            uyari = sum(1 for b in bulgular if b.onem == "uyari")
            self._log(f"      {len(bulgular)} bulgu: {kritik} kritik, {uyari} uyari.")

            self._log("Bloklar uretiliyor...")
            bloklar = hesap_incelemeleri_uret(rapor)
            self._log(f"      {len(bloklar)} blok uretildi.")

            # Cikti dosya adi
            tarih_str = datetime.now().strftime("%Y%m%d_%H%M%S")
            unvan_kisa = (mukellef.unvan or "RAPOR").replace(" ", "_")[:40]
            out_filename = f"TT_Hesap_Incelemeleri_{unvan_kisa}_{tarih_str}.docx"
            out_path = os.path.join(outdir, out_filename)

            self._log(f"Word dosyası yazılıyor: {out_filename}")
            yaz_word_raporu(rapor, bloklar, out_path)
            self._log("═" * 64, "head")
            self._log(f"  BAŞARILI! Çıktı: {out_path}", "ok")
            self._log("═" * 64, "head")
            self.status_label.config(text=f"Rapor üretildi: {out_filename}")

            if messagebox.askyesno("Tamamlandı", f"Rapor üretildi:\n{out_path}\n\nKlasörü açmak ister misiniz?"):
                os.startfile(outdir)

        except Exception as e:
            import traceback
            tb = traceback.format_exc()
            self._log(f"HATA: {e}", "err")
            self._log(tb, "muted")
            messagebox.showerror("Hata", f"Rapor üretiminde hata oluştu:\n{e}")


def main():
    root = tk.Tk()
    app = TTHesapIncelemeleriApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
