"""VUK Mukerrer 298/C yeniden degerleme tablosu parser - cok formatli.

Sabit kiymet bazinda detay listeyi okur, hesap (3 haneli ana hesap) bazinda
ozetler. Farkli muhasebe yazilimlarinin urettigi degisik sutun duzenleri
desteklenir:

  FORMAT A ("dogrudan" tipi) - degerleme tutarlari hazir sutunlarda:
    A.D.Gr.                  -> hesap kodu (251/252/253/255/260/267)
    Aktif Degerleme Tutari   -> brut aktif deger artisi
    Birikmis Amt. Artis Tut. -> birikmis amortisman artisi
    Degerleme Tutari         -> net deger artis fonu (522)

  FORMAT B ("hesaplamali" tipi) - YD oncesi/sonrasi degerlerden hesaplanir:
    Hs. Kod                          -> hesap kodu
    Deftere Kayitli Degeri (G)       -> YD oncesi aktif deger
    Birikmis Amortisman Tutari (T)   -> YD oncesi birikmis amortisman
    YD Sonrasi Aktif Degeri (GxW)    -> YD sonrasi aktif deger
    YD Sonrasi Birikmis Amort.(I+TxW)-> YD sonrasi birikmis amortisman
    Net Deger Artisi (U-Z)           -> net deger artis fonu (522)
  Bu formatta:
    aktif_artis = YD_sonrasi_aktif - deftere_deger
    amort_artis = YD_sonrasi_birikmis_amort - birikmis_amort
    net         = Net Deger Artisi
"""
import re
import unicodedata
from collections import OrderedDict

import openpyxl

from engine.data_model import YenidenDegerlemeSatiri
from parsers.mizan_parser import _to_float


# Hesap kodu -> standart TDHP adi
_HESAP_ADLARI = {
    "250": "Arazi ve Arsalar",
    "251": "Yeraltı ve Yerüstü Düzenleri",
    "252": "Binalar",
    "253": "Tesis, Makine ve Cihazlar",
    "254": "Taşıtlar",
    "255": "Demirbaşlar",
    "256": "Diğer Maddi Duran Varlıklar",
    "258": "Yapılmakta Olan Yatırımlar",
    "260": "Haklar",
    "264": "Özel Maliyetler",
    "267": "Diğer Maddi Olmayan Duran Varlıklar",
}


def _norm(value) -> str:
    if value is None:
        return ""
    text = str(value).strip().lower()
    text = text.translate(str.maketrans({
        "ı": "i", "İ": "i", "ğ": "g", "Ğ": "g", "ü": "u", "Ü": "u",
        "ş": "s", "Ş": "s", "ö": "o", "Ö": "o", "ç": "c", "Ç": "c",
    }))
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _detect_header(ws) -> tuple:
    """Baslik satirini, sutun eslemesini ve format tipini bul.

    (header_row_index, mapping, format) doner. format: "A" (dogrudan) | "B" (hesaplamali).
    """
    for ri in range(min(ws.max_row or 1, 40)):
        row = [ws.cell(row=ri + 1, column=ci + 1).value for ci in range(min(ws.max_column or 1, 60))]
        cells = [_norm(v) for v in row]
        a_map = {}
        b_map = {}
        for ci, cell in enumerate(cells):
            if not cell:
                continue
            # --- Ortak: hesap kodu ---
            if cell in ("a d gr", "ad gr") or "a d gr" in cell:
                a_map.setdefault("hesap_kodu", ci)
            if cell == "hs kod" or cell.startswith("hs kod") or cell in ("hesap kodu", "hesap kod"):
                b_map.setdefault("hesap_kodu", ci)
            # --- Format A (dogrudan) sutunlari ---
            if "aktif degerleme tutar" in cell:
                a_map.setdefault("aktif_deg", ci)
            elif "birikmis amt artis" in cell or "birikmis amortisman artis" in cell:
                a_map.setdefault("amt_artis", ci)
            elif cell == "degerleme tutari" or cell.endswith("degerleme tutari"):
                a_map.setdefault("net_deg", ci)
            # --- Format B (hesaplamali) sutunlari ---
            if "deftere kayitli degeri" in cell:
                b_map.setdefault("deftere_deger", ci)
            elif "yd sonrasi aktif deger" in cell:
                b_map.setdefault("yd_aktif", ci)
            elif "yd sonrasi birikmis amort" in cell:
                b_map.setdefault("yd_birikmis", ci)
            elif "net deger artis" in cell:
                b_map.setdefault("net_deg", ci)
            elif "birikmis amortisman tutar" in cell:
                b_map.setdefault("birikmis_amort", ci)

        # Format A onceligi: hazir net deger artis sutunu varsa
        if "hesap_kodu" in a_map and "net_deg" in a_map:
            return ri, a_map, "A"
        # Format B: YD oncesi/sonrasi degerlerle hesaplanabiliyorsa
        if ("hesap_kodu" in b_map and "net_deg" in b_map
                and "deftere_deger" in b_map and "yd_aktif" in b_map):
            return ri, b_map, "B"
    raise ValueError("Yeniden degerleme tablosunda baslik satiri bulunamadi.")


def _hucre(row, mapping, key):
    idx = mapping.get(key)
    if idx is None or idx >= len(row):
        return 0.0
    return _to_float(row[idx])


def parse_yeniden_degerleme(xlsx_path: str, sheet_name: str = "") -> list:
    """Yeniden degerleme detay tablosunu hesap bazinda ozetleyip dondurur.

    Cok formatli; ilk gecerli sayfayi/duzeni kullanir.
    list[YenidenDegerlemeSatiri] - her hesap kodu icin tek satir (artan kod sirasiyla).
    """
    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    try:
        names = [sheet_name] if sheet_name and sheet_name in wb.sheetnames else list(wb.sheetnames)
        for name in names:
            ws = wb[name]
            try:
                header_row, mapping, fmt = _detect_header(ws)
            except ValueError:
                continue

            agg = OrderedDict()  # kod -> [aktif_deg, amt_artis, net, adet]
            for row in ws.iter_rows(min_row=header_row + 2, values_only=True):
                if not row:
                    continue
                ci = mapping["hesap_kodu"]
                if ci >= len(row) or row[ci] is None:
                    continue
                kod = str(row[ci]).strip()
                # "251" gibi 3 haneli ana hesap; sayisal olmayan / toplam satirlarini atla
                kod = kod.split(".")[0].split("-")[0].strip()
                if not kod[:1].isdigit():
                    continue
                if len(kod) > 3:
                    kod = kod[:3]

                if fmt == "A":
                    aktif = _hucre(row, mapping, "aktif_deg")
                    amt = _hucre(row, mapping, "amt_artis")
                    net = _hucre(row, mapping, "net_deg")
                else:  # fmt == "B"
                    deftere = _hucre(row, mapping, "deftere_deger")
                    birikmis = _hucre(row, mapping, "birikmis_amort")
                    yd_aktif = _hucre(row, mapping, "yd_aktif")
                    yd_birikmis = _hucre(row, mapping, "yd_birikmis")
                    net_kol = _hucre(row, mapping, "net_deg")
                    aktif = yd_aktif - deftere
                    amt = yd_birikmis - birikmis
                    # Net dogrudan sutundan; yoksa aktif-amt
                    net = net_kol if abs(net_kol) > 0.001 else (aktif - amt)

                if abs(aktif) < 0.001 and abs(net) < 0.001:
                    continue
                if kod not in agg:
                    agg[kod] = [0.0, 0.0, 0.0, 0]
                agg[kod][0] += aktif
                agg[kod][1] += amt
                agg[kod][2] += net
                agg[kod][3] += 1

            if not agg:
                continue

            satirlar = []
            for kod in sorted(agg):
                aktif, amt, net, adet = agg[kod]
                satirlar.append(YenidenDegerlemeSatiri(
                    hesap_kodu=kod,
                    hesap_adi=_HESAP_ADLARI.get(kod, ""),
                    kiymet_adedi=adet,
                    aktif_degerleme_tutari=aktif,
                    amortisman_artis_tutari=amt,
                    net_degerleme_tutari=net,
                ))
            return satirlar
        return []
    finally:
        wb.close()
