"""Kurumlar Vergisi Beyannamesi PDF parser."""
import re
import unicodedata

import pdfplumber

from engine.data_model import BeyannameVerisi, BilancoKalemi, GelirTablosuKalemi, KurHesapSatiri


_NUM_RE = re.compile(r"(-?\d{1,3}(?:\.\d{3})+(?:,\d+)?|-?\d+(?:,\d+)?)\s*$")


def _parse_amount(s: str) -> float:
    """1.234.567,89 -> 1234567.89, parantez negatifleri de destekler."""
    s = s.strip()
    neg = False
    if s.startswith("(") and s.endswith(")"):
        neg = True
        s = s[1:-1]
    if s.startswith("-"):
        neg = True
        s = s[1:]
    s = s.replace(".", "").replace(",", ".")
    try:
        v = float(s)
        return -v if neg else v
    except ValueError:
        return 0.0


def _norm(s: str) -> str:
    text = str(s or "").strip().lower()
    text = text.translate(str.maketrans({
        "ı": "i", "İ": "i", "ğ": "g", "Ğ": "g", "ü": "u", "Ü": "u",
        "ş": "s", "Ş": "s", "ö": "o", "Ö": "o", "ç": "c", "Ç": "c",
    }))
    text = unicodedata.normalize("NFKD", text)
    return "".join(ch for ch in text if not unicodedata.combining(ch))


def _extract_amount_from_line(line: str, label_pattern: str) -> float | None:
    """Bir satirda label'in sonundaki sayisal degeri yakala."""
    m = re.search(label_pattern + r".*?(-?\d[\d\.]*(?:,\d+)?)\s*$", line, re.IGNORECASE)
    if m:
        return _parse_amount(m.group(1))
    return None


def parse_beyanname(pdf_path: str) -> BeyannameVerisi:
    bv = BeyannameVerisi()
    with pdfplumber.open(pdf_path) as pdf:
        all_text = []
        for page in pdf.pages:
            t = page.extract_text() or ""
            all_text.append(t)
        text = "\n".join(all_text)

    lines = [ln.rstrip() for ln in text.split("\n")]

    # Mukellef bilgileri
    for i, ln in enumerate(lines):
        m = re.search(r"Vergi Kimlik Numarasi\s*(\d{10})", ln) or re.search(r"Vergi Kimlik Numarası\s*(\d{10})", ln)
        if m and not bv.vergi_no:
            bv.vergi_no = m.group(1)
        m = re.search(r"Soyadı \(Unvanı\)\s*(.+)", ln)
        if m and not bv.unvan:
            bv.unvan = m.group(1).strip()
            # Adı (Unvanın Devamı) bir sonraki satirda olabilir
            if i + 1 < len(lines):
                m2 = re.search(r"Adı \(Unvanın Devamı\)\s*(.+)", lines[i + 1])
                if m2:
                    devam = m2.group(1).strip()
                    if devam and devam.lower() not in bv.unvan.lower():
                        bv.unvan = bv.unvan + " " + devam

    # Donem ve VD basligi
    for ln in lines:
        m = re.search(r"DÖNEM TİPİ\s+Yıl\s+(\d{4})", ln)
        if m:
            yil = m.group(1)
            bv.donem = f"01.01.{yil}-31.12.{yil}"
        # "ANKARA KURUMLAR DÖNEM TİPİ Yıl 2024" -> "ANKARA KURUMLAR"
        m = re.search(r"^([A-ZÇĞIİÖŞÜ][A-ZÇĞIİÖŞÜ\s]+?)\s+DÖNEM TİPİ", ln)
        if m and not bv.vergi_dairesi:
            bv.vergi_dairesi = m.group(1).strip()

    # Tutar etiketleri - tek satirlik desenler
    label_patterns = {
        "ticari_bilanco_kari": r"Ticari Bilan(?:ç|c)o Karı",
        "ticari_bilanco_zarari": r"Ticari Bilan(?:ç|c)o Zararı",
        "kkeg_toplam": r"Kanunen Kabul Edilmeyen Giderler",
        "matrah": r"Kurumlar Vergisi Matrah",
        "hesaplanan_vergi": r"Hesaplanan Kurumlar Vergisi",
        "yil_ici_kesinti": r"Yıl İçinde Kesinti Yoluyla Ödenen Vergiler",
        "odenen_gecici_vergi": r"Ödenen Geçici Vergi",
        "zarar_olsa_dahi_indirim_toplam": r"Cari Yıla Ait Zarar, İstisna ve İndirimler Toplam",
    }

    for ln in lines:
        for field, pat in label_patterns.items():
            if re.search(pat, ln, re.IGNORECASE):
                # son sayisal degeri al
                nums = re.findall(r"-?\d{1,3}(?:\.\d{3})*(?:,\d+)?", ln)
                if nums:
                    val = _parse_amount(nums[-1])
                    cur = getattr(bv, field)
                    if abs(cur) < 0.005:
                        setattr(bv, field, val)

    # Bilanco ve gelir tablosu — beyanname icindeki PDF tablolari
    bv.bilanco_satirlari = _parse_bilanco_table_from_pdf(lines)
    bv.gelir_tablosu_satirlari = _parse_gelir_tablosu_table_from_pdf(lines)
    bv.dipnot_tutarlari = _parse_dipnot_tutarlari(lines)

    # C. Diger Incelemeler bolumu icin beyanname eki tablolari
    bv.kesinti_listesi = _parse_kesinti_listesi(lines)
    bv.kkeg_satirlari = _parse_kkeg_tablosu(lines)
    bv.zarar_olsa_dahi_indirim_satirlari = _parse_istisna_detay(
        lines,
        "zarar olsa dahi indirilecek istisna ve indirimler",
    )
    bv.kazanc_halinde_indirim_satirlari = _parse_istisna_detay(
        lines,
        "kazancin bulunmasi halinde indirilecek istisna ve indirimler",
    )
    bv.nakdi_sermaye_satirlari, bv.nakdi_sermaye_indirim_toplam = _parse_nakdi_sermaye(lines)
    # istisnalar listesini de zarar-olsa-dahi dokumunden doldur (geriye donuk uyum)
    if not bv.istisnalar and bv.zarar_olsa_dahi_indirim_satirlari:
        bv.istisnalar = list(bv.zarar_olsa_dahi_indirim_satirlari)

    # Yabanci para: once "YABANCI PARA POZISYONUNA ILISKIN BILGILER" tablosu
    # (hesap koduna eslenebildigi icin oncelikli), bulunamazsa genel desen.
    yp_pozisyon = _parse_yabanci_para_pozisyonu(lines)
    if yp_pozisyon:
        bv.yabanci_para_satirlari = yp_pozisyon
    else:
        bv.yabanci_para_satirlari = _parse_yabanci_para_ekleri(lines)

    return bv


# Beyanname "YABANCI PARA POZISYONUNA ILISKIN BILGILER" tablosundaki alt
# kalem adlarini TDHP hesap koduna esler. Anahtarlar normalize edilmis (ascii).
_YP_KALEM_KODLARI = [
    ("bankalar", "102"),
    ("kasa", "100"),
    ("alicilar", "120"),
    ("ticari alacaklar", "120"),
    ("diger ticari alacaklar", "121"),
    ("verilen cekler", "103"),
    ("diger hazir degerler", "108"),
    ("menkul kiymetler", "110"),
    ("diger alacaklar", "136"),
    ("stoklar", "153"),
    ("verilen siparis avanslari", "159"),
    ("banka kredileri", "300"),
    ("finansal kiralama", "301"),
    ("saticilar", "320"),
    ("ticari borclar", "320"),
    ("diger borclar", "336"),
    ("alinan avanslar", "340"),
    ("alinan siparis avanslari", "340"),
]


def _yp_kalem_kodu(label_norm: str) -> str:
    """YP tablosu alt kalem adini hesap koduna esler; eslesmezse bos doner."""
    for anahtar, kod in _YP_KALEM_KODLARI:
        if anahtar in label_norm:
            return kod
    return ""


def _parse_yabanci_para_pozisyonu(lines: list[str]) -> list:
    """Beyanname 'YABANCI PARA POZISYONUNA ILISKIN BILGILER' tablosunu ayristirir.

    Tablo kolonlari: Aciklama | USD($) TL Karsiligi | EURO(€) TL Karsiligi |
    Diger Doviz Cinslerinin TL Karsiligi. Alt kalem satirlari (orn. '. 2.Bankalar
    9.435.476,71 0,00 0,00') hesap koduna eslenir; USD/EUR kolonlarindaki TL
    karsiligi sifirdan buyukse KurHesapSatiri olarak uretilir. Doviz tutari,
    data_model._aktif_yabanci_para_satirlari icinde varsayilan kur ile hesaplanir.
    """
    satirlar = []
    in_section = False
    seen_kod = set()  # (kod, doviz_cinsi) tekrarini engelle
    for ln in lines:
        s = ln.strip()
        u = _norm(s)
        if "yabanci para poz" in u:
            in_section = True
            continue
        if not in_section:
            continue
        # Tablo disina cikinca dur
        if any(k in u for k in ("kanunen kabul edilmeyen", "nakdi sermaye", "sinai mulkiyet")):
            break
        # Toplam/baslik satirlarini ve kolon basligini atla
        if any(k in u for k in (
            "yabanci para toplami", "net bilanco", "net yabanci para",
            "yabanci para poz", "tl karsiligi", "doviz cinsleri", "aciklama usd",
        )):
            continue
        kod = _yp_kalem_kodu(u)
        if not kod:
            continue
        # Sadece ondalik virgullu sayilar tutar kolonudur; ". 2.Bankalar" gibi
        # satir-no onekindeki tam sayilari (",dddd" iceren) disla.
        nums = re.findall(r"-?\d{1,3}(?:\.\d{3})*,\d+|-?\d+,\d+", s)
        if not nums:
            continue
        tutarlar = [_parse_amount(n) for n in nums]
        # Kolon sirasi sondan: [..., USD_TL, EUR_TL, Diger_TL]
        usd_tl = tutarlar[-3] if len(tutarlar) >= 3 else (tutarlar[0] if tutarlar else 0.0)
        eur_tl = tutarlar[-2] if len(tutarlar) >= 3 else (tutarlar[1] if len(tutarlar) >= 2 else 0.0)
        for dc, tl in (("USD", usd_tl), ("EUR", eur_tl)):
            if abs(tl) < 0.005:
                continue
            anahtar = (kod, dc)
            if anahtar in seen_kod:
                continue
            seen_kod.add(anahtar)
            satirlar.append(KurHesapSatiri(
                hesap_kodu=kod,
                hesap_adi="Beyanname yabancı para pozisyonu",
                doviz_cinsi=dc,
                tl_tutar=abs(tl),
                kaynak="Beyanname yabancı para pozisyonu",
            ))
    return satirlar


def _parse_dipnot_tutarlari(lines: list[str]) -> dict:
    """Dipnot ve ek bilgi satirlarindan kontrol edilecek tutarlari yakala."""
    sonuc = {}
    for ln in lines:
        s = _norm(ln)
        if not any(k in s for k in ["amortisman", "yabanci para", "doviz", "kur fark"]):
            continue
        nums = re.findall(r"-?\d{1,3}(?:\.\d{3})*(?:,\d+)?", ln)
        if not nums:
            continue
        tutar = _parse_amount(nums[-1])
        if abs(tutar) < 0.005:
            continue
        if "amortisman" in s:
            sonuc.setdefault("amortisman", 0.0)
            sonuc["amortisman"] += abs(tutar)
        elif "yabanci para" in s or "doviz" in s:
            sonuc.setdefault("yabanci_para_tl", 0.0)
            sonuc["yabanci_para_tl"] += abs(tutar)
        elif "kur fark" in s:
            sonuc.setdefault("kur_farki", 0.0)
            sonuc["kur_farki"] += abs(tutar)
    return sonuc


def _parse_yabanci_para_ekleri(lines: list[str]) -> list:
    """Kurumlar beyannamesi ekindeki yabanci para satirlarini genel desenlerle yakala."""
    satirlar = []
    doviz_re = re.compile(r"\b(USD|EUR|EURO|GBP|CHF|AUD|CAD|JPY)\b", re.IGNORECASE)
    hesap_re = re.compile(r"\b([1-9]\d{2}(?:\.\d+)*)\b")
    for ln in lines:
        s = _norm(ln)
        if not any(k in s for k in ["yabanci para", "doviz", "kur", "usd", "eur", "euro", "gbp", "chf"]):
            continue
        dm = doviz_re.search(ln)
        if not dm:
            continue
        nums = re.findall(r"-?\d{1,3}(?:\.\d{3})*(?:,\d+)?|-?\d+(?:,\d+)?", ln)
        if not nums:
            continue
        tutarlar = [_parse_amount(n) for n in nums]
        tl_tutar = max(tutarlar, key=lambda n: abs(n)) if tutarlar else 0.0
        if abs(tl_tutar) < 0.005:
            continue
        hesap = ""
        hm = hesap_re.search(ln)
        if hm:
            hesap = hm.group(1)
        dc = dm.group(1).upper()
        if dc == "EURO":
            dc = "EUR"
        satirlar.append(KurHesapSatiri(
            hesap_kodu=hesap,
            hesap_adi="Beyanname yabanci para eki",
            doviz_cinsi=dc,
            tl_tutar=tl_tutar,
            kaynak="Kurumlar vergisi beyannamesi eki",
        ))
    return satirlar


def _parse_bilanco_table_from_pdf(lines: list[str]) -> list:
    """Beyanname PDF'inde 'TEK DÜZEN HESAP PLANI AYRINTILI BİLANÇO' bolumunu ayristir."""
    kalemler = []
    in_section = False
    in_aktif = False
    in_pasif = False
    vade = ""  # "kisa" (donen/KVYK) | "uzun" (duran/UVYK) | "" (ozkaynak/belirsiz)
    for ln in lines:
        s = ln.strip()
        if "AYRINTILI BİLANÇO" in s.upper():
            in_section = True
            in_aktif = False
            in_pasif = False
            vade = ""
            continue
        # Bilanço bölümü gelir tablosu / kar dağıtım / dipnot başlığında kapanmalı.
        # Beyanname PDF'inde gelir tablosu başlığı "AYRINTILI" içermeden yalnızca
        # "GELİR TABLOSU" geçtiği için eski kapanış koşulu hiç tetiklenmiyor; bilanço
        # açık kalıp gelir tablosu, kar dağıtım ve yabancı para eki satırlarını da
        # pasif kalem olarak okuyordu (153/540/590-591/102 sahte uyumsuzluklarinin kaynagi).
        if in_section and (
            "GELİR TABLOSU" in s.upper()
            or "KAR DAĞITIM" in s.upper()
            or "KÂR DAĞITIM" in s.upper()
            or s.upper().startswith("DİPNOT")
        ):
            in_section = False
            in_aktif = False
            in_pasif = False
            continue
        if not in_section:
            continue
        if s.startswith("AKTİF") or s == "AKTİF":
            in_aktif = True
            in_pasif = False
            vade = ""
            continue
        if s.startswith("PASİF"):
            in_aktif = False
            in_pasif = True
            vade = ""
            continue
        if not (in_aktif or in_pasif):
            continue
        # Vade baglamini izle: vade-bolunmus kalemler (Banka Kredileri 300/400,
        # Diger Mali Borclar 309/409 vb.) dogru tek koda eslenebilsin diye.
        ns = _norm(s)
        if "donen varlik" in ns:
            vade = "kisa"
        elif "duran varlik" in ns:
            vade = "uzun"
        elif "kisa vadeli yabanci kaynak" in ns:
            vade = "kisa"
        elif "uzun vadeli yabanci kaynak" in ns:
            vade = "uzun"
        elif "ozkaynak" in ns or "oz kaynak" in ns:
            vade = ""
        # Satir sonundaki iki tutari (onceki/cari donem) ve oncesindeki aciklamayi
        # tek regex ile ayir. Eski rfind yontemi, formatli sayinin alt dizisini
        # (orn. "650,00" icindeki "0,00") aciklamada bulup yanlis kesiyordu
        # (". 1. Saticilar 0,00 664.365.65" gibi bozuk etiketler).
        _amt = r"-?\d{1,3}(?:\.\d{3})*(?:,\d+)?|-?\d+(?:,\d+)?"
        m = re.match(rf"^(.*?\S)\s+({_amt})\s+({_amt})\s*$", s)
        if m:
            label = m.group(1).strip()
            try:
                onceki = _parse_amount(m.group(2))
                cari = _parse_amount(m.group(3))
            except Exception:
                continue
            if not re.search(r"[A-Za-zÇĞIİÖŞÜçğıiöşü]", label):
                continue
            # hesap kodu (varsa) - genel beyanname formati bunlari icermez
            kalemler.append(BilancoKalemi(
                hesap_kodu="",
                aciklama=label,
                onceki_donem=onceki,
                cari_donem=cari,
                seviye=0,
                vade=vade,
                bolum="aktif" if in_aktif else ("pasif" if in_pasif else ""),
            ))
    return kalemler


def _parse_gelir_tablosu_table_from_pdf(lines: list[str]) -> list:
    """Beyanname PDF'inde 'GELİR TABLOSU' bolumunu ayristir.

    Beyanname ekinde bilanco ile gelir tablosu ortak baslik altinda
    ("...AYRINTILI BİLANÇO VE AYRINTILI GELİR TABLOSU") gosterilir; gercek
    gelir tablosu ise daha sonra TEK BASINA "GELİR TABLOSU" basligiyla gelir.
    Eski kosul "AYRINTILI GELİR TABLOSU" ortak basligini yakaladigi icin bilanco
    satirlarini gelir tablosu kalemi olarak okuyordu. Bu yuzden bolum yalnizca
    tam olarak "GELİR TABLOSU" olan satirda acilir.
    """
    kalemler = []
    in_section = False
    for ln in lines:
        s = ln.strip()
        su = s.upper()
        if su == "GELİR TABLOSU":
            in_section = True
            continue
        if not in_section:
            continue
        if su.startswith("DİPNOT") or "KAR DAĞITIM" in su or "KÂR DAĞITIM" in su \
                or "EK BİLGİLER" in su:
            in_section = False
            continue
        # Baslik/yil satirlarini atla ("Açıklama Önceki Dönem Cari Dönem", "(2023) (2024)")
        if _norm(s).startswith("aciklama"):
            continue
        nums = re.findall(r"-?\d{1,3}(?:\.\d{3})*(?:,\d+)?", s)
        if len(nums) >= 2:
            try:
                cari = _parse_amount(nums[-1])
                onceki = _parse_amount(nums[-2])
            except Exception:
                continue
            # Sondaki tutar dizisini topluca kes (rfind dongusu ic ice gecen
            # "0,00"/"5.340,00" gibi sayilarda etikette artik birakiyordu).
            label = re.sub(
                r"(?:\s+-?\d{1,3}(?:\.\d{3})*(?:,\d+)?)+\s*$", "", s
            ).strip()
            # Yil satiri "(2023) (2024)" gibi metin etiketi olmayan satirlari atla.
            if not re.search(r"[A-Za-zçğıöşüÇĞİÖŞÜ]", label):
                continue
            kalemler.append(GelirTablosuKalemi(
                hesap_kodu="",
                aciklama=label,
                onceki_donem=onceki,
                cari_donem=cari,
                seviye=0,
            ))
    return kalemler


# ============================================================
# C. DIGER INCELEMELER icin beyanname eki tablolari
# ============================================================

# Sadece ondalik virgullu tutarlar (VKN/tarih gibi tam sayilari disla)
_AMOUNT_RE2 = re.compile(r"-?\d{1,3}(?:\.\d{3})*,\d+|-?\d+,\d+")
_AMOUNT_TAIL_RE = re.compile(r"(-?\d{1,3}(?:\.\d{3})*,\d+|-?\d+,\d+)\s*$")
_KESINTI_DONEM_RE = re.compile(r"\d{2}/\d{4}\s*-\s*\d{2}/\d{4}")
_NS_DATE_RE = re.compile(r"^\d{2}/\d{2}/\d{4}\b")


def _parse_kesinti_listesi(lines: list[str]) -> list:
    """'KESINTI YOLUYLA ODENEN VERGILERE ILISKIN LISTE' tablosunu ayristirir.

    Beyanname kolonlari: Adi Soyadi/Unvani | T.C. Kimlik No | Vergi Kimlik No |
    Kesilen Vergi Donemi (MM/YYYY-MM/YYYY) | Odemenin Brut Tutari | Vergi Tutari.
    Kurumsal satirlarda T.C. Kimlik bos olup yalnizca VKN bulunur.
    """
    satirlar = []
    in_section = False
    seen = set()
    for raw in lines:
        s = raw.strip()
        u = _norm(s)
        if "kesinti yoluyla odenen vergilere iliskin liste" in u:
            in_section = True
            continue
        if not in_section:
            continue
        # Liste disina cikinca dur
        if any(k in u for k in (
            "kurum ortaklarina", "yonetim kurulu", "transfer fiyatlandirmasi",
            "kanunen kabul edilmeyen", "sinai mulkiyet",
        )):
            in_section = False
            continue
        donem_m = _KESINTI_DONEM_RE.search(s)
        # Baslik satirlari (donem icermeyen)
        if not donem_m:
            continue
        if u.startswith("toplam"):
            continue
        donem = re.sub(r"\s+", "", donem_m.group(0))
        before = s[:donem_m.start()].strip()
        after = s[donem_m.end():].strip()
        idm = re.search(r"(\d{10,11})\s*$", before)
        if idm:
            vkn = idm.group(1)
            unvan = before[:idm.start()].strip()
        else:
            vkn = ""
            unvan = before
        nums = _AMOUNT_RE2.findall(after)
        if len(nums) < 2:
            continue
        brut = _parse_amount(nums[-2])
        vergi = _parse_amount(nums[-1])
        key = (unvan, vkn, donem)
        if key in seen:
            continue
        seen.add(key)
        satirlar.append({
            "unvan": unvan,
            "vkn": vkn,
            "donem": donem,
            "brut": brut,
            "vergi": vergi,
        })
    return satirlar


def _parse_kkeg_tablosu(lines: list[str]) -> list:
    """'KANUNEN KABUL EDILMEYEN GIDERLER' dokum tablolarini ayristirir.

    Hem ana ('Giderin Turu / Tutar') hem '(DIGER)' ('Diger Aciklama / Tutar')
    bloklarini toplar. Satir = etiket + satir sonundaki tutar; etiket birden
    fazla satira bolunmusse birlestirilir.
    """
    satirlar = []
    in_section = False
    pending = ""
    for raw in lines:
        s = raw.strip()
        u = _norm(s)
        # Tablo basligi: tutar icermeyen "kanunen kabul edilmeyen giderler" satiri
        if "kanunen kabul edilmeyen gider" in u and "giderler" in u \
                and not any(ch.isdigit() for ch in s):
            in_section = True
            pending = ""
            continue
        if not in_section:
            continue
        if u.startswith("giderin turu") or u.startswith("diger aciklama") \
                or u in ("turu tutar", "tutar"):
            continue
        if u.startswith("toplam"):
            in_section = False
            pending = ""
            continue
        if any(k in u for k in (
            "sinai mulkiyet", "nakdi sermaye", "transfer fiyat", "yabanci para",
            "zarar olsa dahi", "kazancin bulunmasi", "vergi bildirimi",
            "mahsup edilecek vergiler", "ek bilgiler",
        )):
            in_section = False
            pending = ""
            continue
        m = _AMOUNT_TAIL_RE.search(s)
        if not m:
            pending = (pending + " " + s).strip() if pending else s
            continue
        amount = _parse_amount(m.group(1))
        label = (pending + " " + s[:m.start()]).strip() if pending else s[:m.start()].strip()
        pending = ""
        if not label:
            continue
        satirlar.append((label, amount))
    return satirlar


def _parse_istisna_detay(lines: list[str], header_norm: str) -> list:
    """Verilen baslik altindaki istisna/indirim dokum satirlarini ayristirir.

    'ZARAR OLSA DAHI INDIRILECEK ISTISNA VE INDIRIMLER' veya
    'KAZANCIN BULUNMASI HALINDE INDIRILECEK ISTISNA VE INDIRIMLER' icin kullanilir.
    """
    satirlar = []
    in_section = False
    pending = ""
    for raw in lines:
        s = raw.strip()
        u = _norm(s)
        if header_norm in u and not any(ch.isdigit() for ch in s):
            in_section = True
            pending = ""
            continue
        if not in_section:
            continue
        if u.startswith("turu aciklama") or u.startswith("turu tutar"):
            continue
        if u.startswith("toplam"):
            in_section = False
            pending = ""
            continue
        if any(k in u for k in (
            "kar ve ilaveler toplami", "cari yila ait zarar", "donem safi kurum",
            "kazancin bulunmasi halinde", "vergi bildirimi", "mahsup edilecek vergiler",
            "indirime esas tutar", "genel orana tabi", "ilaveler",
            "gelecek yila devreden", "ek bilgiler",
        )):
            in_section = False
            pending = ""
            continue
        m = _AMOUNT_TAIL_RE.search(s)
        if not m:
            pending = (pending + " " + s).strip() if pending else s
            continue
        amount = _parse_amount(m.group(1))
        label = (pending + " " + s[:m.start()]).strip() if pending else s[:m.start()].strip()
        pending = ""
        if not label:
            continue
        satirlar.append((label, amount))
    return satirlar


def _parse_nakdi_sermaye(lines: list[str]) -> tuple:
    """'NAKDI SERMAYE ARTISINDAN KAYNAKLANAN FAIZ INDIRIMI' tablosunu ayristirir.

    Veri satirlari DD/MM/YYYY (tescil tarihi) ile baslar. Kolonlar:
    tescil tarihi | donem | nakdi sermaye tutari | TCMB faiz orani | indirim oranlari |
    toplam indirim orani | sure (x/12) | indirim tutari (son sutun).
    """
    satirlar = []
    toplam = 0.0
    in_section = False
    for raw in lines:
        s = raw.strip()
        u = _norm(s)
        if "nakdi sermaye artisindan kaynaklanan faiz indirimi" in u:
            in_section = True
            continue
        if not in_section:
            continue
        if any(k in u for k in (
            "sinai mulkiyet", "kanunen kabul", "transfer fiyat", "devir alinan",
            "patent sahibinin", "vergi bildirimi",
        )):
            in_section = False
            continue
        if not _NS_DATE_RE.match(s):
            continue
        toks = s.split()
        if len(toks) < 4:
            continue
        indirim = _parse_amount(toks[-1])
        sure = ""
        for t in toks:
            if re.match(r"^\d{1,2}/12$", t):
                sure = t
        satirlar.append({
            "tescil": toks[0],
            "donem": toks[1],
            "sermaye": _parse_amount(toks[2]),
            "faiz_orani": toks[3],
            "sure": sure,
            "indirim": indirim,
        })
        toplam += indirim
    return satirlar, toplam
