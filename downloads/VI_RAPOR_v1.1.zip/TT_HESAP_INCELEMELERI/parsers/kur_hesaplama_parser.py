"""Kur hesaplama / yabanci para Excel parser."""
import re
import unicodedata

import openpyxl

from engine.data_model import KurHesapSatiri
from parsers.mizan_parser import _to_float


def _norm(value) -> str:
    if value is None:
        return ""
    text = str(value).strip().lower()
    text = text.translate(str.maketrans({
        "ı": "i", "İ": "i", "ğ": "g", "Ğ": "g", "ü": "u", "Ü": "u",
        "ş": "s", "Ş": "s", "ö": "o", "Ö": "o", "ç": "c", "Ç": "c",
    }))
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _account_code(value) -> str:
    if value is None:
        return ""
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def _detect_header(ws) -> tuple:
    for ri in range(min(ws.max_row or 1, 40)):
        row = [ws.cell(row=ri + 1, column=ci + 1).value for ci in range(min(ws.max_column or 1, 50))]
        cells = [_norm(v) for v in row]
        mapping = {}
        for ci, cell in enumerate(cells):
            if any(k in cell for k in ["hesap kod", "hesap no", "tam hesap", "td hesap", "t d hesap"]):
                mapping.setdefault("hesap_kodu", ci)
            elif any(k in cell for k in ["hesap adi", "hesap acik", "aciklama", "unvan", "banka"]):
                mapping.setdefault("hesap_adi", ci)
            elif any(k in cell for k in ["doviz cinsi", "para birimi", "p br", "pbr", "kur cinsi"]):
                mapping.setdefault("doviz_cinsi", ci)
            elif any(k in cell for k in ["doviz tutar", "orijinal tutar", "yp tutar", "yabanci para tutar", "bakiye doviz"]):
                mapping.setdefault("doviz_tutari", ci)
            elif cell == "kur" or "degerleme kuru" in cell or "doviz kuru" in cell:
                mapping.setdefault("kur", ci)
            elif any(k in cell for k in ["tl tutar", "tl karsilik", "bakiye tl", "degerlenmis tutar", "degerleme tutar"]):
                mapping.setdefault("tl_tutar", ci)
        if "doviz_cinsi" in mapping and ("doviz_tutari" in mapping or "tl_tutar" in mapping):
            return ri, mapping
    raise ValueError("Kur hesaplama Excel'inde yabanci para baslik satiri bulunamadi.")


def _detect_pivot_header(ws) -> tuple:
    """"YABANCI PARA POZISYONU CALISMASI" tipi PIVOT sayfasinin basligini bul.

    Bu format hesap/doviz cinsi bazinda borc-alacak ayrik sutunlar icerir:
    ANA HESAP | ACIKLAMA | R.PBr. | Bak.Borc(R.P) | Bak.Alac(R.P) | Bakiye Borc | Bakiye Alac
    Bulursa (header_row_index, mapping) doner; bulamazsa None.
    """
    for ri in range(min(ws.max_row or 1, 40)):
        row = [ws.cell(row=ri + 1, column=ci + 1).value for ci in range(min(ws.max_column or 1, 60))]
        cells = [_norm(v) for v in row]
        mapping = {}
        for ci, cell in enumerate(cells):
            if cell == "ana hesap" or ("ana hesap" in cell and "kod" not in cell):
                mapping.setdefault("hesap_kodu", ci)
            elif cell == "aciklama":
                mapping.setdefault("hesap_adi", ci)
            elif cell in ("r pbr", "pbr", "r p br") or "pbr" in cell:
                mapping.setdefault("doviz_cinsi", ci)
            elif "bak borc r p" in cell:
                mapping.setdefault("doviz_borc", ci)
            elif "bak alac r p" in cell:
                mapping.setdefault("doviz_alac", ci)
            elif "bakiye borc" in cell:
                mapping.setdefault("tl_borc", ci)
            elif "bakiye alac" in cell:
                mapping.setdefault("tl_alac", ci)
        gerekli = {"hesap_kodu", "doviz_cinsi", "doviz_borc", "doviz_alac", "tl_borc", "tl_alac"}
        if gerekli.issubset(mapping.keys()):
            return ri, mapping
    return None


def _parse_pivot_sayfasi(ws, name: str) -> list:
    """PIVOT tipi sayfayi KurHesapSatiri listesine cevir (net borc-alacak)."""
    bulunan = _detect_pivot_header(ws)
    if not bulunan:
        return []
    header_row, mapping = bulunan
    satirlar = []
    for row in ws.iter_rows(min_row=header_row + 2, values_only=True):
        if not row:
            continue

        def hucre(key):
            ci = mapping.get(key)
            if ci is None or ci >= len(row):
                return None
            return row[ci]

        kod_ham = hucre("hesap_kodu")
        hesap_kodu = _account_code(kod_ham)
        # "Genel Toplam" / bos / sayisal olmayan ana hesap satirlarini atla
        if not hesap_kodu or not hesap_kodu[:1].isdigit():
            continue

        dc = ""
        if hucre("doviz_cinsi"):
            dc = str(hucre("doviz_cinsi")).strip().upper()
        if not dc or dc in ("TL", "TRY"):
            continue

        doviz = _to_float(hucre("doviz_borc")) - _to_float(hucre("doviz_alac"))
        tl = _to_float(hucre("tl_borc")) - _to_float(hucre("tl_alac"))
        if abs(doviz) < 0.001 and abs(tl) < 0.001:
            continue

        kur = (tl / doviz) if abs(doviz) > 0.001 else 0.0
        hesap_adi = ""
        if hucre("hesap_adi"):
            hesap_adi = " ".join(str(hucre("hesap_adi")).split())

        satirlar.append(KurHesapSatiri(
            hesap_kodu=hesap_kodu,
            hesap_adi=hesap_adi,
            doviz_cinsi=dc,
            doviz_tutari=doviz,
            kur=kur,
            tl_tutar=tl,
            kaynak=f"Yabanci para pozisyonu calismasi / {name}",
        ))
    return satirlar


def parse_kur_hesaplama(xlsx_path: str, sheet_name: str = "") -> list:
    """Kur hesaplama / yabanci para pozisyonu tablosunu oku.

    Iki format desteklenir:
      1) "YABANCI PARA POZISYONU CALISMASI" PIVOT sayfasi (hesap+doviz bazinda
         borc/alacak ayrik sutunlar). Varsa ONCELIKLE bu kullanilir (cifte sayma
         olmamasi icin yalnizca PIVOT/ozet sayfasi okunur).
      2) Genel kur hesaplama tablosu: hesap kodu/adi, doviz cinsi, doviz tutari,
         kur, TL karsilik sutunlari.
    """
    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    try:
        # 1) Once PIVOT tipi sayfa ara (en guvenilir, cifte saymaz).
        pivot_oncelik = [n for n in wb.sheetnames if "pivot" in _norm(n)]
        diger = [n for n in wb.sheetnames if n not in pivot_oncelik]
        for name in pivot_oncelik + diger:
            ws = wb[name]
            pivot_satir = _parse_pivot_sayfasi(ws, name)
            if pivot_satir:
                return pivot_satir

        # 2) Genel format (eski davranis).
        names = [sheet_name] if sheet_name and sheet_name in wb.sheetnames else list(wb.sheetnames)
        satirlar = []
        for name in names:
            ws = wb[name]
            try:
                header_row, mapping = _detect_header(ws)
            except ValueError:
                continue
            for row in ws.iter_rows(min_row=header_row + 2, values_only=True):
                if not row:
                    continue
                dc = ""
                if mapping["doviz_cinsi"] < len(row) and row[mapping["doviz_cinsi"]]:
                    dc = str(row[mapping["doviz_cinsi"]]).strip().upper()
                if not dc or dc in ("TL", "TRY"):
                    continue

                doviz_tutari = _to_float(row[mapping["doviz_tutari"]]) if "doviz_tutari" in mapping and mapping["doviz_tutari"] < len(row) else 0.0
                kur = _to_float(row[mapping["kur"]]) if "kur" in mapping and mapping["kur"] < len(row) else 0.0
                tl_tutar = _to_float(row[mapping["tl_tutar"]]) if "tl_tutar" in mapping and mapping["tl_tutar"] < len(row) else 0.0
                if abs(doviz_tutari) < 0.001 and abs(tl_tutar) < 0.001:
                    continue

                hesap_kodu = ""
                if "hesap_kodu" in mapping and mapping["hesap_kodu"] < len(row):
                    hesap_kodu = _account_code(row[mapping["hesap_kodu"]])
                hesap_adi = ""
                if "hesap_adi" in mapping and mapping["hesap_adi"] < len(row) and row[mapping["hesap_adi"]]:
                    hesap_adi = " ".join(str(row[mapping["hesap_adi"]]).split())

                satirlar.append(KurHesapSatiri(
                    hesap_kodu=hesap_kodu,
                    hesap_adi=hesap_adi,
                    doviz_cinsi=dc,
                    doviz_tutari=doviz_tutari,
                    kur=kur,
                    tl_tutar=tl_tutar,
                    kaynak=f"Kur hesaplama Excel'i / {name}",
                ))
        return satirlar
    finally:
        wb.close()
