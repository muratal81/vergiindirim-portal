"""Gecici Vergi (KGV) Beyannamesi PDF parser."""
import re
import unicodedata

import pdfplumber

from engine.data_model import GeciciVergiDonemi


_NUM_TAIL_RE = re.compile(r"(-?\d{1,3}(?:\.\d{3})*(?:,\d+)?|-?\d+(?:,\d+)?)\s*$")

# donem_no -> rapordaki kolon basligi
DONEM_ADLARI = {1: "Ocak-Mart", 2: "Ocak-Haziran", 3: "Ocak-Eylül", 4: "Ocak-Aralık"}

# Raporda gosterilecek satirlar: (canonical_key, gorunen_etiket)
RAPOR_SATIRLARI = [
    ("ticari_bilanco_kari", "Ticari Bilanço Kârı"),
    ("ticari_bilanco_zarari", "Ticari Bilanço Zararı"),
    ("kkeg", "Kanunen Kabul Edilmeyen Gider"),
    ("zarar_olsa_dahi_indirim", "Zarar Olsa Dahi İndirilecek İstisna ve İndirimler"),
    ("kar_ilaveler_toplami", "Kâr ve İlaveler Toplamı"),
    ("zarar_indirimler_toplami", "Zarar ve İndirimler Toplamı"),
    ("mahsup_gecmis_zarar", "Mahsup Edilecek Geçmiş Yıl Zararları"),
    ("indirime_esas_tutar", "İndirime Esas Tutar"),
    ("zarar", "Zarar"),
    ("safi_matrah", "Safi Geçici Vergi Matrahı"),
    ("genel_oran_matrah", "Genel Orana Tabi Geçici Vergi Matrahı"),
    ("gecici_vergi_matrahi", "Geçici Vergi Matrahı"),
    ("hesaplanan_gecici_vergi", "Hesaplanan Geçici Vergi"),
    ("onceki_donem_hesaplanan", "Önceki Dönemlerde Hesaplanan Geçici Vergi"),
    ("odenmesi_gereken", "Ödenmesi Gereken Geçici Vergi"),
    ("mahsup_tevkifat", "Mahsup Edilecek Tevkifat Tutarı"),
    ("odenecek_gecici_vergi", "Ödenecek Geçici Vergi"),
    ("devreden_tevkifat", "Sonraki Döneme Devreden Tevkifat Tutarı"),
    ("devreden_hesaplanan", "Sonraki Döneme Devreden Hesaplanan Geçici Vergi"),
]

# canonical_key -> beyannamede satir basinda birebir eslesmesi gereken etiket
_ALAN_ETIKETLERI = {
    "ticari_bilanco_kari": "Ticari Bilanço Karı",
    "ticari_bilanco_zarari": "Ticari Bilanço Zararı",
    "kkeg": "Kanunen Kabul Edilmeyen Gider",
    "zarar_olsa_dahi_indirim": "Zarar Olsa Dahi İndirilecek İstisna ve İndirimler",
    "kar_ilaveler_toplami": "Kar ve İlaveler Toplamı",
    "zarar_indirimler_toplami": "Zarar ve İndirimler Toplamı",
    "mahsup_gecmis_zarar": "Mahsup Edilecek Geçmiş Yıl Zararları",
    "indirime_esas_tutar": "İndirime Esas Tutar",
    "zarar": "Zarar",
    "safi_matrah": "Safi Geçici Vergi Matrahı",
    "genel_oran_matrah": "Genel Orana Tabi Geçici Vergi Matrahı",
    "gecici_vergi_matrahi": "Geçici Vergi Matrahı",
    "hesaplanan_gecici_vergi": "Hesaplanan Geçici Vergi",
    "onceki_donem_hesaplanan": "Önceki Dönemlerde Hesaplanan Geçici Vergi",
    "odenmesi_gereken": "Ödenmesi Gereken Geçici Vergi",
    "mahsup_tevkifat": "Mahsup Edilecek Tevkifat Tutarı",
    "odenecek_gecici_vergi": "Ödenecek Geçici Vergi",
    "devreden_tevkifat": "Sonraki Döneme Devreden Tevkifat Tutarı",
    "devreden_hesaplanan": "Sonraki Döneme Devreden Hesaplanan Geçici Vergi",
}


def _norm(s: str) -> str:
    text = str(s or "").strip().lower()
    text = text.translate(str.maketrans({
        "ı": "i", "İ": "i", "ğ": "g", "Ğ": "g", "ü": "u", "Ü": "u",
        "ş": "s", "Ş": "s", "ö": "o", "Ö": "o", "ç": "c", "Ç": "c",
    }))
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return re.sub(r"\s+", " ", text)


def _parse_amount(s: str) -> float:
    s = s.strip()
    neg = False
    if s.startswith("(") and s.endswith(")"):
        neg = True
        s = s[1:-1]
    if s.startswith("-"):
        neg = True
        s = s[1:]
    s = s.replace(".", "").replace(",", ".")
    try:
        v = float(s)
        return -v if neg else v
    except ValueError:
        return 0.0


# Etiket -> normalize sozluk (bir kez hesapla)
_ETIKET_NORM = {k: _norm(v) for k, v in _ALAN_ETIKETLERI.items()}


def parse_gecici_vergi(pdf_path: str) -> GeciciVergiDonemi:
    """Bir geçici vergi (KGV) beyannamesi PDF'ini ayristirir."""
    with pdfplumber.open(pdf_path) as pdf:
        all_text = []
        for page in pdf.pages:
            t = page.extract_text() or ""
            all_text.append(t)
    text = "\n".join(all_text)
    lines = [ln.rstrip() for ln in text.split("\n")]

    gv = GeciciVergiDonemi()
    gv.kaynak_dosya = pdf_path

    norm_full = _norm(text)

    # Donem numarasi: "Dönem 3. Dönem" / "Geçici Vergi Dönemi ... Dönem 3. Dönem"
    m = re.search(r"donem (\d)\. donem", norm_full)
    if m:
        gv.donem_no = int(m.group(1))
    gv.donem_adi = DONEM_ADLARI.get(gv.donem_no, "")

    # Yil: "Yılı 2024" / "Yıl 2024"
    m = re.search(r"yil[i]? (\d{4})", norm_full)
    if m:
        gv.yil = m.group(1)

    # VKN
    m = re.search(r"vergi kimlik numarasi (\d{10})", norm_full)
    if m:
        gv.vergi_no = m.group(1)

    # Tutar alanlari - satir basi birebir etiket eslesmesi
    for ln in lines:
        s = ln.strip()
        if not s:
            continue
        nm = _NUM_TAIL_RE.search(s)
        if not nm:
            continue
        sayi = nm.group(1)
        # Etiket = satirdaki son sayidan onceki kisim
        label = s[:nm.start()].strip()
        label_norm = _norm(label)
        if not label_norm:
            continue
        for key, etiket_norm in _ETIKET_NORM.items():
            if key in gv.degerler:
                continue
            if label_norm == etiket_norm:
                gv.degerler[key] = _parse_amount(sayi)
                break

    return gv
