"""Mizan ve dovizli mizan Excel parser modulleri."""
import re
import unicodedata

import openpyxl

from engine.data_model import MizanSatiri, DovizliMizanSatiri


def _normalize_text(value) -> str:
    """Basliklari Turkce karakter, noktalama ve bosluk farklarindan arindir."""
    if value is None:
        return ""
    text = str(value).strip().lower()
    text = text.translate(str.maketrans({
        "ı": "i",
        "İ": "i",
        "ğ": "g",
        "Ğ": "g",
        "ü": "u",
        "Ü": "u",
        "ş": "s",
        "Ş": "s",
        "ö": "o",
        "Ö": "o",
        "ç": "c",
        "Ç": "c",
    }))
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _to_float(v) -> float:
    """Excel hucresini float'a cevir."""
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace("\xa0", "").replace(" ", "")
    if not s:
        return 0.0
    # Turkce: 1.234.567,89 / Ingilizce: 1,234,567.89
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        s = s.replace(".", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return 0.0


def _to_account_code(value) -> str:
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def _contains(cell: str, keywords: list[str]) -> bool:
    return any(keyword in cell for keyword in keywords)


def _detect_header_row(ws, max_scan: int = 30, max_cols: int = 40) -> tuple[int, dict]:
    """Mizan sayfasinin baslik satirini bul, kolon eslestir.

    Returns: (header_row_index_0_based, {alan: kolon_index_0_based})
    """
    needed = {
        "hesap_kodu": ["tam hesap", "hesap no", "hesap kodu", "hesap kod", "t d hesap no"],
        "hesap_adi": ["hesap adi", "hesap acik", "hesap ismi", "aciklama"],
        "borc_toplam": ["toplam borc", "borc toplam", "top borc"],
        "alacak_toplam": ["toplam alacak", "alacak toplam", "toplam alac", "top alac"],
        "borc_bakiye": ["bakiye borc", "borc bakiye", "bak borc"],
        "alacak_bakiye": ["bakiye alacak", "alacak bakiye", "bakiye alac", "bak alac"],
        "para_birimi": ["para br", "para birimi", "doviz", "f p br", "p br", "rpbr", "r pbr"],
    }

    for ri in range(min(max_scan, ws.max_row or max_scan)):
        row = [ws.cell(row=ri + 1, column=ci + 1).value for ci in range(min(max_cols, ws.max_column or max_cols))]
        row_str = [_normalize_text(v) for v in row]
        mapping = {}
        for field, keywords in needed.items():
            for ci, cell in enumerate(row_str):
                if _contains(cell, keywords):
                    mapping.setdefault(field, ci)

        required = {"hesap_kodu", "hesap_adi", "borc_bakiye", "alacak_bakiye"}
        if required.issubset(mapping):
            return ri, mapping

    raise ValueError("Mizan sayfasinda baslik satiri bulunamadi.")


def _sheet_name_score(sheet_name: str, role: str) -> int:
    name = _normalize_text(sheet_name)
    score = 0
    if "mizan" in name:
        score += 20
    if role == "mizan":
        if "doviz" in name:
            score -= 25
        if "enflasyon" in name or "duzeltme" in name:
            score -= 15
    elif role == "dovizli_mizan" and "doviz" in name:
        score += 30
    return score


def _find_sheet_by_header(wb, preferred_name: str, role: str):
    """Istenen sayfa yoksa tum sayfalari tarayip en uygun mizan sayfasini sec."""
    if preferred_name and preferred_name in wb.sheetnames:
        ws = wb[preferred_name]
        try:
            header_row, mapping = _detect_header_row(ws)
            return ws, preferred_name, header_row, mapping
        except ValueError:
            pass

    ordered_names = []
    ordered_names.extend(name for name in wb.sheetnames if name not in ordered_names)

    candidates = []
    for order, name in enumerate(ordered_names):
        ws = wb[name]
        try:
            header_row, mapping = _detect_header_row(ws)
        except ValueError:
            continue
        score = 100 - order + len(mapping) * 5 + _sheet_name_score(name, role)
        if preferred_name and name == preferred_name:
            score += 100
        candidates.append((score, name, header_row, mapping))

    if not candidates:
        names = ", ".join(wb.sheetnames)
        raise ValueError(f"Mizan sayfasi otomatik bulunamadi. Dosyadaki sayfalar: {names}")

    candidates.sort(reverse=True, key=lambda item: item[0])
    _, name, header_row, mapping = candidates[0]
    return wb[name], name, header_row, mapping


def parse_mizan(xlsx_path: str, sheet_name: str = "Mizan") -> list:
    """Mizan sayfasini oku, MizanSatiri listesi dondur."""
    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    try:
        ws, _selected_sheet, header_row, mapping = _find_sheet_by_header(wb, sheet_name, "mizan")
        satirlar = []
        for row in ws.iter_rows(min_row=header_row + 2, values_only=True):
            if not row:
                continue
            hesap_kodu_raw = row[mapping["hesap_kodu"]] if mapping["hesap_kodu"] < len(row) else None
            if hesap_kodu_raw is None:
                continue
            hesap_kodu = _to_account_code(hesap_kodu_raw)
            if not hesap_kodu or hesap_kodu.lower() in ("nan", "none"):
                continue
            if not hesap_kodu[0].isdigit():
                continue

            hesap_adi = ""
            if mapping["hesap_adi"] < len(row) and row[mapping["hesap_adi"]]:
                hesap_adi = " ".join(str(row[mapping["hesap_adi"]]).split())

            satir = MizanSatiri(
                hesap_kodu=hesap_kodu,
                hesap_adi=hesap_adi,
                borc_toplam=_to_float(row[mapping["borc_toplam"]]) if "borc_toplam" in mapping and mapping["borc_toplam"] < len(row) else 0.0,
                alacak_toplam=_to_float(row[mapping["alacak_toplam"]]) if "alacak_toplam" in mapping and mapping["alacak_toplam"] < len(row) else 0.0,
                borc_bakiye=_to_float(row[mapping["borc_bakiye"]]) if mapping["borc_bakiye"] < len(row) else 0.0,
                alacak_bakiye=_to_float(row[mapping["alacak_bakiye"]]) if mapping["alacak_bakiye"] < len(row) else 0.0,
                para_birimi=str(row[mapping["para_birimi"]]).strip() if "para_birimi" in mapping and mapping["para_birimi"] < len(row) and row[mapping["para_birimi"]] else "TL",
            )
            satirlar.append(satir)
        return satirlar
    finally:
        wb.close()


def _detect_dovizli_header_row(ws, max_scan: int = 30, max_cols: int = 40) -> tuple:
    for ri in range(min(max_scan, ws.max_row or max_scan)):
        row = [ws.cell(row=ri + 1, column=ci + 1).value for ci in range(min(max_cols, ws.max_column or max_cols))]
        row_str = [_normalize_text(v) for v in row]
        mapping = {}
        for ci, cell in enumerate(row_str):
            if "hesap no" in cell or "hesap kod" in cell or "tam hesap" in cell:
                mapping.setdefault("hesap_kodu", ci)
            elif "hesap ad" in cell or "hesap acik" in cell:
                mapping.setdefault("hesap_adi", ci)
            elif cell.startswith("r pbr") or cell.startswith("r p br") or "doviz cinsi" in cell or "rpbr" in cell:
                mapping.setdefault("doviz_cinsi", ci)
            elif "top borc r p" in cell:
                mapping.setdefault("dov_borc_top", ci)
            elif "top alac r p" in cell:
                mapping.setdefault("dov_alac_top", ci)
            elif "bak borc r p" in cell:
                mapping.setdefault("dov_borc_bak", ci)
            elif "bak alac r p" in cell:
                mapping.setdefault("dov_alac_bak", ci)
            elif cell == "toplam borc":
                mapping.setdefault("tl_borc_top", ci)
            elif cell in ("toplam alac", "toplam alacak"):
                mapping.setdefault("tl_alac_top", ci)
            elif cell == "bakiye borc":
                mapping.setdefault("tl_borc_bak", ci)
            elif cell in ("bakiye alac", "bakiye alacak"):
                mapping.setdefault("tl_alac_bak", ci)
        if {"hesap_kodu", "tl_borc_bak", "tl_alac_bak"}.issubset(mapping):
            return ri, mapping
    return None, {}


def _find_dovizli_sheet(wb, preferred_name: str):
    if preferred_name and preferred_name in wb.sheetnames:
        ws = wb[preferred_name]
        header_row, mapping = _detect_dovizli_header_row(ws)
        if header_row is not None:
            return ws, header_row, mapping

    ordered_names = []
    ordered_names.extend(
        name for name in wb.sheetnames
        if name not in ordered_names and "doviz" in _normalize_text(name)
    )
    ordered_names.extend(name for name in wb.sheetnames if name not in ordered_names)

    candidates = []
    for order, name in enumerate(ordered_names):
        ws = wb[name]
        header_row, mapping = _detect_dovizli_header_row(ws)
        if header_row is None:
            continue
        has_foreign_cols = any(key.startswith("dov_") for key in mapping) or "doviz_cinsi" in mapping
        if not has_foreign_cols:
            continue
        score = 100 - order + len(mapping) * 5 + _sheet_name_score(name, "dovizli_mizan")
        if preferred_name and name == preferred_name:
            score += 100
        candidates.append((score, name, header_row, mapping))

    if not candidates:
        return None, None, {}
    candidates.sort(reverse=True, key=lambda item: item[0])
    _, name, header_row, mapping = candidates[0]
    return wb[name], header_row, mapping


def parse_dovizli_mizan(xlsx_path: str, sheet_name: str = "Dovizli Mizan") -> list:
    """Dovizli mizan sayfasini oku. Bulunamazsa bos liste dondur."""
    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    try:
        ws, header_row, mapping = _find_dovizli_sheet(wb, sheet_name)
        if ws is None:
            return []

        satirlar = []
        for row in ws.iter_rows(min_row=header_row + 2, values_only=True):
            if not row:
                continue
            hk_raw = row[mapping["hesap_kodu"]] if mapping["hesap_kodu"] < len(row) else None
            if hk_raw is None:
                continue
            hesap_kodu = _to_account_code(hk_raw)
            if not hesap_kodu or not hesap_kodu[0].isdigit():
                continue

            hesap_adi = ""
            if "hesap_adi" in mapping and mapping["hesap_adi"] < len(row) and row[mapping["hesap_adi"]]:
                hesap_adi = " ".join(str(row[mapping["hesap_adi"]]).split())
            doviz_cinsi = ""
            if "doviz_cinsi" in mapping and mapping["doviz_cinsi"] < len(row) and row[mapping["doviz_cinsi"]]:
                doviz_cinsi = str(row[mapping["doviz_cinsi"]]).strip().upper()

            satir = DovizliMizanSatiri(
                hesap_kodu=hesap_kodu,
                hesap_adi=hesap_adi,
                doviz_cinsi=doviz_cinsi,
                doviz_borc_toplam=_to_float(row[mapping["dov_borc_top"]]) if "dov_borc_top" in mapping and mapping["dov_borc_top"] < len(row) else 0.0,
                doviz_alacak_toplam=_to_float(row[mapping["dov_alac_top"]]) if "dov_alac_top" in mapping and mapping["dov_alac_top"] < len(row) else 0.0,
                doviz_borc_bakiye=_to_float(row[mapping["dov_borc_bak"]]) if "dov_borc_bak" in mapping and mapping["dov_borc_bak"] < len(row) else 0.0,
                doviz_alacak_bakiye=_to_float(row[mapping["dov_alac_bak"]]) if "dov_alac_bak" in mapping and mapping["dov_alac_bak"] < len(row) else 0.0,
                tl_borc_toplam=_to_float(row[mapping["tl_borc_top"]]) if "tl_borc_top" in mapping and mapping["tl_borc_top"] < len(row) else 0.0,
                tl_alacak_toplam=_to_float(row[mapping["tl_alac_top"]]) if "tl_alac_top" in mapping and mapping["tl_alac_top"] < len(row) else 0.0,
                tl_borc_bakiye=_to_float(row[mapping["tl_borc_bak"]]) if mapping["tl_borc_bak"] < len(row) else 0.0,
                tl_alacak_bakiye=_to_float(row[mapping["tl_alac_bak"]]) if mapping["tl_alac_bak"] < len(row) else 0.0,
            )
            satirlar.append(satir)
        return satirlar
    finally:
        wb.close()
