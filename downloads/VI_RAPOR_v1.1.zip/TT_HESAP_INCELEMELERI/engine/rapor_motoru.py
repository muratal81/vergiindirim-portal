"""Tam tasdik raporu metin uretim motoru.

Bu modul, RaporVerisi'nden hareketle 'III- Hesap Incelemeleri' bolumune
ait paragraf ve tablolari uretir. Cikti olarak bir 'BlokListesi' dondurur;
docx_writer modulu bu listeyi dogrudan Word dosyasina yazar.

Blok tipleri:
  - {"tip": "h1", "metin": ...}   -> Buyuk baslik
  - {"tip": "h2", "metin": ...}   -> Orta baslik (A. BILANCO HESAPLARI)
  - {"tip": "h3", "metin": ...}   -> Alt baslik (1.1. Kasa)
  - {"tip": "p",  "metin": ...}   -> Paragraf
  - {"tip": "doviz_tablo", "satirlar": [...], "toplam_tl": ...}
  - {"tip": "tablo", "basliklar": [...], "satirlar": [...], "toplam": (...)}
  - {"tip": "sari_uyari", "metin": ...}  -> Sari arka planli uyari blogu
"""
from engine.data_model import RaporVerisi
from engine.formatlar import tutar, tutar_sade, doviz_format, kur_format


def hesap_bakiye_tam(rapor: RaporVerisi, hesap_kodu: str) -> float:
    """Ana hesap kodunun net bakiyesi.

    Once 3 haneli ana hesap satiri aranir. Mizan ana hesap satirini
    icermiyorsa (yalnizca alt hesaplar mevcutsa), ilgili kodun en sig
    alt hesap seviyesi toplanir; bu sayede 630/631/632/660 gibi yalnizca
    alt detayda tutulan hesaplar atlanmaz. Cifte sayma olmamasi icin
    yalnizca en sig (en az noktali) alt seviye toplanir.
    """
    target = hesap_kodu.strip()
    for s in rapor.mizan:
        if s.hesap_kodu.strip() == target:
            return s.net_bakiye
    # Ana satir yok -> alt hesaplardan en sig seviyeyi topla
    alt = [s for s in rapor.mizan if s.hesap_kodu.strip().startswith(target + ".")]
    if alt:
        min_nokta = min(s.hesap_kodu.strip().count(".") for s in alt)
        return sum(s.net_bakiye for s in alt if s.hesap_kodu.strip().count(".") == min_nokta)
    return 0.0


def _yd_gruplar(rapor: RaporVerisi) -> tuple:
    """Yeniden degerleme satirlarini MDV (25x) ve MODV (26x) olarak ayirir."""
    satirlar = list(getattr(rapor, "yeniden_degerleme_satirlari", []) or [])
    mdv = [s for s in satirlar if str(s.hesap_kodu).strip()[:2] == "25"]
    modv = [s for s in satirlar if str(s.hesap_kodu).strip()[:2] == "26"]
    return mdv, modv


def _yd_ozet_tablo(satirlar: list) -> tuple:
    """Yeniden degerleme ozet tablo blogu ve net toplam dondurur. (blok, net) doner."""
    aktif = sum(s.aktif_degerleme_tutari for s in satirlar)
    amt = sum(s.amortisman_artis_tutari for s in satirlar)
    net = sum(s.net_degerleme_tutari for s in satirlar)
    blok = {
        "tip": "tablo",
        "basliklar": ["Hesap", "Hesap Adı", "Aktif Değerleme Tutarı (TL)",
                      "Birikmiş Amort. Artışı (TL)", "Net Değerleme Tutarı (TL)"],
        "satirlar": [
            (s.hesap_kodu, s.hesap_adi or "", tutar_sade(s.aktif_degerleme_tutari),
             tutar_sade(s.amortisman_artis_tutari), tutar_sade(s.net_degerleme_tutari))
            for s in satirlar
        ],
        "toplam": ("Toplam", "", tutar_sade(aktif), tutar_sade(amt), tutar_sade(net)),
    }
    return blok, net


def _mizan_adi(rapor: RaporVerisi, kod: str) -> str:
    """Mizandan hesap kodunun adini bulur (once tam eslesme, sonra ilk alt hesap)."""
    kod = kod.strip()
    for s in rapor.mizan:
        if s.hesap_kodu.strip() == kod:
            return (s.hesap_adi or "").strip()
    for s in rapor.mizan:
        if s.hesap_kodu.strip().startswith(kod + "."):
            return (s.hesap_adi or "").strip()
    return ""


def _grup_dokum(rapor: RaporVerisi, kodlar: list) -> list:
    """3 haneli hesap listesi icin (kod, ad, abs_bakiye) dokumu - bakiyesi olanlar."""
    out = []
    for k in kodlar:
        b = hesap_bakiye_tam(rapor, k)
        if abs(b) > 0.005:
            out.append((k, _mizan_adi(rapor, k) or k, abs(b)))
    return out


def _alt_hesap_dokumu(rapor: RaporVerisi, ana_kod: str) -> list:
    """ana_kod'un en sig (en az noktali) alt hesap seviyesini (kod, ad, abs_bakiye) dondurur."""
    ana_kod = ana_kod.strip()
    alt = [s for s in rapor.mizan if s.hesap_kodu.strip().startswith(ana_kod + ".")]
    if not alt:
        return []
    min_nokta = min(s.hesap_kodu.strip().count(".") for s in alt)
    out = []
    for s in alt:
        if s.hesap_kodu.strip().count(".") == min_nokta and abs(s.net_bakiye) > 0.005:
            out.append((s.hesap_kodu.strip(), (s.hesap_adi or "").strip(), abs(s.net_bakiye)))
    return out


def _beyanname_fgk_kkeg(rapor: RaporVerisi) -> float:
    """Beyannamede beyan edilen FGK KKEG tutarini (KVK 11/1-i) dondurur.

    KKEG dokumunde "finansman gider kisitlamasi" iceren satir esas alinir;
    "...kisitlamasi haric" ifadeli satir HARIC tutulur. Bulunamazsa 0 doner.
    """
    bv = getattr(rapor, "beyanname", None)
    if not bv or not getattr(bv, "kkeg_satirlari", None):
        return 0.0
    for ad, tut in bv.kkeg_satirlari:
        a = (ad or "").lower()
        if "finansman gider" in a and "haric" not in a and "hariç" not in a:
            return abs(tut)
    return 0.0


def _fgk_hesapla(rapor: RaporVerisi) -> dict | None:
    """Finansman gider kisitlamasi hesaplamasi (KVK 11/1-i).

    Yabanci kaynak / ozkaynak tutarlari mizanin 3 haneli TDHP ana hesaplarindan
    toplanir (musteri/alt detay kodlari haric). 18 Seri No.lu KVK Genel Tebligi
    uyarinca yabanci kaynak toplamina vergi karsiliklari (370/371) dahil edilmez
    ve finansman gideri olarak yalnizca vadeye bagli finansman giderleri ile kur
    farklari (660/661) dikkate alinir.

    KKEG tutari, raporun beyanname ile birebir uyumlu olmasi icin ONCELIKLE
    beyannamede beyan edilen FGK tutarina sabitlenir; beyannamede yoksa mizandan
    hesaplanan tutar kullanilir. fg_top ve beyan tutari sifirsa None doner.
    """
    b660 = abs(hesap_bakiye_tam(rapor, "660"))
    b661 = abs(hesap_bakiye_tam(rapor, "661"))
    fg_top = b660 + b661

    # Yabanci kaynak / ozkaynak hesaplamasinda HARIC tutulacak hesaplar:
    # vergi karsiliklari (370 Donem Kari Vergi ve Diger Yasal Yukumluluk Karsiliklari,
    # 371 Donem Karinin Pesin Odenen Vergi ve Diger Yukumlulukleri (-)).
    haric_kodlar = {"370", "371"}

    def _tdhp_ana_grup_toplami(prefix: str) -> float:
        top = 0.0
        for s in rapor.mizan:
            hk = s.hesap_kodu.strip()
            if hk.startswith(prefix) and len(hk) == 3 and hk.isdigit() and hk not in haric_kodlar:
                top += s.net_bakiye
        return top

    kvyk = abs(_tdhp_ana_grup_toplami("3"))
    uvyk = abs(_tdhp_ana_grup_toplami("4"))
    ozkaynak = abs(_tdhp_ana_grup_toplami("5"))
    toplam_yk = kvyk + uvyk
    ozk_asan = toplam_yk - ozkaynak

    beyan_kkeg = _beyanname_fgk_kkeg(rapor)
    if fg_top <= 0.005 and beyan_kkeg <= 0.005:
        return None

    sonuc = {
        "fg_top": fg_top, "kvyk": kvyk, "uvyk": uvyk, "ozkaynak": ozkaynak,
        "toplam_yk": toplam_yk, "ozk_asan": ozk_asan, "kisitlama_var": False,
        "beyan_kkeg": beyan_kkeg,
    }
    if (ozk_asan > 0 and toplam_yk > 0) or beyan_kkeg > 0.005:
        kisitlama_oran = (ozk_asan / toplam_yk) if toplam_yk > 0 else 0.0
        # Mizandan hesaplanan tutarlar (tablonun ic tutarliligi icin saklanir).
        hesaplanan_kisitlama = fg_top * kisitlama_oran
        hesaplanan_kkeg = hesaplanan_kisitlama * 0.10
        # KKEG'i beyanname ile uyumlu tutmak icin oncelikle beyan edilen tutara sabitle.
        if beyan_kkeg > 0.005:
            kkeg = beyan_kkeg
            kisitlama_tutar = kkeg / 0.10
        else:
            kisitlama_tutar = hesaplanan_kisitlama
            kkeg = hesaplanan_kkeg
        sonuc.update({
            "kisitlama_var": True,
            "kisitlama_oran": kisitlama_oran,
            "kisitlama_tutar": kisitlama_tutar,
            "kkeg": kkeg,
            "hesaplanan_kisitlama": hesaplanan_kisitlama,
            "hesaplanan_kkeg": hesaplanan_kkeg,
        })
    return sonuc


def bilanco_satir_bul(rapor: RaporVerisi, anahtarlar: list[str]) -> float:
    """Bilanco kalemlerinden anahtar kelimeyi iceren cari donem tutarini bul."""
    for k in rapor.bilanco:
        for ah in anahtarlar:
            if ah.lower() in k.aciklama.lower():
                return k.cari_donem
    return 0.0


def gelir_tablo_satir_bul(rapor: RaporVerisi, anahtarlar: list[str]) -> float:
    for k in rapor.gelir_tablosu:
        for ah in anahtarlar:
            if ah.lower() in k.aciklama.lower():
                return k.cari_donem
    return 0.0


# ============================================================
# YABANCI PARA HESAPLARI - Bolum 1
# ============================================================

YABANCI_PARA_HESAPLARI = [
    # (hesap_kodu, baslik, ekstra_aciklama)
    ("100", "Kasa", "efektif"),  # efektif doviz alis
    ("102", "Bankalar", "alis"),  # doviz alis
    ("120", "Alıcılar", "alis"),
    ("159", "Verilen Sipariş Avansları (K.V.)", "alis"),
    ("259", "Verilen Sipariş Avansları (U.V.)", "alis"),
    ("300", "Banka Kredileri (K.V.)", "yatirim"),
    ("301", "Finansal Kiralama İşlemlerinden Borçlar Hesabı (K.V.)", "yatirim_lease"),
    ("302", "Ertelenmiş Finansal Kiralama Borçlanma Maliyeti Hesabı (K.V.)", "yatirim_lease_eksi"),
    ("303", "Uzun Vadeli Kredilerin Anapara Taksitleri", "yatirim"),
    ("309", "Diğer Mali Borçlar Hesabı", "yatirim"),
    ("320", "Satıcılar (K.V.)", "alis"),
    ("340", "Alınan Sipariş Avansları (K.V.)", "alis"),
    ("381", "Gider Tahakkukları (K.V.)", "alis"),
    ("400", "Banka Kredileri (U.V.)", "yatirim"),
    ("401", "Finansal Kiralama İşlemlerinden Borçlar (U.V.)", "yatirim_lease"),
    ("402", "Ertelenmiş Finansal Kiralama Borçlanma Maliyeti Hesabı (U.V.)", "yatirim_lease_eksi"),
]


def _doviz_paragraf_metni(rapor: RaporVerisi, hesap_kodu: str, baslik: str, tip: str) -> str:
    """Yabanci para hesap incelemesi paragrafi olusturur."""
    ana_bakiye = abs(hesap_bakiye_tam(rapor, hesap_kodu))
    dovizli_tl = abs(rapor.dovizli_bakiye_toplami(hesap_kodu))
    donem_sonu = rapor.mukellef.donem_sonu

    if ana_bakiye < 0.005:
        return ""

    kur_aciklama = "döviz kurları"
    if tip == "efektif":
        kur_aciklama = "efektif döviz alış kuru"

    # Yatirim finansmanli kredi grubu icin ek metin
    yatirim_metni = ""
    if tip in ("yatirim", "yatirim_lease"):
        yatirim_metni = (
            "163 seri No.lu VUK ve 187 seri numaralı GVK Genel Tebliği hükümleri kapsamında "
            "Yatırım finansmanında kullanılan kredilerle ilgili faiz ve kur farklarının yatırımın "
            "maliyetine diğerlerinin ise gelir tablosu hesaplarına aktarıldığı tespit edilmiştir."
        )
    elif tip == "yatirim_lease_eksi":
        yatirim_metni = (
            "163 seri No.lu VUK ve 187 seri numaralı GVK Genel Tebliği hükümleri kapsamında "
            "Yatırım finansmanında kullanılan kredilerle ilgili kur farklarının yatırımın "
            "maliyetinden düşüldüğü diğerlerinin ise gelir tablosu hesaplarına aktarıldığı "
            "tespit edilmiştir."
        )
    else:
        yatirim_metni = "oluşan kur farkının gelir tablosu hesaplarına aktarıldığı tespit edilmiştir."

    # Tamami dovizli mi? "Tamami" ifadesini yalnizca TL kalanin gercekten
    # ihmal edilebilir oldugu durumda kullan (oransal < %0,5 VE mutlak < 100.000 TL).
    # Aksi halde dovizli kismin tutarini acikca belirt (asiri "tamami dovizli"
    # iddiasindan kacinmak icin).
    kalan_tl = ana_bakiye - dovizli_tl
    oransal = abs(kalan_tl) / max(ana_bakiye, 1)
    tamami_dovizli = dovizli_tl > 0 and oransal < 0.005 and abs(kalan_tl) < 100_000

    if tamami_dovizli:
        # "tamamı dövizli ... hesaplarından oluştuğu"
        kisim_metni = f"tamamı dövizli {baslik} hesaplarından oluştuğu"
    else:
        kisim_metni = (
            f"{tutar(dovizli_tl)} tutarındaki kısmının dövizli {baslik} hesaplarından, "
            f"kalan {tutar(abs(kalan_tl))} tutarındaki kısmının ise Türk Lirası {baslik} "
            f"hesaplarından oluştuğu"
        )

    metin = (
        f"{donem_sonu} tarihli kurum bilançosunda {tutar(ana_bakiye)} olarak yer alan "
        f"{baslik} hesabının {kisim_metni}, ilgili hesap bakiyelerinin "
        f"{rapor.kurlar.teblig_tarihi} tarihli ve {rapor.kurlar.rg_no} sayılı Resmi Gazete'de "
        f"yayımlanan {rapor.kurlar.teblig_no} Sıra No.lu Vergi Usul Kanunu Genel Tebliği'nin ekinde "
        f"yer alan {kur_aciklama} ile değerlendiği ve "
        f"{yatirim_metni}"
    )
    return metin


def _doviz_tablo_satirlari(rapor: RaporVerisi, hesap_kodu: str) -> list:
    """Hesap kodu icin doviz cinsi bazinda tablo satirlari uretir."""
    detay = rapor.dovizli_detay(hesap_kodu)
    satirlar = []
    for dc, (doviz, kur, tl) in detay.items():
        if abs(doviz) < 0.005:
            continue
        satirlar.append({
            "doviz_cinsi": dc,
            "doviz_tutari": abs(doviz),
            "kur": abs(kur),
            "bakiye_tl": abs(tl),
        })
    return satirlar


def bilanco_dovizli_bolum_bloklari(rapor: RaporVerisi) -> list:
    """1. Yabanci Para Cinsinden Izlenen Hesaplar — bolum tum bloklari."""
    bloklar = []

    bloklar.append({
        "tip": "h3",
        "metin": "1. Yabancı Para Cinsinden İzlenen Hesaplar:",
    })
    bloklar.append({
        "tip": "p",
        "metin": (
            "Şirketin yabancı para cinsinden izlenen hesapları 213 Sayılı Vergi Usul Kanunu'nun "
            "(VUK) 280'inci maddesinde düzenlenmiştir."
        ),
    })
    bloklar.append({
        "tip": "p",
        "metin": (
            "VUK'un 280'inci maddesinde \"Yabancı paraların borsa rayici ile değerleneceği, Borsa "
            "rayicinin takarrüründe muvazaa olduğu anlaşılırsa bu rayiç yerine alış bedeli esas "
            "alınacağı, Yabancı paranın borsada rayici yoksa, değerlemeye uygulanacak kur Maliye "
            f"Bakanlığınca tespit olunacağı,\" ifade edilmiştir. Bu kapsamda şirketin yabancı para "
            f"cinsinden bulunan hesapları {rapor.kurlar.teblig_tarihi} tarihli ve {rapor.kurlar.rg_no} "
            f"sayılı Resmi Gazete'de yayımlanan {rapor.kurlar.teblig_no} Sıra No.lu Vergi Usul Kanunu "
            "Genel Tebliği'nin ekinde yer alan döviz kurları üzerinden değerlenmiştir."
        ),
    })

    sira = 0
    for hesap_kodu, baslik, tip in YABANCI_PARA_HESAPLARI:
        dovizli_tl = abs(rapor.dovizli_bakiye_toplami(hesap_kodu))
        ana_bakiye = abs(hesap_bakiye_tam(rapor, hesap_kodu))
        if dovizli_tl < 0.005 or ana_bakiye < 0.005:
            continue
        sira += 1
        bloklar.append({"tip": "h4", "metin": f"1.{sira}. {baslik}:"})
        metin = _doviz_paragraf_metni(rapor, hesap_kodu, baslik, tip)
        if metin:
            bloklar.append({"tip": "p", "metin": metin})
            bloklar.append({"tip": "p", "metin": "Bilanço tarihi itibarıyla bakiye veren dövizli " + baslik + " hesaplarının özet dökümü aşağıdaki gibidir;"})
            satirlar = _doviz_tablo_satirlari(rapor, hesap_kodu)
            if satirlar:
                bloklar.append({"tip": "doviz_tablo", "satirlar": satirlar})

    return bloklar


# ============================================================
# DIGER BILANCO HESAPLARI
# ============================================================

def diger_bilanco_bloklari(rapor: RaporVerisi, sira_baslangic: int = 2) -> list:
    """Yabanci para haricindeki bilanco hesap incelemeleri."""
    bloklar = []
    sira = sira_baslangic
    donem_sonu = rapor.mukellef.donem_sonu

    # 100 - Kasa
    # Dovizli kismi varsa "1. Yabanci Para Cinsinden Izlenen Hesaplar" bolumunde
    # ele alindigindan, burada yalnizca tamami TL olan Kasa icin blok uretilir.
    b100 = abs(hesap_bakiye_tam(rapor, "100"))
    dovizli_100 = abs(rapor.dovizli_bakiye_toplami("100"))
    if b100 > 0.005 and dovizli_100 < 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Kasa:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihi itibarıyla Kasa hesabının bakiyesi {tutar(b100)} olup; "
            "bu tutarın tamamı Türk Lirası hesabına aittir."
        )})
        sira += 1

    # 102 - Bankalar (TL)
    # Dovizli kismi "1. Yabanci Para Cinsinden Izlenen Hesaplar" bolumunde
    # toplam bakiye ile birlikte aciklandigindan, burada yalnizca tamami TL olan
    # Bankalar hesabi icin blok uretilir.
    b102 = abs(hesap_bakiye_tam(rapor, "102"))
    dovizli_102 = abs(rapor.dovizli_bakiye_toplami("102"))
    if b102 > 0.005 and dovizli_102 < 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Bankalar:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihli bilançosunda Bankalar hesabının bakiyesi {tutar(b102)} "
            "olduğu görülmüş olup; tamamı Türk Lirası mevduat hesaplarından oluşmaktadır."
        )})
        sira += 1

    # 120 - Alicilar / Ticari Alacaklar (K.V.)
    # Dovizli kismi yabanci para bolumunde ele alinir; supheli alacaklar (128) ve
    # karsiligi (129) takip eden bloklarda gosterilir. Burada tamami TL olan
    # Alicilar (120) hesabi rapora dahil edilir.
    b120 = abs(hesap_bakiye_tam(rapor, "120"))
    dovizli_120 = abs(rapor.dovizli_bakiye_toplami("120"))
    if b120 > 0.005 and dovizli_120 < 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Ticari Alacaklar (K.V.):"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihli bilançosunda Ticari Alacaklar hesap grubunda yer alan "
            f"Alıcılar hesabının bakiyesi {tutar(b120)}'dir."
        )})
        sira += 1

    # 101 - Alinan Cekler
    bakiye = hesap_bakiye_tam(rapor, "101")
    if abs(bakiye) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Alınan Çekler:"})
        bloklar.append({"tip": "p", "metin": f"Şirketin {donem_sonu} tarihi itibariyle Alınan Çekler hesabının bakiyesi {tutar(abs(bakiye))}'dir."})
        sira += 1

    # 103 - Verilen Cekler ve Odeme Emirleri
    bakiye = hesap_bakiye_tam(rapor, "103")
    if abs(bakiye) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Verilen Çekler ve Ödeme Emirleri (-):"})
        bloklar.append({"tip": "p", "metin": f"Şirketin {donem_sonu} tarihi itibariyle Verilen Çekler ve Ödeme Emirleri hesabının bakiyesi ({tutar_sade(abs(bakiye))}-TL) olup tamamı TL cinsinden ve ödemesi sonraki döneme aittir."})
        sira += 1

    # 108 - Diger Hazir Degerler
    bakiye = hesap_bakiye_tam(rapor, "108")
    if abs(bakiye) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Diğer Hazır Değerler:"})
        bloklar.append({"tip": "p", "metin": f"Şirketin {donem_sonu} tarihi itibariyle Diğer Hazır Değerler hesabının bakiyesi {tutar(abs(bakiye))}'dir."})
        sira += 1

    # 11x - Menkul Kiymetler
    bakiye_11 = sum(hesap_bakiye_tam(rapor, kod) for kod in ["110", "111", "112", "118", "119"])
    if abs(bakiye_11) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Menkul Kıymetler:"})
        deger_dusukluk = abs(hesap_bakiye_tam(rapor, "119"))
        diger_mk = abs(hesap_bakiye_tam(rapor, "118"))
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihi itibarıyla Menkul Kıymetler hesabının bakiyesi "
            f"{tutar(abs(bakiye_11))} olup; bahse konu fonların dönem sonu değerlemesinden elde edilen "
            "kazançlar gelir hesaplarına aktarılmıştır."
        )})
        sira += 1

    # 126 - Verilen Depozito ve Teminatlar
    bakiye = hesap_bakiye_tam(rapor, "126")
    if abs(bakiye) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Verilen Depozito ve Teminatlar:"})
        bloklar.append({"tip": "p", "metin": f"Şirketin {donem_sonu} tarihi itibariyle Verilen Depozito ve Teminatlar hesabının bakiyesi {tutar(abs(bakiye))}'dir."})
        bloklar.append({"tip": "p", "metin": (
            "Hesapta yer alan kıymetlerin incelenmesi neticesinde, bunların işletmenin üçüncü kişilere "
            "nakit olarak verdiği depozito ve teminatları temsil ettiği, dönem sonu itibarıyla mevcudiyetlerinin "
            "ilgili belge ve sözleşmelerle teyit edildiği görülmüştür."
        )})
        sira += 1

    # 128 - Supheli Ticari Alacaklar
    b128 = hesap_bakiye_tam(rapor, "128")
    if abs(b128) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Şüpheli Ticari Alacaklar:"})
        bloklar.append({"tip": "p", "metin": (
            f"{donem_sonu} tarihi itibariyle Şüpheli Ticari Alacaklar (128) hesabının bakiyesi {tutar(abs(b128))}'dir. "
            "Dönem içinde şüpheli hale gelen alacaklar ile dava/icra dosyalarına intikal ettirilen alacaklar "
            "ilgili çalışma kâğıtlarında incelenmiştir."
        )})
        sira += 1

    # 129 - Supheli Ticari Alacaklar Karsiligi
    b129 = abs(hesap_bakiye_tam(rapor, "129"))
    if b129 > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Şüpheli Ticari Alacaklar Karşılığı (-):"})
        bloklar.append({"tip": "p", "metin": (
            f"Şüpheli ticari alacaklar karşılığı (129) hesabının bakiyesi {tutar(b129)}'dir. "
            "Şirketin faturaya bağlı ticari alacaklarının şüpheli hale gelmiş, dava ve icra safhasına düşmüş "
            "alacakları için cari dönemde ayrılan karşılık tutarı ile cari ve geçmiş dönemde şüpheli hale "
            "gelmiş olan ancak tahsil edilen tutarların gelir tablosuna aktarıldığı tespit edilmiştir."
        )})
        sira += 1

    # 13x - Diger Alacaklar
    b13_kodlar = ["131", "132", "133", "135", "136", "137", "138", "139"]
    b13_toplam = sum(hesap_bakiye_tam(rapor, k) for k in b13_kodlar)
    if abs(b13_toplam) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Diğer Alacaklar (13 hesap grubu):"})
        personelden = abs(hesap_bakiye_tam(rapor, "135"))
        diger_cesitli = abs(hesap_bakiye_tam(rapor, "136"))
        parcalar = []
        if personelden > 0.005:
            parcalar.append(f"{tutar(personelden)}'i Personelden Alacaklar")
        if diger_cesitli > 0.005:
            parcalar.append(f"{tutar(diger_cesitli)}'i Diğer Çeşitli Alacaklar")
        detay = ", ".join(parcalar) + " hesabından oluşmaktadır." if parcalar else ""
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihli bilançosunda yer alan Diğer Alacakların Hesabının bakiyesi "
            f"{tutar(abs(b13_toplam))} olup; {detay}"
        )})
        sira += 1

    # 15x - Stoklar
    stok_kodlar = ["150", "151", "152", "153", "154", "155", "157", "158", "159"]
    stok_satirlari = []
    stok_aciklama = {
        "150": "İlk Madde ve Malzeme",
        "151": "Yarı Mamuller- Üretim",
        "152": "Mamuller",
        "153": "Ticari Mallar",
        "157": "Diğer Stoklar",
        "159": "Verilen Sipariş Avansları",
    }
    stok_toplam = 0.0
    for k in stok_kodlar:
        b = hesap_bakiye_tam(rapor, k)
        if abs(b) > 0.005:
            stok_satirlari.append({"kod": k, "ad": stok_aciklama.get(k, ""), "tutar": b})
            stok_toplam += b
    if stok_toplam > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Stoklar:"})
        bloklar.append({"tip": "p", "metin": (
            f"{donem_sonu} tarihli kurum bilançosunda {tutar(stok_toplam)} olarak yer alan Stoklar "
            "hesabının detayı aşağıdaki gibidir."
        )})
        bloklar.append({
            "tip": "tablo",
            "basliklar": ["Hesap Kodu", "Hesap Adı", "Dönem Sonu Stok Tutarı (TL)"],
            "satirlar": [(s["kod"], s["ad"], tutar_sade(s["tutar"])) for s in stok_satirlari],
            "toplam": ("Toplam", "", tutar_sade(stok_toplam)),
        })
        bloklar.append({"tip": "p", "metin": (
            "Stokların dönem sonu sayım ve değerleme işlemleri ile maliyet hesaplarına intikalinin VUK "
            "hükümlerine uygun olarak yapıldığı; stok hareketlerinin ilgili çalışma kâğıtlarında incelendiği "
            "tespit edilmiştir."
        )})
        sira += 1

    # 180/181 - Gelecek Aylara Ait Giderler ve Gelir Tahakkuklari
    b180 = hesap_bakiye_tam(rapor, "180")
    b181 = hesap_bakiye_tam(rapor, "181")
    if abs(b180) + abs(b181) > 0.005:
        toplam = abs(b180) + abs(b181)
        bloklar.append({"tip": "h3", "metin": f"{sira}. Gelecek Aylara Ait Giderler ve Gelir Tahakkukları:"})
        bloklar.append({"tip": "p", "metin": (
            f"{donem_sonu} tarihi itibariyle Gelecek Aylara Ait Giderler ve Gelir Tahakkukları hesabının "
            f"bakiyesi {tutar(toplam)} olup; {tutar(abs(b180))}'i Gelecek Aylara Ait Giderler hesabından, "
            f"{tutar(abs(b181))}'i ise Gelir Tahakkukları hesabından oluşmaktadır."
        )})
        bloklar.append({"tip": "p", "metin": (
            "Hesapta izlenen tutarların dönemsellik ilkesi gereğince ilgili oldukları döneme ait giderler ile "
            "tahakkuk eden gelirlerden oluştuğu, dayanak belgelerinin incelendiği tespit edilmiştir."
        )})
        sira += 1

    # 19x - Diger Donen Varliklar (KDV vs.)
    b19_isim = {
        "190": "Devreden KDV",
        "191": "İndirilecek KDV",
        "192": "Diğer KDV",
        "193": "Peşin Ödenen Vergiler ve Fonlar",
        "195": "İş Avansları",
        "196": "Personel Avansları",
        "197": "Sayım ve Tesellüm Noksanları",
        "198": "Diğer Çeşitli Dönen Varlıklar",
    }
    b19_parcalar = []
    b19_toplam = 0.0
    for k, ad in b19_isim.items():
        b = abs(hesap_bakiye_tam(rapor, k))
        if b > 0.005:
            b19_toplam += b
            b19_parcalar.append(f"{tutar(b)}'i {ad} hesabından")
    if b19_toplam > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Diğer Dönen Varlıklar:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihli bilançosunda yer alan Diğer Dönen Varlıkları "
            f"{tutar(b19_toplam)} olup; söz konusu tutarın " + ", ".join(b19_parcalar) + " oluşmaktadır."
        )})
        sira += 1

    # 25x - Maddi Duran Varliklar (MDV)
    mdv_kodlar = {
        "250": "Arazi ve Arsalar",
        "251": "Yer Altı ve Yer Üstü Düzenleri",
        "252": "Binalar",
        "253": "Tesis, Makine ve Cihazlar",
        "254": "Taşıtlar",
        "255": "Demirbaşlar",
        "256": "Diğer Maddi Duran Varlıklar",
        "257": "Birikmiş Amortismanlar",
        "258": "Yapılmakta Olan Yatırımlar",
        "259": "Verilen Avanslar",
    }
    mdv_satirlari = []
    mdv_toplam = 0.0
    for k, ad in mdv_kodlar.items():
        b = hesap_bakiye_tam(rapor, k)
        if abs(b) > 0.005:
            # 257 birikmis amortisman negatif gosterilir
            display_tutar = b
            if k == "257":
                display_tutar = -abs(b)  # parantezli gosterilecek
                mdv_toplam -= abs(b)
            else:
                mdv_toplam += abs(b)
            display_ad = ad + " (-)" if k == "257" else ad
            mdv_satirlari.append((k, display_ad, display_tutar))

    if mdv_satirlari:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Maddi Duran Varlıklar:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihi itibarıyla Maddi Duran Varlıkları {tutar(mdv_toplam)} olup; "
            "Maddi Duran Varlıklar hesap gruplarının detayı aşağıdaki gibidir;"
        )})
        bloklar.append({
            "tip": "tablo",
            "basliklar": ["Maddi Duran Varlıklar", "Tutar (TL)"],
            "satirlar": [(s[1], tutar_sade(s[2])) for s in mdv_satirlari],
            "toplam": ("Toplam", tutar_sade(mdv_toplam)),
        })
        bloklar.append({"tip": "p", "metin": (
            "2025 hesap döneminde VUK Mükerrer 298 inci maddesinin (A) fıkrası kapsamında enflasyon "
            "düzeltmesi uygulanmamıştır. Amortismana tabi maddi duran varlıklar ile bunlara ait birikmiş "
            "amortismanlar, VUK Mükerrer 298 inci maddesinin (Ç) fıkrası uyarınca sürekli yeniden "
            "değerlemeye tabi tutulmuş; oluşan net değer artışı bilançonun pasifinde 522 Maddi Duran "
            "Varlık Yeniden Değerleme Artışları hesabında özel bir fon olarak izlenmiştir."
        )})
        mdv_yd, _modv_yd = _yd_gruplar(rapor)
        if mdv_yd:
            tablo_blok, _ = _yd_ozet_tablo(mdv_yd)
            bloklar.append({"tip": "p", "metin": (
                "Maddi duran varlıklara ilişkin yeniden değerlemenin hesap bazında özeti aşağıdaki "
                "gibidir;"
            )})
            bloklar.append(tablo_blok)
        sira += 1

    # 259 - Verilen Avanslar (U.V.)
    b259 = abs(hesap_bakiye_tam(rapor, "259"))
    if b259 > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Verilen Sipariş Avansları (U.V.):"})
        bloklar.append({"tip": "p", "metin": (
            f"{donem_sonu} tarihli kurum bilançosunda {tutar(b259)} olarak yer alan uzun vadeli sipariş "
            "avansları hesabına ait tutarların, ileride teslim alınacak mal ve hizmetler için verilen "
            "avanslardan oluştuğu ve dayanak belgeleriyle incelendiği tespit edilmiştir."
        )})
        sira += 1

    # 26x - Maddi Olmayan Duran Varliklar (MODV)
    modv_kodlar = {
        "260": "Haklar",
        "263": "Araştırma ve Geliştirme Giderleri",
        "264": "Özel Maliyetler",
        "267": "Diğer Maddi Olmayan Duran Varlıklar",
        "268": "Birikmiş Amortismanlar",
    }
    modv_satirlari = []
    modv_toplam = 0.0
    for k, ad in modv_kodlar.items():
        b = hesap_bakiye_tam(rapor, k)
        if abs(b) > 0.005:
            if k == "268":
                modv_satirlari.append((k, ad + " (-)", -abs(b)))
                modv_toplam -= abs(b)
            else:
                modv_satirlari.append((k, ad, abs(b)))
                modv_toplam += abs(b)
    if modv_satirlari:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Maddi Olmayan Duran Varlıklar:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihi itibarıyla Maddi Olmayan Duran Varlıkları {tutar(modv_toplam)} "
            "olup; Maddi Olmayan Duran Varlıklar hesabının detayı aşağıdaki gibidir;"
        )})
        bloklar.append({
            "tip": "tablo",
            "basliklar": ["Maddi Olmayan Duran Varlıklar", "Tutar (TL)"],
            "satirlar": [(s[1], tutar_sade(s[2])) for s in modv_satirlari],
            "toplam": ("Toplam", tutar_sade(modv_toplam)),
        })
        bloklar.append({"tip": "p", "metin": (
            "İşletmenin sahip olduğu patent, lisans gibi gayri maddi hakları ve bu hakların oluşturulması "
            "sürecindeki harcamaları izlediği Maddi Olmayan Duran Varlıklar hesaplarının dayanak belgeleri "
            "incelenmiştir. Amortismana tabi maddi olmayan duran varlıklar VUK Mükerrer 298 inci maddesinin "
            "(Ç) fıkrası kapsamında sürekli yeniden değerlemeye tabi tutulmuş olup, değer artışları 522 "
            "hesapta izlenmektedir. 263 Araştırma ve Geliştirme Giderleri hesabında oluşan tutarların "
            "Ar-Ge indirimi hesabında dikkate alınmadığı tespit edilmiştir."
        )})
        _mdv_yd, modv_yd = _yd_gruplar(rapor)
        if modv_yd:
            tablo_blok, _ = _yd_ozet_tablo(modv_yd)
            bloklar.append({"tip": "p", "metin": (
                "Maddi olmayan duran varlıklara ilişkin yeniden değerlemenin hesap bazında özeti "
                "aşağıdaki gibidir;"
            )})
            bloklar.append(tablo_blok)
        sira += 1

    # 30x - Mali Borclar (K.V.)
    # NOT: 302 "Ertelenmis Finansal Kiralama Borclanma Maliyetleri" duzenleyici (aktif
    # karakterli/borc bakiyeli) bir hesaptir; 301'in toplamindan DUSULUR (eksilten/negatif kalem).
    b30_kodlar = ["300", "301", "302", "303", "309"]
    b30_eksilten = {"302"}
    b30_satirlari = []
    b30_isim = {"300": "Banka Kredileri", "301": "Finansal Kiralama İşlemlerinden Borçlar",
                "302": "Ertelenmiş Finansal Kiralama Borçlanma Maliyetleri (-)", "303": "Uzun Vadeli Kredilerin Anapara Taksitleri ve Faizleri",
                "309": "Diğer Mali Borçlar"}
    b30_toplam = 0.0
    for k in b30_kodlar:
        b = abs(hesap_bakiye_tam(rapor, k))
        if b > 0.005:
            isaret = -1 if k in b30_eksilten else 1
            b30_satirlari.append((k, b30_isim[k], b, isaret))
            b30_toplam += isaret * b
    if b30_satirlari:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Mali Borçlar (K.V.):"})
        artiranlar = [f"{tutar(s[2])}'si {s[1]} hesabından" for s in b30_satirlari if s[3] > 0]
        eksiltenler = [f"{tutar(s[2])}'lik {s[1]} hesabı (düzenleyici/eksilten hesap)" for s in b30_satirlari if s[3] < 0]
        metin = (f"Şirketin {donem_sonu} itibarıyla Mali Borçlar hesabının net bakiyesi {tutar(abs(b30_toplam))} "
                 "olup; bu tutarın " + ", ".join(artiranlar) + " oluşmaktadır.")
        if eksiltenler:
            metin += (" Söz konusu net bakiyenin hesabında, " + ", ".join(eksiltenler) +
                      " düşülmüştür. 302 No.lu Ertelenmiş Finansal Kiralama Borçlanma Maliyetleri hesabı, "
                      "finansal kiralama sözleşmesinin başlangıcında 301 hesaba kaydedilen toplam kira "
                      "taahhüdü içindeki gelecek dönem faiz giderlerini gösteren düzenleyici (aktif "
                      "karakterli) bir hesap olduğundan, finansal kiralamadan doğan borçlar bilançoda 301'in "
                      "302 ile netleştirilmiş (azaltılmış) tutarı üzerinden raporlanmıştır.")
        bloklar.append({"tip": "p", "metin": metin})
        sira += 1

    # 32x - Ticari Borclar (K.V.)
    b320 = hesap_bakiye_tam(rapor, "320")
    if abs(b320) > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Ticari Borçlar (K.V.):"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} itibarıyla Ticari Borçlar hesabının bakiyesi {tutar(abs(b320))} olup; "
            "tamamı Satıcılar hesabından oluşmaktadır."
        )})
        sira += 1

    # 33x - Diger Borclar
    b33_isim = {
        "331": "Ortaklara Borçlar",
        "332": "İştiraklere Borçlar",
        "333": "Bağlı Ortaklıklara Borçlar",
        "335": "Personele Borçlar",
        "336": "Diğer Çeşitli Borçlar",
    }
    b33_parcalar = []
    b33_toplam = 0.0
    for k, ad in b33_isim.items():
        b = abs(hesap_bakiye_tam(rapor, k))
        if b > 0.005:
            b33_toplam += b
            b33_parcalar.append(f"{tutar(b)}'i {ad} hesabı")
    if b33_toplam > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Diğer Borçlar (K.V.):"})
        bloklar.append({"tip": "p", "metin": (
            f"{donem_sonu} itibarıyla Diğer Borçlar hesabının bakiyesi {tutar(b33_toplam)} olup; "
            "söz konusu tutarın " + ", ".join(b33_parcalar) + " oluşturmaktadır."
        )})
        sira += 1

    # 340 - Alinan Avanslar
    b340 = abs(hesap_bakiye_tam(rapor, "340"))
    if b340 > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Alınan Avanslar:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} itibarıyla Alınan Avanslar hesabının bakiyesi {tutar(b340)} olup; söz "
            "konusu tutarın tamamı Alınan Sipariş Avansları hesabından oluşmaktadır."
        )})
        sira += 1

    # 36x - Odenecek Vergi ve Diger Yukumlulukler
    b36_kodlar = ["360", "361", "368", "369"]
    b36_isim = {"360": "Ödenecek Vergi ve Fonları", "361": "Ödenecek Sosyal Güvenlik Kesintilerinden",
                "368": "Vadesi Geçmiş Ertelenmiş Vergiler", "369": "Ödenecek Diğer Yükümlülükler"}
    b36_toplam = 0.0
    b36_parcalar = []
    for k in b36_kodlar:
        b = abs(hesap_bakiye_tam(rapor, k))
        if b > 0.005:
            b36_toplam += b
            b36_parcalar.append(f"{tutar(b)}'lik kısmı {b36_isim[k]} hesaplarından")
    if b36_toplam > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Ödenecek Vergi ve Diğer Yükümlülükler:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihi itibari ile Ödenecek Vergi ve Diğer Yükümlülükler tutarı "
            f"{tutar(b36_toplam)} olup " + ", ".join(b36_parcalar) + " oluşmaktadır."
        )})
        sira += 1

    # 38x - Gelecek Aylara Ait Gelirler ve Gider Tahakkuklari
    b380 = abs(hesap_bakiye_tam(rapor, "380"))
    b381 = abs(hesap_bakiye_tam(rapor, "381"))
    if b380 + b381 > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Gelecek Aylara Ait Gelirler ve Gider Tahakkukları:"})
        parcalar = []
        if b380 > 0.005:
            parcalar.append(f"{tutar(b380)}'i Gelecek Aylara Ait Gelirler hesabından")
        if b381 > 0.005:
            parcalar.append(f"{tutar(b381)}'i Gider Tahakkukları hesabından")
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem_sonu} tarihi itibari ile Gelecek Aylara Ait Gelirler ve Gider Tahakkukları "
            f"hesabının bakiyesi {tutar(b380 + b381)} olup; söz konusu tutarın " + ", ".join(parcalar) + " oluşmaktadır."
        )})
        sira += 1

    # 40x - Mali Borclar (U.V.)
    # NOT: 402 "Ertelenmis Finansal Kiralama Borclanma Maliyetleri" duzenleyici (aktif
    # karakterli/borc bakiyeli) bir hesaptir; 401'in toplamindan DUSULUR (eksilten/negatif kalem).
    b40_kodlar = ["400", "401", "402", "409"]
    b40_eksilten = {"402"}
    b40_isim = {"400": "Banka Kredileri", "401": "Finansal Kiralama İşlemlerinden Borçlar",
                "402": "Ertelenmiş Finansal Kiralama Borçlanma Maliyetleri (-)", "409": "Diğer Mali Borçlar"}
    b40_satirlari = []
    b40_toplam = 0.0
    for k in b40_kodlar:
        b = abs(hesap_bakiye_tam(rapor, k))
        if b > 0.005:
            isaret = -1 if k in b40_eksilten else 1
            b40_satirlari.append((k, b40_isim[k], b, isaret))
            b40_toplam += isaret * b
    if b40_satirlari:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Mali Borçlar (U.V.):"})
        artiranlar = [f"{tutar(s[2])}'si {s[1]} hesabından" for s in b40_satirlari if s[3] > 0]
        eksiltenler = [f"{tutar(s[2])}'lik {s[1]} hesabı (düzenleyici/eksilten hesap)" for s in b40_satirlari if s[3] < 0]
        metin = (f"Şirketin {donem_sonu} tarihi itibari ile Mali Borçlar (U.V.) hesabının net bakiyesi "
                 f"{tutar(abs(b40_toplam))} olup; bu tutarın " + ", ".join(artiranlar) + " oluşmaktadır.")
        if eksiltenler:
            metin += (" Söz konusu net bakiyenin hesabında, " + ", ".join(eksiltenler) +
                      " düşülmüştür. 402 No.lu Ertelenmiş Finansal Kiralama Borçlanma Maliyetleri hesabı, "
                      "uzun vadeli finansal kiralama borçları içindeki gelecek dönemlere ait faiz giderlerini "
                      "gösteren düzenleyici (aktif karakterli) bir hesap olduğundan, finansal kiralamadan doğan "
                      "uzun vadeli borçlar bilançoda 401'in 402 ile netleştirilmiş (azaltılmış) tutarı üzerinden "
                      "raporlanmıştır.")
        bloklar.append({"tip": "p", "metin": metin})
        sira += 1

    return bloklar, sira


# ============================================================
# OZKAYNAKLAR (5xx)
# ============================================================

def ozkaynaklar_bloklari(rapor: RaporVerisi, sira_baslangic: int) -> tuple[list, int]:
    bloklar = []
    sira = sira_baslangic
    donem_sonu = rapor.mukellef.donem_sonu

    # 5xx tum hesap toplami - sadece 3 haneli TDHP ana hesaplari
    tum_5xx = sum(
        s.net_bakiye for s in rapor.mizan
        if s.hesap_kodu.strip().startswith("5") and len(s.hesap_kodu.strip()) == 3 and s.hesap_kodu.strip().isdigit()
    )
    # Ozkaynaklarin pozitif (alacak) toplami: ozkaynak hesaplari alacak bakiye
    # verdiginden net_bakiye negatiftir; isaret cevirisi ile pozitif gosterilir.
    ozkaynak_toplam = -tum_5xx

    # Donem net kar/zarari mizanin 5xx grubunda yoksa (590/591 kapanis kaydi
    # yapilmamis, sonuc 690/692'de ya da yalnizca beyannamede), ozkaynaklara
    # elle dahil edilir: kar artirir, zarar azaltir.
    b590_net = hesap_bakiye_tam(rapor, "590")
    b591_net = hesap_bakiye_tam(rapor, "591")
    if abs(b590_net) < 0.005 and abs(b591_net) < 0.005:
        b692_net = hesap_bakiye_tam(rapor, "692")
        b690_net = hesap_bakiye_tam(rapor, "690")
        if abs(b692_net) > 0.005:
            ozkaynak_toplam += -b692_net  # alacak(kar)->+, borc(zarar)->-
        elif abs(b690_net) > 0.005:
            ozkaynak_toplam += -b690_net
        elif rapor.beyanname.ticari_bilanco_zarari > 0.005:
            ozkaynak_toplam -= rapor.beyanname.ticari_bilanco_zarari
        elif rapor.beyanname.ticari_bilanco_kari > 0.005:
            ozkaynak_toplam += rapor.beyanname.ticari_bilanco_kari

    if abs(ozkaynak_toplam) < 0.005 and abs(tum_5xx) < 0.005:
        return bloklar, sira

    # H3 baslik
    bloklar.append({"tip": "h3", "metin": f"{sira}. Özkaynaklar:"})
    bloklar.append({"tip": "p", "metin": (
        f"Şirketin dönem sonu itibari ile Özkaynaklar toplamı {tutar(abs(ozkaynak_toplam))} olarak gerçekleşmiştir."
    )})

    # 500 + 502 + 504 -> Odenmis Sermaye
    b500 = abs(hesap_bakiye_tam(rapor, "500"))
    b501 = abs(hesap_bakiye_tam(rapor, "501"))
    b502 = abs(hesap_bakiye_tam(rapor, "502"))
    b503 = abs(hesap_bakiye_tam(rapor, "503"))
    b504 = abs(hesap_bakiye_tam(rapor, "504"))
    if b500 + b502 > 0.005:
        odenmis_sermaye = b500 - b501 + b502 - b503 - b504
        bloklar.append({"tip": "h4", "metin": f"{sira}.1. Ödenmiş Sermaye:"})
        parcalar = []
        if b500 > 0.005:
            parcalar.append(f"{tutar(b500)}'i Sermaye hesabından")
        if b501 > 0.005:
            parcalar.append(f"({tutar_sade(b501)}-TL)'i Ödenmemiş Sermaye hesabından")
        if b502 > 0.005:
            parcalar.append(f"{tutar(b502)}'i Sermaye Düzeltmesi Olumlu Farkları hesabından")
        if b504 > 0.005:
            parcalar.append(f"({tutar_sade(b504)}-TL)'i hisse geri alım programı kapsamındaki tutardan")
        bloklar.append({"tip": "p", "metin": (
            f"Ödenmiş Sermaye tutarı {tutar(abs(odenmis_sermaye))} olup; söz konusu tutarın " + ", ".join(parcalar) + " oluşmaktadır."
        )})

    # 52x - Sermaye Yedekleri
    b52_toplam = sum(abs(hesap_bakiye_tam(rapor, k)) for k in ["520", "521", "522", "523", "529"])
    b520 = abs(hesap_bakiye_tam(rapor, "520"))
    b522 = abs(hesap_bakiye_tam(rapor, "522"))
    if b52_toplam > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.2. Sermaye Yedekleri:"})
        # Sermaye Yedekleri toplamini olusturan kalemleri tek tek dok (520 Hisse
        # Senedi Ihrac Primleri, 522 MDV Yeniden Degerleme Artislari vb.); eksik
        # kalem birakilmasin diye toplamdan acik kalan kismi "diger" olarak goster.
        parcalar = []
        if b520 > 0.005:
            parcalar.append(f"{tutar(b520)}'lik kısmı Hisse Senedi İhraç Primlerinden (520)")
        if b522 > 0.005:
            parcalar.append(f"{tutar(b522)}'lik kısmı Maddi Duran Varlık Yeniden Değerleme Artışlarından (522)")
        diger52 = b52_toplam - b520 - b522
        if diger52 > 0.005:
            parcalar.append(f"{tutar(diger52)}'lik kısmı diğer sermaye yedeklerinden")
        detay52 = (" ve ".join(parcalar) if len(parcalar) <= 1 else
                   ", ".join(parcalar[:-1]) + " ve " + parcalar[-1])
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin dönem sonu itibariyle Sermaye Yedekleri hesabı {tutar(b52_toplam)} olup; "
            f"bu tutarın {detay52} oluşmaktadır."
        )})
        if b520 > 0.005:
            bloklar.append({"tip": "p", "metin": (
                "520 Hisse Senedi İhraç Primleri hesabı, hisse senetlerinin nominal bedelinin üzerinde "
                "ihraç edilmesinden kaynaklanan emisyon primlerini içermekte olup, dayanak işlemleri "
                "incelenmiştir."
            )})
        if b522 > 0.005:
            bloklar.append({"tip": "p", "metin": (
                f"Sermaye Yedekleri içinde yer alan {tutar(b522)} tutarındaki Maddi Duran Varlık Yeniden "
                "Değerleme Artışları (522), VUK Mükerrer 298 inci maddesinin (Ç) fıkrası kapsamında uygulanan "
                "sürekli yeniden değerleme müessesesinden kaynaklanmaktadır. Anılan hüküm uyarınca; "
                "amortismana tabi iktisadi kıymetler ile bunlara ait birikmiş amortismanlar, enflasyon "
                "düzeltmesi yapılan dönemler hariç olmak üzere her yıl sonu itibarıyla Yİ-ÜFE artış oranı "
                "esas alınarak yeniden değerlemeye tabi tutulmuş; değerleme sonucu maddi duran varlıkların "
                "(25x) ve birikmiş amortismanlarının (257) defter değerleri yükseltilmiş, oluşan net değer "
                "artışı pasifte 522 Maddi Duran Varlık Yeniden Değerleme Artışları hesabında özel bir fon "
                "olarak izlenmiştir. Değer artışı üzerinden ayrılan ilave amortismanlar; yeniden değerlemeye "
                "tabi tutulan maddi ve maddi olmayan duran varlıkların amortisman hesaplamasında dikkate "
                "alınmış, fonun sermayeye ilave dışında herhangi bir şekilde başka bir hesaba "
                "nakledilmediği veya işletmeden çekilmediği tespit edilmiştir."
            )})
            yd_satirlar = list(getattr(rapor, "yeniden_degerleme_satirlari", []) or [])
            if yd_satirlar:
                bloklar.append({"tip": "p", "metin": (
                    f"522 hesabında izlenen {tutar(b522)} tutarındaki net yeniden değerleme fonunun hesap "
                    "bazında dökümü; maddi duran varlıklar için raporun \"Maddi Duran Varlıklar\", maddi "
                    "olmayan duran varlıklar için \"Maddi Olmayan Duran Varlıklar\" bölümlerinde yer alan "
                    "yeniden değerleme özet tablolarında gösterilmiştir."
                )})
            else:
                bloklar.append({"tip": "p", "metin": (
                    "Maddi duran varlık (25x) ve maddi olmayan duran varlık (26x) hesapları bazında yeniden "
                    "değerleme tutarlarının (aktif değerleme tutarı, birikmiş amortisman artışı ve net değerleme "
                    "artışı) dökümünü gösteren ayrıntılı yeniden değerleme tablosunun şirketten temin edilerek "
                    "rapor ekine alınması; yapılacak inceleme sonrası hesap bazında özet tablonun ilgili duran "
                    "varlık bölümlerine eklenmesi gerekmektedir."
                )})

    # 540 - Yasal Yedekler
    b540 = abs(hesap_bakiye_tam(rapor, "540"))
    if b540 > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.3. Yasal Yedekler:"})
        bloklar.append({"tip": "p", "metin": (
            f"Dönem sonu itibariyle Yasal Yedekler tutarı {tutar(b540)}'dir. 540 Yasal Yedekler Hesabı, Türk "
            "Ticaret Kanunu hükümleri uyarınca ayrılan birinci ve ikinci tertip yasal yedeklerden oluşmakta "
            "olup, ayrılma oranları ve dayanakları incelenmiştir."
        )})

    # 541 - Statu Yedekler
    b541 = abs(hesap_bakiye_tam(rapor, "541"))
    if b541 > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.4. Statü Yedekleri:"})
        bloklar.append({"tip": "p", "metin": (
            f"Dönem sonu itibariyle Statü Yedekler tutarı {tutar(b541)}'dir. 541 Statü Yedekleri Hesabı, "
            "şirket esas sözleşmesine dayanarak ayrılan yedeklerden oluşmakta olup, ayrılma esasları "
            "incelenmiştir."
        )})

    # 542 - Olaganustu Yedekler
    b542 = abs(hesap_bakiye_tam(rapor, "542"))
    if b542 > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.5. Olağanüstü Yedekler:"})
        bloklar.append({"tip": "p", "metin": (
            f"Dönem sonu itibariyle Olağanüstü Yedekler tutarı {tutar(b542)}'dir. 542 Olağanüstü Yedekler "
            "hesabı, genel kurul kararı ile dağıtılmayarak işletmede bırakılan kârlardan oluşmakta olup, "
            "dayanak kararları incelenmiştir."
        )})

    # 549 - Ozel Fonlar
    b549 = abs(hesap_bakiye_tam(rapor, "549"))
    if b549 > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.6. Özel Fonlar:"})
        bloklar.append({"tip": "p", "metin": (
            f"Dönem sonu itibariyle Özel Fonlar (549) tutarı {tutar(b549)} olup; söz konusu tutar "
            "şirketin değişik kanun ve düzenlemeler uyarınca oluşturduğu özel fonlardan oluşmaktadır. "
            "Fonu oluşturan her bir kalemin kaynağına ve tabi olduğu vergi mevzuatına bağlı olarak alt "
            "hesaplarda izlendiği görülmüştür."
        )})
        ozel_fon_dokum = _alt_hesap_dokumu(rapor, "549")
        if ozel_fon_dokum:
            of_top = sum(t for _, _, t in ozel_fon_dokum)
            bloklar.append({
                "tip": "tablo",
                "basliklar": ["Hesap Kodu", "Hesap Adı", "Tutar (TL)"],
                "satirlar": [(k, ad, tutar_sade(t)) for k, ad, t in ozel_fon_dokum],
                "toplam": ("Toplam", "", tutar_sade(of_top)),
            })
        bloklar.append({"tip": "p", "metin": (
            "Özel Fonlar hesabı içinde, 5746 sayılı Araştırma, Geliştirme ve Tasarım Faaliyetlerinin "
            "Desteklenmesi Hakkında Kanun'un 3 üncü maddesinin ondördüncü fıkrası uyarınca; yıllık "
            "beyanname üzerinden yararlanılan Ar-Ge ve tasarım indirimi tutarının mevzuatta belirlenen "
            "haddi aşması halinde, bu tutarın %3'ünün (yıllık azami 100.000.000 TL ile sınırlı olmak "
            "üzere) pasifte geçici bir hesaba aktarılarak, yükümlülük yılını izleyen hesap dönemi sonuna "
            "kadar girişim sermayesi yatırım fonu (GSYF) paylarının satın alınması ya da girişim "
            "sermayesi yatırım ortaklıkları/girişimci şirketlere sermaye olarak konulması suretiyle "
            "kullanılması zorunluluğundan kaynaklanan fonların izlenip izlenmediği değerlendirilmiştir. "
            "Ar-Ge indirimi kaynaklı bu fonun, amacına uygun olarak GSYF paylarının alımında kullanıldığı/ "
            "süresinde kullanılacağı; süresinde girişim sermayesi olarak kullanılmaması halinde "
            "indirim konusu edilen tutarın aranacağı hususunun şirket tarafından takip edildiği "
            "incelenmiştir."
        )})
        bloklar.append({"tip": "p", "metin": (
            "Ayrıca Özel Fonlar hesabında, 196 Sıra No.lu Vergi Usul Kanunu Sirküleri kapsamında "
            "aktifleştirilen tutarlardan kaynaklanan fonların da izlendiği; aktifleştirmeye konu "
            "tutarların dayanak belgeleri ile uyumlu olduğu ve anılan Sirküler çerçevesinde "
            "değerlendirildiği tespit edilmiştir."
        )})

    # 580 - Gecmis Yillar Zararlari
    b580 = abs(hesap_bakiye_tam(rapor, "580"))
    if b580 > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.7. Geçmiş Yıllar Zararları:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin geçmiş yıllara ait zararı {tutar(b580)}'dir. 580 Geçmiş Yıllar Zararları Hesabı'nda "
            "izlenen tutarların önceki dönem beyannameleri ile uyumlu olduğu ve Kurumlar Vergisi Kanunu'nun "
            "9'uncu maddesi kapsamında mahsuba konu edilebilecek zararları içerdiği incelenmiştir."
        )})

    # 590 / 591 - Donem Net Kari / Zarari
    b590 = hesap_bakiye_tam(rapor, "590")
    b591 = hesap_bakiye_tam(rapor, "591")
    yil = rapor.mukellef.donem_baslangic[6:]
    if abs(b590) > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.8. Dönem Net Kârı:"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {yil} hesap dönemine ait Dönem Net Kârı {tutar(abs(b590))}'dir."
        )})
    elif abs(b591) > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.8. Dönem Net Zararı (-):"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {yil} hesap dönemine ait Dönem Net Zararı ({tutar_sade(abs(b591))}-TL)'dir."
        )})
    elif rapor.beyanname.ticari_bilanco_zarari > 0.005:
        bloklar.append({"tip": "h4", "metin": f"{sira}.8. Dönem Net Zararı (-):"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {yil} hesap dönemine ait Dönem Net Zararı "
            f"({tutar_sade(rapor.beyanname.ticari_bilanco_zarari)}-TL)'dir."
        )})

    sira += 1
    return bloklar, sira


# ============================================================
# B. GELIR TABLOSU HESAPLARI
# ============================================================

def gelir_tablosu_bloklari(rapor: RaporVerisi) -> list:
    bloklar = []
    donem = rapor.mukellef.donem

    bloklar.append({"tip": "h2", "metin": "B. GELİR TABLOSU HESAPLARI"})
    bloklar.append({"tip": "p", "metin": (
        f"Şirketin, raporumuza eklenmiş bulunan {donem} hesap dönemi gelir tablosunda yer alan satışlar, "
        "maliyetler, pazarlama satış ve dağıtım giderleri, genel yönetim giderleri ile diğer gelir-gider "
        "hesapları ve dönem kârının kanuni defter kayıtları ile mutabık ve muhasebe sistemi uygulama genel "
        "tebliğlerine uygun olduğu ve gerçeği yansıttığı görülmüştür."
    )})
    bloklar.append({"tip": "p", "metin": (
        "Gelir tablosu kalemlerindeki vergi mevzuatını ilgilendiren başlıca hususlar ve bunlar hakkındaki "
        "tespit ve kanaatlerimiz özetle şöyledir;"
    )})

    sira = 1
    # 1. Alis ve Satislar
    yi_satis = abs(hesap_bakiye_tam(rapor, "600"))
    yd_satis = abs(hesap_bakiye_tam(rapor, "601"))
    dig_gelir = abs(hesap_bakiye_tam(rapor, "602"))
    brut_satis = yi_satis + yd_satis + dig_gelir
    if brut_satis > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Alış ve Satışlar:"})
        bloklar.append({"tip": "p", "metin": (
            "Örnekleme suretiyle yapılan incelemelerde, şirketin muhtelif mal ve hizmet alış ve "
            "satışlarına ilişkin faturalarında gerçek dışı bir alış veya satış emaresine rastlanmamıştır."
        )})
        bloklar.append({"tip": "p", "metin": (
            "Şirketin mal ve hizmet alım ve satım miktarlarıyla bu firmalarla olan borç ve alacak "
            "ilişkilerinin uyumlu olduğu, borç ve alacak ödeme ve tahsilatının çoğunlukla bankalardan "
            "havale suretiyle yapıldığı, nakit tediye ve tahsilatının makul seviyede olduğu görülmüştür."
        )})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin, {donem} hesap döneminde Brüt Satışlar toplamı {tutar(brut_satis)}'dir. Bu tutarın "
            f"{tutar(yi_satis)}'lik kısmı Yurtiçi Satışlara, {tutar(yd_satis)}'lik kısmı Yurtdışı "
            f"Satışlara ve {tutar(dig_gelir)}'lik kısmı ise Diğer Gelirlere ilişkindir."
        )})
        sira += 1

    # 2. Satis Indirimleri
    b610 = abs(hesap_bakiye_tam(rapor, "610"))
    b611 = abs(hesap_bakiye_tam(rapor, "611"))
    b612 = abs(hesap_bakiye_tam(rapor, "612"))
    si_top = b610 + b611 + b612
    if si_top > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Satış İndirimleri (-):"})
        parcalar = []
        if b610 > 0.005:
            parcalar.append(f"({tutar_sade(b610)}-TL)'lik kısmı Satıştan İadeler hesabından")
        if b611 > 0.005:
            parcalar.append(f"({tutar_sade(b611)}-TL)'lik kısmı Satış İskontoları hesabından")
        if b612 > 0.005:
            parcalar.append(f"({tutar_sade(b612)}-TL)'lik kısmı Diğer İndirimler hesabından")
        bloklar.append({"tip": "p", "metin": (
            f"{donem} hesap dönemine ilişkin Gelir Tablosunda Satış İndirimleri hesabının bakiyesi "
            f"({tutar_sade(si_top)}) olup; söz konusu tutarın " + " ve ".join(parcalar) + " oluşmaktadır."
        )})
        sira += 1

    # 3. Satislarin Maliyeti
    b620 = abs(hesap_bakiye_tam(rapor, "620"))
    b621 = abs(hesap_bakiye_tam(rapor, "621"))
    b622 = abs(hesap_bakiye_tam(rapor, "622"))
    b623 = abs(hesap_bakiye_tam(rapor, "623"))
    smt = b620 + b621 + b622 + b623
    if smt > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Satışların Maliyeti(-):"})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {donem} hesap dönemine ilişkin Gelir Tablosunda yer alan toplam Satışların Maliyeti "
            f"({tutar_sade(smt)}-TL)'dir."
        )})
        satirlar = []
        if b620 > 0.005:
            satirlar.append(("Satılan Mamuller Maliyeti", f"({tutar_sade(b620)})"))
        if b621 > 0.005:
            satirlar.append(("Satılan Ticari Mallar Maliyeti", f"({tutar_sade(b621)})"))
        if b622 > 0.005:
            satirlar.append(("Satılan Hizmet Maliyeti", f"({tutar_sade(b622)})"))
        if b623 > 0.005:
            satirlar.append(("Diğer Satışların Maliyeti", f"({tutar_sade(b623)})"))
        bloklar.append({
            "tip": "tablo",
            "basliklar": ["Satışların Maliyeti", "Tutar (TL)"],
            "satirlar": satirlar,
            "toplam": ("TOPLAM", f"({tutar_sade(smt)})"),
        })
        sira += 1

    # 4. Faaliyet Giderleri
    b630 = abs(hesap_bakiye_tam(rapor, "630"))
    b631 = abs(hesap_bakiye_tam(rapor, "631"))
    b632 = abs(hesap_bakiye_tam(rapor, "632"))
    fg = b630 + b631 + b632
    if fg > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Faaliyet Giderleri (-):"})
        bloklar.append({"tip": "p", "metin": (
            f"{rapor.mukellef.donem_sonu} tarihli gelir tablosunda Faaliyet Giderlerinin toplamı "
            f"({tutar_sade(fg)}-TL) olarak yer almaktadır. Bu tutarın ({tutar_sade(b630)}-TL)'i "
            f"Araştırma ve Geliştirme Giderleri, ({tutar_sade(b631)}-TL)'i Pazarlama Satış ve Dağıtım "
            f"Giderleri ve ({tutar_sade(b632)}-TL)'i Genel Yönetim Giderleri hesaplarından oluşmaktadır."
        )})
        if b630 > 0.005:
            bloklar.append({"tip": "p", "metin": (
                f"Tasdik dönemi içerisinde şirketin ({tutar_sade(b630)}-TL)'lik Araştırma ve Geliştirme "
                "Giderleri personel ücret ve giderleri, işçi tazminat giderleri, dışardan alınan hizmet "
                "giderleri, danışmanlık giderleri, amortisman giderleri ve eğitim/kurs/seminer/konferans "
                "katılım giderlerinden oluşmaktadır."
            )})
        if b631 > 0.005:
            bloklar.append({"tip": "p", "metin": (
                f"({tutar_sade(b631)}-TL) olarak gerçekleşen Pazarlama Satış ve Dağıtım Giderleri; "
                "personel ücret ve giderleri, işçi tazminat giderleri, seyahat ve ulaşım giderleri, "
                "pazarlama giderleri (reklam, tanıtım, ilan), nakliye, ihracat, satış ve sevk giderleri "
                "ve diğer giderlerden oluşmaktadır."
            )})
        if b632 > 0.005:
            bloklar.append({"tip": "p", "metin": (
                f"Tasdik dönemi içerisinde şirketin Genel Yönetim Giderleri ({tutar_sade(b632)}-TL) "
                "olarak gerçekleşmiştir. Genel Yönetim Giderleri; personel ücret ve giderleri, işçi "
                "tazminat giderleri, elektrik ısınma giderleri, vergi giderleri (resim, harç), temsil "
                "ağırlama giderleri, amortisman giderleri, ulaşım ve haberleşme giderleri, araç giderleri "
                "ve diğer giderlerden oluşmaktadır."
            )})
        sira += 1

    # 5. Diger Olagan Gelir / Giderler
    b64 = sum(abs(hesap_bakiye_tam(rapor, k)) for k in ["640", "641", "642", "643", "644", "645", "646", "647", "648", "649"])
    b65 = sum(abs(hesap_bakiye_tam(rapor, k)) for k in ["650", "651", "652", "653", "654", "655", "656", "657", "658", "659"])
    if b64 + b65 > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Diğer Faaliyetlerden Olağan Gelir ve Gider Kalemleri:"})
        if b64 > 0.005:
            bloklar.append({"tip": "p", "metin": (
                f"Gelir Tablosunda {tutar(b64)} olarak yer alan Diğer Faaliyetlerden Olağan Gelir ve "
                "Kârlar hesabının, şirket muavin kayıtlarından (mizan) hareketle hesap bazında dökümü "
                "aşağıdaki gibi olup; tutarı yüksek kalemler dâhil tüm alt hesaplar gösterilmiştir;"
            )})
            d64 = _grup_dokum(rapor, ["640", "641", "642", "643", "644", "645",
                                      "646", "647", "648", "649"])
            if d64:
                bloklar.append({
                    "tip": "tablo",
                    "basliklar": ["Hesap Kodu", "Hesap Adı", "Tutar (TL)"],
                    "satirlar": [(k, ad, tutar_sade(t)) for k, ad, t in d64],
                    "toplam": ("Toplam", "", tutar_sade(sum(t for _, _, t in d64))),
                })
            b642 = abs(hesap_bakiye_tam(rapor, "642"))
            b644 = abs(hesap_bakiye_tam(rapor, "644"))
            b645 = abs(hesap_bakiye_tam(rapor, "645"))
            b646 = abs(hesap_bakiye_tam(rapor, "646"))
            if b642 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Faiz Gelirleri toplamı {tutar(b642)} olup; bankalarda bulunan vadeli mevduat "
                    "hesaplarından elde edilen faiz gelirleri oluşmaktadır."
                )})
            if b644 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin Konusu Kalmayan Karşılıklar toplamı {tutar(b644)} olup; ilgili tutar "
                    "geçmiş dönemde icra safhasına gelen ve karşılık gideri ayrılan tutarların tahsil "
                    "edilmiş tutarlarından oluşmaktadır."
                )})
            if b645 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin Menkul Kıymet Satış Kârları toplamı {tutar(b645)} olup; bankada yer alan "
                    "fon hesaplarına ilişkin gelirden oluşmaktadır."
                )})
            if b646 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin döviz cinsinden işlemleri ile döviz cinsinden mevcutlarının değerlenmesi "
                    f"sonucunda ortaya çıkan Kambiyo Kârları toplamı {tutar(b646)}'dir."
                )})
            b649 = abs(hesap_bakiye_tam(rapor, "649"))
            if b649 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin Diğer Olağan Gelir ve Kârlar hesabının bakiyesi {tutar(b649)} olup; "
                    "yukarıda sayılanlar dışında kalan çeşitli olağan gelir ve kârlardan oluşmaktadır."
                )})
        if b65 > 0.005:
            bloklar.append({"tip": "p", "metin": (
                f"Gelir Tablosunda ({tutar_sade(b65)}-TL) olarak yer alan Diğer Faaliyetlerden Olağan "
                "Gider ve Zararlar hesabının, şirket muavin kayıtlarından (mizan) hareketle hesap bazında "
                "dökümü aşağıdaki gibi olup; tutarı yüksek kalemler dâhil tüm alt hesaplar gösterilmiştir;"
            )})
            d65 = _grup_dokum(rapor, ["650", "651", "652", "653", "654", "655",
                                      "656", "657", "658", "659"])
            if d65:
                bloklar.append({
                    "tip": "tablo",
                    "basliklar": ["Hesap Kodu", "Hesap Adı", "Tutar (TL)"],
                    "satirlar": [(k, ad, tutar_sade(t)) for k, ad, t in d65],
                    "toplam": ("Toplam", "", tutar_sade(sum(t for _, _, t in d65))),
                })
            b654 = abs(hesap_bakiye_tam(rapor, "654"))
            b655 = abs(hesap_bakiye_tam(rapor, "655"))
            b656 = abs(hesap_bakiye_tam(rapor, "656"))
            if b654 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin faturaya bağlı ticari alacaklarının şüpheli hale gelmiş dava ve icra "
                    f"safhasına düşmüş alacakları için ayırmış olduğu karşılık gideri {tutar(b654)}'dir."
                )})
            if b655 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin Menkul Kıymet Satış Zararları toplamı {tutar(b655)} olup; bankada yer "
                    "alan fon hesaplarının fona iadesi ve dönem sonu değerlemesinden kaynaklı oluşan "
                    "zararlardan oluşmaktadır."
                )})
            if b656 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin döviz cinsinden işlemleri ile döviz cinsinden mevcutlarının değerlenmesi "
                    f"sonucunda ortaya çıkan Kambiyo Zararları toplamı ({tutar_sade(b656)}-TL)'dir."
                )})
            b659 = abs(hesap_bakiye_tam(rapor, "659"))
            if b659 > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin Diğer Olağan Gider ve Zararlar hesabının bakiyesi ({tutar_sade(b659)}-TL) "
                    "olup; yukarıda sayılanlar dışında kalan çeşitli olağan gider ve zararlardan oluşmaktadır."
                )})
        sira += 1

    # 6. Finansman Giderleri (FGK ile birlikte)
    b660 = abs(hesap_bakiye_tam(rapor, "660"))
    b661 = abs(hesap_bakiye_tam(rapor, "661"))
    fg_top = b660 + b661
    if fg_top > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Finansman Giderleri(-):"})
        bloklar.append({"tip": "p", "metin": (
            f"{rapor.mukellef.donem_sonu} itibarıyla şirketin Finansman Giderleri toplamı "
            f"({tutar_sade(fg_top)}-TL) olarak gerçekleşmiştir. Şirketin finansman giderleri bankalara "
            "ödenen yatırım kredisine ait faiz giderleri ile banka komisyon giderleri ve vade farkı "
            "giderlerinden oluşmaktadır."
        )})
        # Not: Finansman Gider Kisitlamasi (KVK 11/1-i) hesaplamasi ve tablosu
        # "C. DIGER INCELEMELER" bolumu altinda "3.1. Finansman Gider Kisitlamasi"
        # basligi ile ornek tam tasdik raporundaki sirayla raporlanmaktadir.
        sira += 1

    # 7. Olagandisi Gelir / Karlar
    b67 = sum(abs(hesap_bakiye_tam(rapor, k)) for k in ["671", "672", "673", "674", "675", "676", "677", "678", "679"])
    b671 = abs(hesap_bakiye_tam(rapor, "671"))
    b679 = abs(hesap_bakiye_tam(rapor, "679"))
    if b67 > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Olağandışı Gelir ve Kârlar Hesabı:"})
        parcalar = []
        if b671 > 0.005:
            parcalar.append(f"{tutar(b671)}'lik kısmı Önceki Dönem Gelir ve Karları hesabından")
        if b679 > 0.005:
            parcalar.append(f"{tutar(b679)}'lik kısmı ise Diğer Olağandışı Gelir ve Kârlar hesabından")
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin Gelir Tablosunda Olağandışı Gelir ve Kârlar hesabının bakiyesi {tutar(b67)} olup"
            + (" ; " + ", ".join(parcalar) + " oluşmaktadır." if parcalar else ".")
        )})
        d67 = _grup_dokum(rapor, ["671", "672", "673", "674", "675", "676", "677", "678", "679"])
        if d67:
            bloklar.append({"tip": "p", "metin": (
                "Olağandışı Gelir ve Kârlar hesabının, şirket muavin kayıtlarından (mizan) hareketle "
                "hesap bazında dökümü aşağıdaki gibi olup; tutarı yüksek kalemler dâhil tüm alt hesaplar "
                "gösterilmiştir;"
            )})
            bloklar.append({
                "tip": "tablo",
                "basliklar": ["Hesap Kodu", "Hesap Adı", "Tutar (TL)"],
                "satirlar": [(k, ad, tutar_sade(t)) for k, ad, t in d67],
                "toplam": ("Toplam", "", tutar_sade(sum(t for _, _, t in d67))),
            })
        sira += 1

    # 8. Olagandisi Gider / Zararlar
    b68 = sum(abs(hesap_bakiye_tam(rapor, k)) for k in ["680", "681", "682", "683", "684", "685", "686", "687", "688", "689"])
    b680 = abs(hesap_bakiye_tam(rapor, "680"))
    b681 = abs(hesap_bakiye_tam(rapor, "681"))
    b689 = abs(hesap_bakiye_tam(rapor, "689"))
    if b68 > 0.005:
        bloklar.append({"tip": "h3", "metin": f"{sira}. Olağandışı Gider ve Zararlar Hesabı (-):"})
        parcalar = []
        if b680 > 0.005:
            parcalar.append(f"({tutar_sade(b680)}-TL)'lik kısmı Çalışmayan Kısım Gider ve Zararları hesabından")
        if b681 > 0.005:
            parcalar.append(f"({tutar_sade(b681)}-TL)'lik kısmı Önceki Dönem Gider ve Zararları hesabından")
        if b689 > 0.005:
            parcalar.append(f"({tutar_sade(b689)}-TL)'lik kısmı ise Diğer Olağandışı Gider ve Zararlar hesabından")
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin Gelir Tablosunda Olağandışı Gider ve Zararlar hesabının bakiyesi "
            f"({tutar_sade(b68)}-TL) olup"
            + ("; " + ", ".join(parcalar) + " oluşmaktadır." if parcalar else ".")
        )})
        sira += 1

    # 9-10-11 - Donem Kari/Zarari ve Vergiler
    yil = rapor.mukellef.donem_baslangic[6:]
    b690_net = hesap_bakiye_tam(rapor, "690")   # 690 alacak(kar)->net negatif, borc(zarar)->net pozitif
    b691 = abs(hesap_bakiye_tam(rapor, "691"))

    # Vergi oncesi donem sonucu (+ kar / - zarar)
    if rapor.beyanname.ticari_bilanco_kari > 0.005:
        sonuc = rapor.beyanname.ticari_bilanco_kari
    elif rapor.beyanname.ticari_bilanco_zarari > 0.005:
        sonuc = -rapor.beyanname.ticari_bilanco_zarari
    else:
        sonuc = -b690_net

    if abs(sonuc) > 0.005:
        kar_mi = sonuc > 0
        bloklar.append({"tip": "h3", "metin": f"{sira}. Dönem Karı veya Zararı"})
        if kar_mi:
            bloklar.append({"tip": "p", "metin": (
                f"Şirketin {yil} hesap dönemi sonunda vergi karşılığı öncesi dönem karı "
                f"{tutar(sonuc)}'dir."
            )})
        else:
            bloklar.append({"tip": "p", "metin": (
                f"Şirketin {yil} hesap dönemi sonunda vergi karşılığı öncesi dönem zararı "
                f"({tutar_sade(abs(sonuc))}-TL)'dir."
            )})
        sira += 1

        if rapor.beyanname.hesaplanan_vergi > 0.005 or b691 > 0.005:
            bloklar.append({"tip": "h3", "metin": f"{sira}. Dönem Karı, Vergi ve Diğer Yasal Yükümlülük Karşılığı"})
            v = rapor.beyanname.hesaplanan_vergi if rapor.beyanname.hesaplanan_vergi > 0.005 else b691
            bloklar.append({"tip": "p", "metin": (
                f"Şirketin {yil} hesap dönem kârı üzerinden, ilgili mevzuat hükümlerine göre hesaplanan "
                f"vergi ve yasal yükümlülüklerin tutarı {tutar(v)}'dir."
            )})
            sira += 1

        # Vergi sonrasi net sonuc (+ kar / - zarar)
        b692_net = hesap_bakiye_tam(rapor, "692")
        b590_net = hesap_bakiye_tam(rapor, "590")
        b591_net = hesap_bakiye_tam(rapor, "591")
        if abs(b590_net) > 0.005:
            net_sonuc = -b590_net
        elif abs(b591_net) > 0.005:
            net_sonuc = -b591_net
        elif abs(b692_net) > 0.005:
            net_sonuc = -b692_net
        else:
            net_sonuc = sonuc - (rapor.beyanname.hesaplanan_vergi if kar_mi else 0.0)
        if abs(net_sonuc) > 0.005:
            bloklar.append({"tip": "h3", "metin": f"{sira}. Dönem Net Karı veya Zararı"})
            if net_sonuc > 0:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin {yil} hesap dönemi sonunda vergi karşılığı sonrası dönem net karı "
                    f"{tutar(net_sonuc)}'dir."
                )})
            else:
                bloklar.append({"tip": "p", "metin": (
                    f"Şirketin {yil} hesap dönemi sonunda vergi karşılığı sonrası dönem net zararı "
                    f"({tutar_sade(abs(net_sonuc))}-TL)'dir."
                )})

    return bloklar


# ============================================================
# C. DIGER INCELEMELER
# ============================================================

def _istisna_tutar_bul(satirlar: list, anahtarlar: list[str]) -> float:
    """Beyanname istisna satirlarinda anahtar kelime eslesen tutarlari toplar.

    `satirlar` -> list[tuple[str, float]] (etiket, tutar).
    Bir etiket anahtarlardan herhangi birini iceriyorsa tutari toplanir.
    """
    top = 0.0
    for ogeler in satirlar or []:
        try:
            label, amt = ogeler[0], ogeler[1]
        except (TypeError, IndexError):
            continue
        ll = str(label).lower()
        if any(a in ll for a in anahtarlar):
            top += amt
    return top


def diger_incelemeler_bloklari(rapor: RaporVerisi) -> list:
    """C. DIGER INCELEMELER bolumu - ornek tam tasdik raporundaki sirayla.

    1. Yil Icinde Gecici Vergiler (yalnizca KGV yuklendiyse)
    2. Kesinti Yoluyla Pesin Odenen Vergiler (+ KVK beyanname eki liste)
    3. Kanunen Kabul Edilmeyen Giderler (+ KVK beyanname KKEG tablosu)
       3.1. Finansman Gider Kisitlamasi (KVK 11/1-i)
    4. Kur Korumali Mevduat Kazanclari Istisnasi (KVK Gecici 14)
    5. Diger Fon Kazanclari Istisnasi (KVK 5/1-a 3 ve 4)
    6. Transfer Fiyatlandirmasi Yoluyla Ortulu Kazanc Dagitimi
    7. Nakdi Sermaye Artisindan Kaynaklanan Faiz Indirimi (KVK 10/1-i)
    """
    bv = rapor.beyanname
    d_bas = rapor.mukellef.donem_baslangic or ""
    d_son = rapor.mukellef.donem_sonu or ""
    yil = (d_bas[6:] if len(d_bas) >= 10 else "") or str(rapor.mukellef.donem)
    donem_aralik = f"{d_bas}–{d_son}" if d_bas and d_son else str(rapor.mukellef.donem)

    bloklar = []
    bloklar.append({"tip": "h2", "metin": "C. DİĞER İNCELEMELER"})

    n = 0

    # ---- 1. Yil Icinde Gecici Vergiler ----
    gv_bloklari = _gecici_vergi_section(rapor)
    if gv_bloklari:
        n += 1
        bloklar.append({"tip": "h3", "metin": f"{n}. Yıl İçinde Geçici Vergilerin Hesaplanmasına İlişkin İncelemeler:"})
        bloklar.extend(gv_bloklari)

    # ---- 2. Kesinti Yoluyla Pesin Odenen Vergiler ----
    n += 1
    bloklar.append({"tip": "h3", "metin": f"{n}. Kesinti Yoluyla Peşin Ödenen Vergilere İlişkin İncelemeler:"})
    bloklar.append({"tip": "p", "metin": (
        f"Şirketin {donem_aralik} hesap dönemine ilişkin bankalardaki vadeli mevduat hesaplarından "
        "elde ettiği faiz gelirleri ve üzerinden tevkif edilen gelir vergisi stopajı tutarına ait "
        "tablo aşağıda gösterilmiştir. Bahse konu banka faiz ve kesinti yazıları rapor ekinde sunulmuştur."
    )})
    if bv.kesinti_listesi:
        satirlar = []
        t_brut = t_vergi = 0.0
        for k in bv.kesinti_listesi:
            brut = k.get("brut", 0.0) or 0.0
            vergi = k.get("vergi", 0.0) or 0.0
            t_brut += brut
            t_vergi += vergi
            satirlar.append((
                k.get("unvan", ""), k.get("vkn", ""), k.get("donem", ""),
                tutar_sade(brut), tutar_sade(vergi),
            ))
        bloklar.append({
            "tip": "tablo",
            "basliklar": ["Unvan", "Vergi Kimlik Numarası", "Kesilen Vergi Dönemi",
                          "Ödemenin Brüt Tutarı (TL)", "Vergi Tutarı (TL)"],
            "satirlar": satirlar,
            "toplam": ("Toplam", "", "", tutar_sade(t_brut), tutar_sade(t_vergi)),
        })
    if bv.yil_ici_kesinti > 0.005:
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin yıl içinde kesinti yoluyla ödenen vergileri toplam tutarı "
            f"{tutar(bv.yil_ici_kesinti)}'dir."
        )})

    # ---- 3. Kanunen Kabul Edilmeyen Giderler ----
    if bv.kkeg_satirlari or bv.kkeg_toplam > 0.005:
        n += 1
        bloklar.append({"tip": "h3", "metin": f"{n}. Kanunen Kabul Edilmeyen Giderler:"})
        bloklar.append({"tip": "p", "metin": (
            "213 sayılı Vergi Usul Kanunu ve 193 sayılı Gelir Vergisi Kanunu'nun 41'inci maddesinde "
            "“Gider Kabul Edilmeyen Ödemeler” başlığı altında açıklanmıştır. Ayrıca, kurumlar vergisi "
            "mükellefleri için yasal düzenlemelere ilaveten 5520 sayılı Kurumlar Vergisi Kanunu'nda "
            "“Diğer İndirimler” ve “Kabul Edilmeyen İndirimler” başlığı altında ilaveler yapılmıştır."
        )})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {yil} hesap dönemine ait kanunen kabul edilmeyen giderleri aşağıdaki tabloda "
            "gösterilmiştir."
        )})
        if bv.kkeg_satirlari:
            satirlar = [(lbl, tutar_sade(amt)) for lbl, amt in bv.kkeg_satirlari]
            toplam_kkeg = bv.kkeg_toplam if bv.kkeg_toplam > 0.005 else sum(a for _, a in bv.kkeg_satirlari)
            bloklar.append({
                "tip": "tablo",
                "basliklar": ["Giderin Türü", "Tutar (TL)"],
                "satirlar": satirlar,
                "toplam": ("TOPLAM", tutar_sade(toplam_kkeg)),
            })

        # ---- 3.1. Finansman Gider Kisitlamasi ----
        fgk = _fgk_hesapla(rapor)
        if fgk and fgk.get("kisitlama_var"):
            bloklar.append({"tip": "h3", "metin": f"{n}.1. Finansman Gider Kısıtlaması:"})
            bloklar.append({"tip": "p", "metin": (
                "6322 sayılı Kanunla kanunen kabul edilmeyen giderlerin düzenlendiği Gelir Vergisi "
                "Kanunu'nun 41/9. maddesi ile Kurumlar Vergisi Kanunu'nun 11/1-(i) maddesine eklenen "
                "finansman gider kısıtlaması, finansman gider kısıtlama oranının Cumhurbaşkanı tarafından "
                "bugüne kadar belirlenmemesi nedeniyle uygulama alanı bulmamıştı. Ancak söz konusu oran "
                "04.02.2022 tarih ve 31385 sayılı Resmi Gazete'de yayınlanan 4936 sayılı Cumhurbaşkanı "
                "Kararı ile, 1.1.2022 tarihinden itibaren başlayan vergilendirme dönemi kazançlarına "
                "uygulanmak üzere %10 olarak belirlenmiştir."
            )})
            bloklar.append({"tip": "p", "metin": (
                "Kurumlar Vergisi Kanunu'nun 11. maddesinin birinci fıkrasının (i) bendi hükümlerine "
                "göre, kredi kuruluşları, finansal kuruluşlar, finansal kiralama, faktoring ve finansman "
                "şirketleri dışında, kullanılan yabancı kaynakları öz kaynaklarını aşan işletmelerde, aşan "
                "kısma münhasır olmak üzere, yatırımın maliyetine eklenenler hariç, işletmede kullanılan "
                "yabancı kaynaklara ilişkin faiz, komisyon, vade farkı, kâr payı, kur farkı ve benzeri "
                "adlar altında yapılan gider ve maliyet unsurları toplamının %10'unun kurum kazancının "
                "tespitinde indirimi kabul edilmeyecektir."
            )})
            bloklar.append({"tip": "p", "metin": (
                "1 Seri No.lu Kurumlar Vergisi Genel Tebliği'nde yapılan açıklamalar uyarınca, finansman "
                "gider kısıtlaması hesabında dikkate alınacak yabancı kaynak ve öz kaynak tutarlarının "
                "tespitinde; dönem kârı vergi ve diğer yasal yükümlülük karşılıkları (370-371 No.lu hesaplar) "
                "gibi gerçek bir finansman yükü doğurmayan karşılık niteliğindeki kalemler dikkate alınmamış; "
                "finansman gideri olarak da yalnızca işletmede kullanılan yabancı kaynaklara ilişkin vadeye "
                "bağlı faiz, komisyon, vade farkı ve kur farkı gibi gider ve maliyet unsurları (660-661 No.lu "
                "hesaplar) esas alınmıştır."
            )})
            bloklar.append({"tip": "p", "metin": (
                f"Yukarıdaki açıklama ve kanun hükümlerince Şirketin {d_son or rapor.mukellef.donem_sonu} "
                "tarihli bilanço hesaplarının tetkikinden finansman gider kısıtlaması kapsamında hesaplama "
                "tablosu aşağıdaki gibidir."
            )})
            oran_tr = f"{fgk['kisitlama_oran']:.4f}".replace(".", ",")
            beyan_kkeg = fgk.get("beyan_kkeg", 0.0)
            satirlar = [
                ("1  Kısa Vadeli Yabancı Kaynaklar (3'lü Hesaplar, vergi karşılıkları hariç)", tutar_sade(fgk["kvyk"])),
                ("2  Uzun Vadeli Yabancı Kaynaklar (4'lü Hesaplar)", tutar_sade(fgk["uvyk"])),
                ("3  Toplam Yabancı Kaynaklar (1+2)", tutar_sade(fgk["toplam_yk"])),
                ("4  Özsermaye", tutar_sade(fgk["ozkaynak"])),
                ("5  Özsermayeyi Aşan Yabancı Kaynaklar (3-4)", tutar_sade(fgk["ozk_asan"])),
                ("6  Kısıtlama Oranı (5/3)", oran_tr),
                ("7  Maliyete Eklenen Finansman Gideri", "0,00"),
                ("8  Finansman Gideri (Vadeye Bağlı Faiz, Komisyon, Vade Farkı ve Kur Farkı)", tutar_sade(fgk["fg_top"])),
                ("9  Kısıtlanan Tutar (8*6)", tutar_sade(fgk.get("hesaplanan_kisitlama", fgk["kisitlama_tutar"]))),
                ("10 Hesaplanan KKEG (9*0,10)", tutar_sade(fgk.get("hesaplanan_kkeg", fgk["kkeg"]))),
            ]
            if beyan_kkeg > 0.005:
                satirlar.append(("11 Beyannamede Beyan Edilen FGK KKEG", tutar_sade(beyan_kkeg)))
            bloklar.append({
                "tip": "tablo",
                "basliklar": ["Özkaynak/Yabancı Kaynak Karşılaştırma Tablosu", "Tutar (TL)"],
                "satirlar": satirlar,
                "toplam": None,
            })
            if beyan_kkeg > 0.005:
                bloklar.append({"tip": "p", "metin": (
                    f"Yukarıdaki tabloda da görüleceği üzere şirketin toplam yabancı kaynaklarının "
                    f"{tutar(fgk['toplam_yk'])}, özkaynağı aşan tutarın {tutar(fgk['ozk_asan'])} ve yabancı "
                    f"kaynağın özkaynağı aşma oranının {oran_tr} olarak hesaplandığı; vadeye bağlı finansman "
                    f"gideri tutarı olan {tutar(fgk['fg_top'])} ile bu oranın çarpılması sonucu bulunan "
                    f"kısıtlamaya tabi tutarın %10'u olarak finansman gider kısıtlaması hesaplandığı "
                    f"görülmektedir. Şirket tarafından kurumlar vergisi beyannamesinde finansman gider "
                    f"kısıtlaması kapsamında {tutar(beyan_kkeg)} tutarın Kanunen Kabul Edilmeyen Gider olarak "
                    f"beyan edildiği ve yapılan hesaplama ile uyumlu olduğu tespit edilmiştir."
                )})
            else:
                bloklar.append({"tip": "p", "metin": (
                    f"Yukarıdaki tabloda da görüleceği üzere şirketin toplam yabancı kaynaklarının "
                    f"{tutar(fgk['toplam_yk'])} olduğu ve özkaynağı aşan tutarın {tutar(fgk['ozk_asan'])} ve "
                    f"yabancı kaynağın özkaynağı aşma oranının {oran_tr} olarak hesaplanması ile "
                    f"{tutar(fgk['fg_top'])} finansman gideri çarpılması sonucunda kısıtlamaya tabi tutar "
                    f"{tutar(fgk['kisitlama_tutar'])} olarak hesaplanmıştır. İlgili tutarın KVK'nın 11'inci "
                    f"maddesinde belirtilen %10 oranı ile çarpılması neticesinde finansman gider kısıtlaması "
                    f"olarak {tutar(fgk['kkeg'])}'nin Kanunen Kabul Edilmeyen Gider olarak beyan edildiği "
                    "anlaşılmıştır."
                )})

    # ---- 4. Kur Korumali Mevduat Kazanclari Istisnasi (KVK Gecici 14) ----
    kkm_tutar = _istisna_tutar_bul(
        bv.zarar_olsa_dahi_indirim_satirlari,
        ["geçici mad. 14", "geçici madde 14", "gecici mad. 14", "kkm", "kur korumalı", "kur korumali"],
    )
    if kkm_tutar > 0.005:
        n += 1
        bloklar.append({"tip": "h3", "metin": (
            f"{n}. Kur Korumalı Mevduat Kazançları İstisnası (KVK Geçici 14'üncü Madde Çerçevesinde "
            "İstisna Uygulaması):"
        )})
        bloklar.append({"tip": "p", "metin": (
            "31734 sayılı Resmi Gazete'de yayımlanan 7352 sayılı Kanunla, 5520 sayılı Kurumlar Vergisi "
            "Kanunu'na eklenen geçici 14'üncü madde ile; Türk Lirası mevduat ve katılma hesaplarına "
            "dönüşümün desteklenmesi kapsamında dönüşüm kuru/fiyatı üzerinden Türk lirasına çevrilen "
            "yabancı para ve altın hesaplarına ilişkin olarak, dönüşüm tarihinde oluşan kur farkı "
            "kazançları ile dönüşüm sonrasında elde edilen faiz, kâr payı ve diğer kazançlar belirli "
            "şartlarla kurumlar vergisinden istisna edilmiştir."
        )})
        bloklar.append({"tip": "p", "metin": (
            f"Şirketin {yil} hesap döneminde KVK Geçici 14'üncü madde kapsamında kurumlar vergisinden "
            f"istisna ettiği kur korumalı mevduat kazancı tutarı {tutar(kkm_tutar)} olup; ilgili istisna "
            "tutarının madde hükmüne ve çalışma kâğıtlarına uygun şekilde hesaplandığı, kayıtlar üzerinden "
            "yapılan incelemede Müşavirliğimizce tespit edilmiştir."
        )})

    # ---- 5. Diger Fon Kazanclari Istisnasi (KVK 5/1-a 3 ve 4) ----
    fon_tutar = _istisna_tutar_bul(
        bv.zarar_olsa_dahi_indirim_satirlari,
        ["5/1-a", "5/1 a", "iştirak kazanç", "istirak kazanc", "fon kazanç", "fon kazanc"],
    )
    if fon_tutar > 0.005:
        n += 1
        bloklar.append({"tip": "h3", "metin": f"{n}. Diğer Fon Kazançları İstisnası (KVK 5/1-a 3 ve KVK 5/1-a 4):"})
        bloklar.append({"tip": "p", "metin": (
            "Kurumlar Vergisi Kanunu'nun 5'inci maddesinin 1'inci fıkrasının (a) bendinde iştirak "
            "kazançları istisnası düzenlenmiştir. İlgili bent hükmü uyarınca, tam mükellefiyete tabi "
            "girişim sermayesi yatırım fonu katılma payları ile girişim sermayesi yatırım ortaklıklarının "
            "hisse senetlerinden elde edilen kâr payları (5/1-a-3) ve 15.07.2023 tarihli Resmi Gazete'de "
            "yayımlanan 7456 sayılı Kanun ile yapılan değişiklik öncesinde iktisap edilen diğer yatırım "
            "fonu katılma paylarından elde edilen kâr payları ile katılma paylarının fona iadesinden doğan "
            "gelirler (5/1-a-4) kurumlar vergisinden istisnadır."
        )})
        bloklar.append({"tip": "p", "metin": (
            f"Bu kapsamda Şirketin {yil} hesap döneminde KVK 5/1-a maddesi kapsamında kurumlar "
            f"vergisinden istisna ettiği iştirak/fon kazancı tutarı {tutar(fon_tutar)} olup; söz konusu "
            "hesaplamaların 7456 sayılı Kanun değişikliğine uygun şekilde yapıldığı, kayıtlar üzerinden "
            "yapılan incelemede Müşavirliğimizce tespit edilmiştir."
        )})

    # ---- 6. Transfer Fiyatlandirmasi Yoluyla Ortulu Kazanc Dagitimi ----
    n += 1
    bloklar.append({"tip": "h3", "metin": f"{n}. Transfer Fiyatlandırması Yoluyla Örtülü Kazanç Dağıtımı"})
    bloklar.append({"tip": "p", "metin": (
        f"Şirketin ilişkili kişilerle {donem_aralik} hesap döneminde gerçekleştirdiği işlemleri ile "
        "ilgili olarak doldurmuş olduğu “Transfer Fiyatlandırması, Kontrol Edilen Yabancı Kurum ve "
        "Örtülü Sermayeye İlişkin Form” ilgili döneme ilişkin Kurumlar Vergisi Beyannamesinin ekinde "
        "bağlı bulunulan vergi dairesine tevdi edilmiştir. Formda yer alan bilgilere esas teşkil eden "
        "dökümler ile yasal kayıtların uyumlu olup olmadığına yönelik olarak örnekleme yöntemiyle yapılan "
        "kontroller neticesinde formda yer alan bilgiler ile yasal kayıtlar arasında bir uyumsuzluğa "
        "rastlanılmamıştır."
    )})
    bloklar.append({"tip": "p", "metin": (
        "Diğer yandan, transfer fiyatlandırmasıyla ilgili düzenlemenin esasını teşkil eden 5520 sayılı "
        "KVK'nın 13. maddesinde düzenlenen “Emsallere uygunluk” ilkesi; ilişkili kişilerle yapılan mal "
        "veya hizmet alımı ya da satımında uygulanan fiyat veya bedelin, aralarında böyle bir ilişkinin "
        "bulunmaması durumunda oluşacak fiyat veya bedele uygun olması anlamına gelmektedir."
    )})
    bloklar.append({"tip": "p", "metin": (
        f"Raporun konusunu oluşturan tasdik hizmetleri kapsamında, ilişkili kişilerle {donem_aralik} "
        "hesap döneminde gerçekleştirilen işlemlerde uygulanan fiyatların emsallere uygunluğu yönünden "
        "işbu raporun konusunu oluşturan tasdik hizmetlerimizin kapsamı, şirketin yasal defterlerinde yer "
        "alan kayıt ve belgeler ile sınırlı tutulmuştur."
    )})

    # ---- 7. Nakdi Sermaye Artisindan Kaynaklanan Faiz Indirimi (KVK 10/1-i) ----
    if bv.nakdi_sermaye_satirlari or bv.nakdi_sermaye_indirim_toplam > 0.005:
        n += 1
        bloklar.append({"tip": "h3", "metin": f"{n}. Nakdi Sermaye Artışından Kaynaklanan Faiz İndirimi (KVK Mad. 10/1-ı):"})
        bloklar.append({"tip": "p", "metin": (
            "6637 sayılı Kanunla 5520 sayılı Kurumlar Vergisi Kanunu'nun 10'uncu maddesinin birinci "
            "fıkrasına eklenen (ı) bendi uyarınca; sermaye şirketlerinin ilgili hesap dönemi içinde, "
            "ticaret siciline tescil edilmiş olan ödenmiş veya çıkarılmış sermaye tutarlarındaki nakdi "
            "sermaye artışları veya yeni kurulan sermaye şirketlerinde ödenmiş sermayenin nakit olarak "
            "karşılanan kısmı üzerinden, TCMB tarafından en son açıklanan ticari krediler faiz oranı "
            "dikkate alınarak hesaplanan tutarın %50'si kurum kazancından indirilebilmektedir."
        )})
        if bv.nakdi_sermaye_satirlari:
            satirlar = []
            for s in bv.nakdi_sermaye_satirlari:
                satirlar.append((
                    s.get("tescil", ""), s.get("donem", ""),
                    tutar_sade(s.get("sermaye", 0.0) or 0.0),
                    str(s.get("faiz_orani", "")), str(s.get("sure", "")),
                    tutar_sade(s.get("indirim", 0.0) or 0.0),
                ))
            toplam_ns = bv.nakdi_sermaye_indirim_toplam if bv.nakdi_sermaye_indirim_toplam > 0.005 \
                else sum((s.get("indirim", 0.0) or 0.0) for s in bv.nakdi_sermaye_satirlari)
            bloklar.append({
                "tip": "tablo",
                "basliklar": ["Tescil Tarihi", "Dönem", "Sermaye Artışı (TL)", "Faiz Oranı (%)",
                              "Süre (Ay)", "İndirim Tutarı (TL)"],
                "satirlar": satirlar,
                "toplam": ("Toplam", "", "", "", "", tutar_sade(toplam_ns)),
            })
            bloklar.append({"tip": "p", "metin": (
                f"Şirketin {yil} hesap döneminde nakdi sermaye artışından kaynaklanan ve KVK 10/1-ı "
                f"maddesi kapsamında kurum kazancından indirim konusu yaptığı toplam tutar "
                f"{tutar(toplam_ns)} olarak hesaplanmıştır."
            )})
        elif bv.nakdi_sermaye_indirim_toplam > 0.005:
            bloklar.append({"tip": "p", "metin": (
                f"Şirketin {yil} hesap döneminde nakdi sermaye artışından kaynaklanan ve KVK 10/1-ı "
                f"maddesi kapsamında kurum kazancından indirim konusu yaptığı toplam tutar "
                f"{tutar(bv.nakdi_sermaye_indirim_toplam)} olarak hesaplanmıştır."
            )})

    return bloklar


# ============================================================
# C. DIGER INCELEMELER - GECICI VERGI
# ============================================================

def _gecici_vergi_section(rapor: RaporVerisi) -> list:
    """Yuklenen gecici vergi (KGV) beyannamelerinden donem-kolonlu tablo uretir.

    'C. DIGER INCELEMELER' h2 basligini ve '1.' h3 numarasini ICERMEZ; bunlar
    diger_incelemeler_bloklari orkestratorunde uretilir. Donem yoksa [] doner.
    """
    from parsers.gecici_vergi_parser import RAPOR_SATIRLARI

    donemler = [d for d in rapor.gecici_vergi_donemleri if d.donem_no]
    if not donemler:
        return []
    donemler = sorted(donemler, key=lambda d: d.donem_no)

    bloklar = []
    bloklar.append({"tip": "p", "metin": (
        "Şirketin cari vergilendirme döneminde kurumlar vergisine mahsup edilmek üzere, 5520 sayılı "
        "Kurumlar Vergisi Kanunu'nun 32'nci maddesinin 2'nci fıkrası ile 193 sayılı Gelir Vergisi "
        "Kanunu'nun mükerrer 120'nci maddesinde belirtilen esaslara göre beyan ettiği geçici vergi "
        "beyannamelerine ilişkin matrah ve vergi hesaplamaları aşağıdaki tabloda dönemler itibarıyla "
        "gösterilmiştir."
    )})

    # Bu satirlar gelir tablosu/beyanname disozisyonunda eksili (parantezli) gosterilir
    negatif_gosterilecek = {"ticari_bilanco_zarari", "zarar_indirimler_toplami", "zarar"}

    basliklar = ["Açıklama"] + [d.donem_adi or f"{d.donem_no}. Dönem" for d in donemler]
    satirlar = []
    for key, etiket in RAPOR_SATIRLARI:
        # Tum donemlerde sifir olan satirlari gizle (tabloyu sadelestir)
        degerler = [d.degerler.get(key, 0.0) for d in donemler]
        if all(abs(v) < 0.005 for v in degerler):
            continue
        if key in negatif_gosterilecek:
            hucreler = [tutar_sade(-abs(v)) for v in degerler]
        else:
            hucreler = [tutar_sade(v) for v in degerler]
        satir = [etiket] + hucreler
        satirlar.append(tuple(satir))

    bloklar.append({
        "tip": "tablo",
        "basliklar": basliklar,
        "satirlar": satirlar,
        "toplam": None,
    })

    # Donem sonu tevkifat devri ozeti
    son_donem = donemler[-1]
    devreden_tevkifat = son_donem.degerler.get("devreden_tevkifat", 0.0)
    if abs(devreden_tevkifat) > 0.005:
        bloklar.append({"tip": "p", "metin": (
            f"İncelenen son geçici vergi dönemi ({son_donem.donem_adi}) itibarıyla mahsup edilemeyen ve "
            f"sonraki döneme devreden tevkifat tutarı {tutar(devreden_tevkifat)} olarak hesaplanmış olup, "
            "söz konusu tutar kurumlar vergisi beyannamesinde mahsuba konu edilmek üzere izlenmiştir."
        )})

    return bloklar


# ============================================================
# ANA URETICI
# ============================================================

def hesap_incelemeleri_uret(rapor: RaporVerisi) -> list:
    """Tum III- Hesap Incelemeleri bolumunu uretir."""
    bloklar = []

    # Bolum basligi
    bloklar.append({"tip": "h1", "metin": "III- HESAP İNCELEMELERİ"})
    bloklar.append({"tip": "p", "metin": (
        f"{rapor.mukellef.donem} hesap dönemi işlemlerinin vergi kanunları yönünden yapılan incelemesinde "
        "tespit edilen hususlar ve değerlendirmeler aşağıda gösterilmiştir."
    )})

    # A. BILANCO
    bloklar.append({"tip": "h2", "metin": "A. BİLANÇO HESAPLARINA İLİŞKİN İNCELEMELER"})
    bloklar.append({"tip": "p", "metin": (
        f"Şirketin, raporumuza eklenmiş bulunan {rapor.mukellef.donem_sonu} tarihli bilançosunda yer alan "
        "tutarların defter-i kebir hesap bakiyeleri ile kanuni defter kayıtlarının mutabık olduğu ve "
        "gerçeği yansıttığı, bilançonun muhasebe sistemi uygulama genel tebliğlerinde belirtilen ilkelere "
        "uygun olduğu görülmüştür. 2025 hesap döneminde VUK Mükerrer 298 inci maddesinin (A) fıkrası "
        "kapsamında enflasyon düzeltmesi uygulanmamış; yalnızca amortismana tabi iktisadi kıymetler ile "
        "bunlara ait birikmiş amortismanlar VUK Mükerrer 298 inci maddesinin (Ç) fıkrası uyarınca sürekli "
        "yeniden değerlemeye tabi tutulmuştur."
    )})

    # 1. Yabanci Para
    bloklar.extend(bilanco_dovizli_bolum_bloklari(rapor))
    # 2.x diger bilanco hesaplari
    diger_bloklar, son_sira = diger_bilanco_bloklari(rapor, sira_baslangic=2)
    bloklar.extend(diger_bloklar)
    # 24. (veya yer geldikce) Ozkaynaklar
    oz_bloklar, _ = ozkaynaklar_bloklari(rapor, sira_baslangic=son_sira)
    bloklar.extend(oz_bloklar)

    # B. GELIR TABLOSU
    bloklar.extend(gelir_tablosu_bloklari(rapor))

    # C. DIGER INCELEMELER (gecici vergi + kesinti listesi + KKEG + FGK + istisnalar + TF + nakdi sermaye)
    bloklar.extend(diger_incelemeler_bloklari(rapor))

    return bloklar
