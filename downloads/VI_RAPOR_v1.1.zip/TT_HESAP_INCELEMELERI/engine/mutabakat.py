"""Mutabakat motoru: mizan, beyanname, mali tablo ve ek tablo kontrolleri."""
import re
import unicodedata

from engine.data_model import RaporVerisi, ValidationFinding


TOLERANS = 0.50


# Beyanname bilanço satiri -> TDHP hesaplari.
# Kisa/uzun vade ayrimi olan kalemlerde tek hesaba zorlamak yerine ilgili
# hesap ciftleri birlikte degerlendirilir.
TDHP_BILANCO_ESLESTIRMELERI = [
    (["gelecek aylara ait gider", "gelir tahakkuk"], ["180", "181"]),
    (["gelecek yillara ait gider", "gelir tahakkuk"], ["280", "281"]),
    (["gelecek aylara ait gelir", "gider tahakkuk"], ["380", "381"]),
    (["gelecek yillara ait gelir", "gider tahakkuk"], ["480", "481"]),
    (["gelecek aylara ait gelirler ve gider tahakkuklari"], ["380", "381"]),
    (["verilen depozito", "teminat"], ["126", "226"]),
    (["verilen siparis avans"], ["159", "259"]),
    (["gelecek aylara ait gider"], ["180"]),
    (["gelecek yillara ait gider"], ["280"]),
    (["gelir tahakkuk"], ["181"]),
    # "Diger KDV" hem aktif (192) hem pasif (392) tarafta gecer; bolum filtresi
    # (aktif->1/2, pasif->3/4/5) dogru hesabi secer, aksi halde aktif satiri 192,
    # pasif satiri da 192 ile karsilastirip sahte uyumsuzluk uretirdi.
    (["diger kdv"], ["192", "392"]),
    (["indirilecek kdv"], ["191"]),
    (["devreden kdv"], ["190"]),
    (["kasa"], ["100"]),
    (["alinan cek"], ["101"]),
    # "banka kred" (Mali Borclar) genel "banka"/"bankalar" anahtarindan ONCE gelmeli;
    # aksi halde "Banka Kredileri" satiri 102 Bankalar ile eslesip sahte uyumsuzluk uretir.
    (["banka kred"], ["300", "400"]),
    (["bankalar"], ["102"]),
    (["banka"], ["102"]),
    (["verilen cek", "odeme emir"], ["103"]),
    (["diger hazir deger"], ["108"]),
    (["diger menkul kiymet"], ["118"]),
    (["alicilar"], ["120"]),
    # NOT: "Karsiligi" normalize edilince "karsiligi" olur; "karsilik" alt dizisi
    # (sonu 'k') bunun icinde GECMEZ. Bu yuzden "karsilig" kullanilmali; aksi halde
    # karsilik satiri 129 yerine 128 ile eslesip sahte uyumsuzluk uretirdi.
    (["supheli ticari alacak", "karsilig"], ["129"]),
    (["supheli ticari alacak"], ["128"]),
    (["personelden alacak"], ["135"]),
    (["diger cesitli alacak"], ["136", "236"]),
    (["ilk madde", "malzeme"], ["150"]),
    (["yari mamul"], ["151"]),
    (["mamuller"], ["152"]),
    (["ticari mallar"], ["153"]),
    (["diger stok"], ["157"]),
    # "alinan siparis avans" (340/440), "is avans" (195) anahtarindan ONCE gelmeli;
    # cunku "siparIS AVANSlari" metni "is avans" alt dizisini icerir ve yanlis eslesir.
    (["alinan siparis avans"], ["340", "440"]),
    (["is avans"], ["195"]),
    (["personel avans"], ["196"]),
    (["arazi", "arsa"], ["250"]),
    (["yer alti", "yer ustu"], ["251"]),
    (["bina"], ["252"]),
    (["tesis", "makina"], ["253"]),
    (["tasit"], ["254"]),
    (["demirbas"], ["255"]),
    (["yapilmakta olan yatirim"], ["258"]),
    (["haklar"], ["260"]),
    (["arastirma", "gelistirme"], ["263"]),
    (["ozel maliyet"], ["264"]),
    (["diger maddi olmayan"], ["267"]),
    # "Ertelenmis Finansal Kiralama Borclanma" (302/402, eksilten/regulatif hesap)
    # metni hem "finansal kiralama" hem "borc" iceriyor; ozgul "ertelenmis" kurali
    # genel kuraldan ONCE gelmeli, aksi halde 301/401 ile eslesip sahte uyumsuzluk uretir.
    (["ertelenmis finansal kiralama"], ["302", "402"]),
    (["finansal kiralama", "borc"], ["301", "401"]),
    (["diger mali borc"], ["309", "409"]),
    # Saticilar hem KVYK (320) hem UVYK (420) tarafta yer alir; vade filtresi
    # (kisa->3, uzun->4) dogru hesabi secer.
    (["saticilar"], ["320", "420"]),
    (["personele borc"], ["335"]),
    (["diger cesitli borc"], ["336", "436"]),
    (["odenecek vergi", "fon"], ["360"]),
    (["odenecek sosyal guvenlik"], ["361"]),
    (["gider tahakkuk"], ["381"]),
    (["gelecek aylara ait gelir"], ["380"]),
    (["gelecek yillara ait gelir"], ["480"]),
    # "Odenmis Sermaye" beyanname kalemi 500 + 502 (gerekirse -501) toplamidir;
    # tek basina 500 ile karsilastirilirsa enflasyon duzeltmesi farki kadar sahte
    # uyumsuzluk uretir. Ozgul anahtarlar bare "sermaye"den ONCE gelmeli.
    (["odenmemis sermaye"], ["501"]),
    (["odenmis sermaye"], ["500", "501", "502"]),
    (["sermaye duzeltmesi olumlu"], ["502"]),
    # "Sermaye Yedekleri" grup toplami 52x hesaplarinin toplamidir; bare "sermaye"
    # kuralindan ONCE gelmeli, aksi halde 500 (Sermaye) ile eslesip sahte uyumsuzluk
    # uretirdi. MDV yeniden degerleme artislari 522'de izlenir.
    (["maddi duran varlik yeniden degerleme"], ["522"]),
    (["sermaye yedek"], ["520", "521", "522", "523", "524", "525", "526", "527", "529"]),
    (["sermaye"], ["500"]),
    (["hisse senedi ihrac"], ["520"]),
    (["yasal yedek"], ["540"]),
    (["statu yedek"], ["541"]),
    (["olaganustu yedek"], ["542"]),
    (["ozel fon"], ["549"]),
    (["gecmis yillar zarar"], ["580"]),
    (["donem net kari", "zarar"], ["590", "591"]),
    (["donem net kari"], ["590"]),
]


def _norm(text: str) -> str:
    s = str(text or "").lower()
    s = s.translate(str.maketrans({
        "ı": "i", "İ": "i", "ğ": "g", "Ğ": "g", "ü": "u", "Ü": "u",
        "ş": "s", "Ş": "s", "ö": "o", "Ö": "o", "ç": "c", "Ç": "c",
    }))
    for bad, good in {
        "Ä±": "i", "Ä°": "i", "ÄŸ": "g", "Ä": "g", "Ã¼": "u", "Ãœ": "u",
        "ÅŸ": "s", "Å": "s", "Ã¶": "o", "Ã–": "o", "Ã§": "c", "Ã‡": "c",
    }.items():
        s = s.replace(bad.lower(), good)
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _kod_eslesir(hesap_kodu: str, target: str) -> bool:
    hk = hesap_kodu.strip()
    return hk == target or hk.startswith(target + ".")


def _hesap_bakiye(rapor: RaporVerisi, hesap_kodu: str) -> float:
    target = hesap_kodu.strip()
    for satir in rapor.mizan:
        if satir.hesap_kodu.strip() == target:
            return satir.net_bakiye
    # Ana hesap satiri yoksa alt hesaplarin en alt seviyesinden topla.
    ilgili = [s for s in rapor.mizan if _kod_eslesir(s.hesap_kodu, target)]
    kodlar = {s.hesap_kodu.strip() for s in ilgili}
    toplam = 0.0
    for satir in ilgili:
        hk = satir.hesap_kodu.strip()
        if not any(other.startswith(hk + ".") for other in kodlar):
            toplam += satir.net_bakiye
    return toplam


def _hesaplar_bakiye(rapor: RaporVerisi, hesap_kodlari: list[str]) -> float:
    return sum(_hesap_bakiye(rapor, kod) for kod in hesap_kodlari)


def _hesap_kodlari_bul(aciklama: str) -> list[str]:
    ad = _norm(aciklama)
    for anahtarlar, kodlar in TDHP_BILANCO_ESLESTIRMELERI:
        if all(_norm(anahtar) in ad for anahtar in anahtarlar):
            return kodlar
    return []


def mizan_borc_alacak_kontrol(rapor: RaporVerisi) -> ValidationFinding | None:
    """Mizan borc/alacak esitligi; sadece en alt seviye hesaplar dikkate alinir."""
    leaf_satirlar = []
    kodlar = {s.hesap_kodu.strip() for s in rapor.mizan}
    for satir in rapor.mizan:
        hk = satir.hesap_kodu.strip()
        if not any(other.startswith(hk + ".") for other in kodlar):
            leaf_satirlar.append(satir)

    toplam_borc = sum(s.borc_toplam for s in leaf_satirlar)
    toplam_alacak = sum(s.alacak_toplam for s in leaf_satirlar)
    fark = abs(toplam_borc - toplam_alacak)
    if fark <= TOLERANS:
        return None
    return ValidationFinding(
        kod="VAL-001",
        aciklama=f"Mizan borc/alacak toplami esit degil. Borc: {toplam_borc:,.2f}, Alacak: {toplam_alacak:,.2f}, Fark: {fark:,.2f}",
        onem="uyari",
        mizan_tutar=toplam_borc,
        beyanname_tutar=toplam_alacak,
        fark=fark,
    )


def beyanname_mizan_kontrol(rapor: RaporVerisi) -> list:
    """Beyanname bilançosu ile mizan TDHP hesaplarini karsilastir."""
    bulgular = []
    for kalem in rapor.beyanname.bilanco_satirlari:
        hesap_kodlari = _hesap_kodlari_bul(kalem.aciklama)
        if not hesap_kodlari:
            continue

        # Vade-bolunmus kalemler (orn. "Banka Kredileri" hem KVYK 300 hem UVYK 400)
        # beyannamede kisa/uzun olarak ayri satirlarda gosterilir. Her iki satiri da
        # birlesik 300+400 mizan toplami ile karsilastirmak sahte uyumsuzluk uretir;
        # kalemin vade baglamina gore dogru tek hesap secilir (kisa: 1xx/3xx, uzun: 2xx/4xx).
        # Bolum (aktif/pasif) filtresi: ayni metnin hem aktif hem pasif tarafta
        # gectigi kalemleri (orn. "Diger KDV" 192/392) dogru tarafa yonlendirir.
        bolum = getattr(kalem, "bolum", "")
        if bolum and len(hesap_kodlari) > 1:
            bolum_haneler = {"aktif": ("1", "2"), "pasif": ("3", "4", "5")}.get(bolum, ())
            if bolum_haneler:
                filtreli_b = [k for k in hesap_kodlari if k[:1] in bolum_haneler]
                if filtreli_b:
                    hesap_kodlari = filtreli_b

        vade = getattr(kalem, "vade", "")
        if vade and len(hesap_kodlari) > 1:
            ilk_haneler = {"kisa": ("1", "3"), "uzun": ("2", "4")}.get(vade, ())
            filtreli = [k for k in hesap_kodlari if k[:1] in ilk_haneler]
            if filtreli:
                hesap_kodlari = filtreli

        mizan_bakiye = abs(_hesaplar_bakiye(rapor, hesap_kodlari))
        beyanname_tutar = abs(kalem.cari_donem)
        fark = abs(mizan_bakiye - beyanname_tutar)
        if fark <= TOLERANS:
            continue

        # Donem net kari/zarari cogu mizanda (kapanis kaydi yapilmadigi icin) 590/591'de
        # gorunmez; sonuc 6xx/7xx hesaplarinda acik durur. Bu durumda 590/591 = 0 olur ve
        # beyanname ile karsilastirma anlamsiz bir "uyumsuzluk" uretir. Mizan tarafi sifirsa
        # bu kalem dogrulanamaz; sahte bulgu yerine atlanir.
        if set(hesap_kodlari) <= {"590", "591"} and mizan_bakiye <= TOLERANS:
            continue

        kod_metni = "+".join(hesap_kodlari)
        bulgular.append(ValidationFinding(
            kod=f"VAL-FS-{kod_metni}",
            aciklama=f"{kalem.aciklama.strip()} ({kod_metni}) kaleminde mizan-beyanname uyumsuzlugu",
            onem="uyari" if fark < 100 else "kritik",
            mizan_tutar=mizan_bakiye,
            beyanname_tutar=beyanname_tutar,
            fark=fark,
        ))
    return bulgular


# Gelir tablosu grup satiri -> TDHP gelir/gider hesaplari.
# Yalnizca tek bir hesap grubuna karsilik gelen ana satirlar; ara toplamlar
# (Net Satislar, Brut Satis Kari, Faaliyet Kari, Olagan Kar, Donem Kari/Net Kari)
# tek bir hesaba denk gelmedigi icin haric birakilir.
TDHP_GELIR_TABLOSU_ESLESTIRMELERI = [
    (["brut satislar"], ["600", "601", "602"]),
    (["satis indirimleri"], ["610", "611", "612"]),
    (["satislarin maliyeti"], ["620", "621", "622", "623"]),
    (["faaliyet giderleri"], ["630", "631", "632"]),
    (["diger faaliyetlerden olagan gelir"],
     ["640", "641", "642", "643", "644", "645", "646", "647", "648", "649"]),
    (["diger faaliyetlerden olagan gider"],
     ["653", "654", "655", "656", "657", "658", "659"]),
    (["finansman giderleri"], ["660", "661"]),
    (["disi gelir"], ["671", "679"]),
    (["disi gider"], ["680", "681", "689"]),
]


def _gelir_tablosu_kodlari_bul(aciklama: str) -> list[str]:
    ad = _norm(aciklama)
    # Alt kirilim satirlari (". 1. Yurtici Satislar" -> "1 yurtici satislar") ana
    # grup toplamiyla cifte sayilmasin diye atlanir.
    if ad[:1].isdigit():
        return []
    for anahtarlar, kodlar in TDHP_GELIR_TABLOSU_ESLESTIRMELERI:
        if all(_norm(anahtar) in ad for anahtar in anahtarlar):
            return kodlar
    return []


def beyanname_gelir_tablosu_kontrol(rapor: RaporVerisi) -> list:
    """Beyanname eki gelir tablosu gruplarini mizan 6xx/7xx hesaplari ile karsilastir.

    6xx sonuc hesaplari yil sonunda 690'a devredildiginde mizanda sifir gorunur;
    bu durumda karsilastirma anlamsiz oldugu icin mizan tarafi sifirsa satir atlanir
    (sahte uyumsuzluk uretmemek icin).
    """
    bulgular = []
    for kalem in rapor.beyanname.gelir_tablosu_satirlari:
        hesap_kodlari = _gelir_tablosu_kodlari_bul(kalem.aciklama)
        if not hesap_kodlari:
            continue
        mizan_bakiye = abs(_hesaplar_bakiye(rapor, hesap_kodlari))
        if mizan_bakiye <= TOLERANS:
            continue
        beyanname_tutar = abs(kalem.cari_donem)
        fark = abs(mizan_bakiye - beyanname_tutar)
        if fark <= TOLERANS:
            continue
        kod_metni = "+".join(hesap_kodlari)
        bulgular.append(ValidationFinding(
            kod=f"VAL-GT-{kod_metni}",
            aciklama=f"{kalem.aciklama.strip()} ({kod_metni}) kaleminde mizan-beyanname gelir tablosu uyumsuzlugu",
            onem="uyari" if fark < 100 else "kritik",
            mizan_tutar=mizan_bakiye,
            beyanname_tutar=beyanname_tutar,
            fark=fark,
        ))
    return bulgular


def _vuk_kur(rapor: RaporVerisi, doviz_cinsi: str) -> float:
    dc = (doviz_cinsi or "").upper()
    if dc == "USD":
        return rapor.kurlar.usd_alis
    if dc == "EUR":
        return rapor.kurlar.eur_alis
    if dc == "GBP":
        return rapor.kurlar.gbp_alis
    if dc == "CHF":
        return rapor.kurlar.chf_alis
    return 0.0


def _kur_satiri_tl(rapor: RaporVerisi, satir) -> float:
    kur = satir.kur or _vuk_kur(rapor, satir.doviz_cinsi)
    if abs(satir.tl_tutar) > 0.001:
        return satir.tl_tutar
    if abs(satir.doviz_tutari) > 0.001 and abs(kur) > 0.001:
        return satir.doviz_tutari * kur
    return 0.0


def yabanci_para_kontrol(rapor: RaporVerisi) -> list:
    """Dovizli mizan, kur hesaplama Excel'i ve beyanname yabanci para eklerini karsilastir."""
    bulgular = []
    mizan_tl = sum(abs(s.tl_bakiye) for s in rapor.dovizli_mizan if (s.doviz_cinsi or "").upper() not in ("", "TL", "TRY"))
    kur_tl = sum(abs(_kur_satiri_tl(rapor, s)) for s in rapor.kur_hesaplama_satirlari)
    beyan_tl = sum(abs(_kur_satiri_tl(rapor, s)) for s in rapor.beyanname.yabanci_para_satirlari)

    if mizan_tl < TOLERANS and kur_tl > TOLERANS:
        bulgular.append(ValidationFinding(
            kod="VAL-YP-KAYNAK",
            aciklama="Dovizli mizan bulunmadigi icin yabanci para hesaplari yuklenen kur hesaplama Excel'i uzerinden rapora alinacak.",
            onem="uyari",
            mizan_tutar=mizan_tl,
            beyanname_tutar=kur_tl,
            fark=kur_tl,
        ))
    elif mizan_tl < TOLERANS and kur_tl < TOLERANS and beyan_tl > TOLERANS:
        bulgular.append(ValidationFinding(
            kod="VAL-YP-BEYAN",
            aciklama="Dovizli mizan ve kur hesaplama Excel'i bulunmadigi icin yabanci para karsiliklari kurumlar vergisi beyannamesi ekinden ve VUK kurlarindan hesaplanacak.",
            onem="uyari",
            mizan_tutar=mizan_tl,
            beyanname_tutar=beyan_tl,
            fark=beyan_tl,
        ))

    if mizan_tl > TOLERANS and kur_tl > TOLERANS:
        fark = abs(mizan_tl - kur_tl)
        if fark > max(TOLERANS, mizan_tl * 0.01):
            bulgular.append(ValidationFinding(
                kod="VAL-YP-MIZAN-KUR",
                aciklama="Yabanci para TL karsiliklari dovizli mizan ile yuklenen kur hesaplama Excel'i arasinda farkli.",
                onem="kritik" if fark > 100 else "uyari",
                mizan_tutar=mizan_tl,
                beyanname_tutar=kur_tl,
                fark=fark,
            ))

    if mizan_tl > TOLERANS and beyan_tl > TOLERANS:
        fark = abs(mizan_tl - beyan_tl)
        if fark > max(TOLERANS, mizan_tl * 0.01):
            bulgular.append(ValidationFinding(
                kod="VAL-YP-MIZAN-BEYAN",
                aciklama="Yabanci para TL karsiliklari dovizli mizan ile kurumlar vergisi beyannamesi eki arasinda farkli.",
                onem="kritik" if fark > 100 else "uyari",
                mizan_tutar=mizan_tl,
                beyanname_tutar=beyan_tl,
                fark=fark,
            ))

    for satir in rapor.kur_hesaplama_satirlari:
        if abs(satir.kur) < 0.001:
            continue
        vuk = _vuk_kur(rapor, satir.doviz_cinsi)
        if abs(vuk) < 0.001:
            continue
        fark = abs(abs(satir.kur) - abs(vuk))
        if fark > 0.01:
            bulgular.append(ValidationFinding(
                kod=f"VAL-KUR-{satir.doviz_cinsi}",
                aciklama=f"{satir.doviz_cinsi} kuru yuklenen tabloda VUK kurundan farkli. Satir: {satir.hesap_kodu or satir.hesap_adi}",
                onem="uyari",
                mizan_tutar=satir.kur,
                beyanname_tutar=vuk,
                fark=fark,
            ))
            break
    return bulgular


def amortisman_dipnot_kontrol(rapor: RaporVerisi) -> list:
    """Beyanname dipnotlarindaki amortisman tutari ile mizandaki amortisman satirlarini karsilastir."""
    dipnot = abs(rapor.beyanname.dipnot_tutarlari.get("amortisman", 0.0))
    if dipnot < TOLERANS:
        return []
    # Sadece bilanco birikmis amortisman ANA hesaplari (257, 268) toplanmali.
    # Onceki kod adi "amortisman" iceren tum hesaplari (730/740/760/770 amortisman
    # gider hesaplari dahil) ve alt kirilimlari topluyordu; bu da birikmis amortismani
    # kat kat asan (~621M) sahte bir tutar uretiyordu.
    mizan_tutar = 0.0
    for satir in rapor.mizan:
        hk = satir.hesap_kodu.strip()
        if hk in ("257", "268"):
            mizan_tutar += abs(satir.net_bakiye)
    fark = abs(mizan_tutar - dipnot)
    if fark <= max(TOLERANS, dipnot * 0.01):
        return []
    return [ValidationFinding(
        kod="VAL-AMORT-DIPNOT",
        aciklama="Amortisman tutari mizandaki amortisman hesaplari ile kurumlar vergisi beyannamesi dipnotlari/ek bilgileri arasinda farkli gorunuyor.",
        onem="kritik" if fark > 100 else "uyari",
        mizan_tutar=mizan_tutar,
        beyanname_tutar=dipnot,
        fark=fark,
    )]


def kontrolleri_calistir(rapor: RaporVerisi) -> list:
    """Tum kontrolleri calistir ve bulgulari rapor.bulgular'a ekle."""
    bulgular = []
    f = mizan_borc_alacak_kontrol(rapor)
    if f:
        bulgular.append(f)
    bulgular.extend(beyanname_mizan_kontrol(rapor))
    bulgular.extend(beyanname_gelir_tablosu_kontrol(rapor))
    bulgular.extend(yabanci_para_kontrol(rapor))
    bulgular.extend(amortisman_dipnot_kontrol(rapor))
    rapor.bulgular = bulgular
    return bulgular
