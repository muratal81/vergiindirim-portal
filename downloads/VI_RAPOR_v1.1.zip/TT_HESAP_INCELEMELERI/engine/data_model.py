"""Veri modelleri."""
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class MizanSatiri:
    """Tek bir mizan satirini temsil eder."""
    hesap_kodu: str
    hesap_adi: str
    borc_toplam: float = 0.0
    alacak_toplam: float = 0.0
    borc_bakiye: float = 0.0
    alacak_bakiye: float = 0.0
    para_birimi: str = "TL"

    @property
    def net_bakiye(self) -> float:
        """Net bakiye (borc - alacak). Borc bakiye pozitif, alacak bakiye negatif."""
        return self.borc_bakiye - self.alacak_bakiye

    @property
    def bakiye_mutlak(self) -> float:
        """Mutlak bakiye degeri (TL)."""
        return abs(self.borc_bakiye) if self.borc_bakiye else abs(self.alacak_bakiye)

    @property
    def ana_hesap_kodu(self) -> str:
        """100.01.001 -> 100"""
        return self.hesap_kodu.split(".")[0].strip()

    @property
    def alt_seviye(self) -> int:
        """100 = 0, 100.01 = 1, 100.01.001 = 2"""
        return self.hesap_kodu.count(".")


@dataclass
class DovizliMizanSatiri:
    """Dovizli mizan satiri - orijinal doviz tutari ile."""
    hesap_kodu: str
    hesap_adi: str
    doviz_cinsi: str
    doviz_borc_toplam: float = 0.0
    doviz_alacak_toplam: float = 0.0
    doviz_borc_bakiye: float = 0.0
    doviz_alacak_bakiye: float = 0.0
    tl_borc_toplam: float = 0.0
    tl_alacak_toplam: float = 0.0
    tl_borc_bakiye: float = 0.0
    tl_alacak_bakiye: float = 0.0

    @property
    def doviz_bakiye(self) -> float:
        return self.doviz_borc_bakiye - self.doviz_alacak_bakiye

    @property
    def tl_bakiye(self) -> float:
        return self.tl_borc_bakiye - self.tl_alacak_bakiye

    @property
    def kur(self) -> float:
        if self.doviz_bakiye and abs(self.doviz_bakiye) > 0.001:
            return self.tl_bakiye / self.doviz_bakiye
        return 0.0

    @property
    def ana_hesap_kodu(self) -> str:
        return self.hesap_kodu.split(".")[0].strip()


@dataclass
class KurHesapSatiri:
    """Yuklenen kur hesaplama tablosu veya beyanname ekinden gelen yabanci para satiri."""
    hesap_kodu: str = ""
    hesap_adi: str = ""
    doviz_cinsi: str = ""
    doviz_tutari: float = 0.0
    kur: float = 0.0
    tl_tutar: float = 0.0
    kaynak: str = ""

    @property
    def ana_hesap_kodu(self) -> str:
        return self.hesap_kodu.split(".")[0].strip()


@dataclass
class YenidenDegerlemeSatiri:
    """VUK Mukerrer 298/C kapsaminda yeniden degerleme - hesap bazinda ozet satiri."""
    hesap_kodu: str = ""          # 251, 252, 253, 255, 260, 267
    hesap_adi: str = ""
    kiymet_adedi: int = 0
    aktif_degerleme_tutari: float = 0.0   # Aktif (brut) deger artisi
    amortisman_artis_tutari: float = 0.0  # Birikmis amortisman artisi
    net_degerleme_tutari: float = 0.0     # 522'ye atilan net deger artis fonu


@dataclass
class BilancoKalemi:
    """Bilanco satiri (TDHP standardi)."""
    hesap_kodu: str  # 100, 101, 102 vb. veya bos
    aciklama: str
    onceki_donem: float = 0.0
    cari_donem: float = 0.0
    seviye: int = 0  # 0=baslik, 1=grup, 2=detay
    vade: str = ""  # "kisa" (donen/KVYK) | "uzun" (duran/UVYK) | "" (ozkaynak/belirsiz)
    bolum: str = ""  # "aktif" | "pasif" | "" (bilanco tarafini ayirt etmek icin)


@dataclass
class GelirTablosuKalemi:
    """Gelir tablosu satiri."""
    hesap_kodu: str
    aciklama: str
    onceki_donem: float = 0.0
    cari_donem: float = 0.0
    seviye: int = 0


@dataclass
class GeciciVergiDonemi:
    """Tek bir gecici vergi beyannamesi donemi (KGV)."""
    donem_no: int = 0          # 1, 2, 3, 4
    donem_adi: str = ""        # "Ocak-Mart", "Ocak-Haziran", "Ocak-Eylul", "Ocak-Aralik"
    yil: str = ""
    vergi_no: str = ""
    unvan: str = ""
    degerler: dict = field(default_factory=dict)  # canonical_field -> float
    kaynak_dosya: str = ""


@dataclass
class BeyannameVerisi:
    """Kurumlar vergisi beyannamesi - onemli alanlar."""
    vergi_no: str = ""
    unvan: str = ""
    donem: str = ""
    vergi_dairesi: str = ""

    # Ana matrah/vergi bilgileri
    ticari_bilanco_kari: float = 0.0
    ticari_bilanco_zarari: float = 0.0
    kkeg_toplam: float = 0.0
    zarar_olsa_dahi_indirim_toplam: float = 0.0
    matrah: float = 0.0
    hesaplanan_vergi: float = 0.0
    yil_ici_kesinti: float = 0.0
    odenen_gecici_vergi: float = 0.0

    # Bilanco satirlari (PDF'den okunan)
    bilanco_satirlari: list = field(default_factory=list)  # list[BilancoKalemi]
    gelir_tablosu_satirlari: list = field(default_factory=list)

    # Istisna/indirimler (tur, tutar)
    istisnalar: list = field(default_factory=list)  # list[tuple[str, float]]
    dipnot_tutarlari: dict = field(default_factory=dict)
    yabanci_para_satirlari: list = field(default_factory=list)  # list[KurHesapSatiri]

    # C. Diger Incelemeler bolumu icin beyanname eki tablolari
    # Kesinti Yoluyla Odenen Vergilere Iliskin Liste
    kesinti_listesi: list = field(default_factory=list)  # list[dict]: unvan, vkn, donem, brut, vergi
    # Kanunen Kabul Edilmeyen Giderler dokumu
    kkeg_satirlari: list = field(default_factory=list)  # list[tuple[str, float]]
    # "ZARAR OLSA DAHI INDIRILECEK ISTISNA VE INDIRIMLER" dokumu
    zarar_olsa_dahi_indirim_satirlari: list = field(default_factory=list)  # list[tuple[str, float]]
    # "KAZANCIN BULUNMASI HALINDE INDIRILECEK ISTISNA VE INDIRIMLER" dokumu
    kazanc_halinde_indirim_satirlari: list = field(default_factory=list)  # list[tuple[str, float]]
    # Nakdi Sermaye Artisindan Kaynaklanan Faiz Indirimi tablosu
    nakdi_sermaye_satirlari: list = field(default_factory=list)  # list[dict]
    nakdi_sermaye_indirim_toplam: float = 0.0


@dataclass
class MukellefBilgileri:
    """Rapor kapagi icin mukellef ve donem bilgileri."""
    vergi_no: str = ""
    unvan: str = ""
    vergi_dairesi: str = ""
    donem_baslangic: str = "01.01.2024"
    donem_bitis: str = "31.12.2024"
    rapor_no: str = ""
    ymm_adi: str = ""
    ymm_oda_sicil: str = ""

    @property
    def donem(self) -> str:
        return f"{self.donem_baslangic}-{self.donem_bitis}"

    @property
    def donem_sonu(self) -> str:
        return self.donem_bitis


@dataclass
class KurTablosu:
    """590 Sira No.lu VUK GT - 24.01.2026 tarih, 33147 sayili RG - 31.12.2025 doviz kurlari."""
    teblig_tarihi: str = "24.01.2026"
    teblig_no: str = "590"
    rg_no: str = "33147"  # Resmi Gazete sayisi
    # Yil sonu 31.12.2025 kurlari (590 Sira No.lu VUK Genel Tebligi eki)
    usd_alis: float = 42.8623
    usd_efektif_alis: float = 42.8323
    eur_alis: float = 50.4532
    eur_efektif_alis: float = 50.4179
    gbp_alis: float = 57.8159
    chf_alis: float = 54.2141


@dataclass
class ValidationFinding:
    """Mutabakat bulgusu."""
    kod: str
    aciklama: str
    onem: str  # 'kritik', 'uyari', 'bilgi'
    mizan_tutar: float = 0.0
    beyanname_tutar: float = 0.0
    fark: float = 0.0


@dataclass
class RaporVerisi:
    """Tum raporun kullanacagi konsolide veri."""
    mukellef: MukellefBilgileri
    mizan: list  # list[MizanSatiri]
    dovizli_mizan: list  # list[DovizliMizanSatiri]
    bilanco: list  # list[BilancoKalemi]
    gelir_tablosu: list  # list[GelirTablosuKalemi]
    beyanname: BeyannameVerisi
    kurlar: KurTablosu
    kur_hesaplama_satirlari: list = field(default_factory=list)  # list[KurHesapSatiri]
    gecici_vergi_donemleri: list = field(default_factory=list)  # list[GeciciVergiDonemi]
    yeniden_degerleme_satirlari: list = field(default_factory=list)  # list[YenidenDegerlemeSatiri]
    bulgular: list = field(default_factory=list)  # list[ValidationFinding]

    def hesap_bakiye(self, hesap_kodu_prefix: str) -> float:
        """Bir hesap koduyla baslayan TUM alt hesaplarin TL bakiyeleri toplami (sadece ana hesap satirini al)."""
        # Ana hesap satirini bul (3 haneli)
        target = hesap_kodu_prefix.strip()
        for satir in self.mizan:
            if satir.hesap_kodu.strip() == target:
                return satir.net_bakiye
        # Bulunamazsa toplam alt hesaplardan hesapla
        # Ama bu sefer SADECE en alt seviye satirlari ele al (cifte sayma olmasin)
        toplam = 0.0
        for satir in self.mizan:
            if satir.hesap_kodu.startswith(target + ".") or satir.hesap_kodu == target:
                # Sadece en derin seviyeyi al
                pass
        # Default: ana hesap kodu eslesen ilk satiri al
        for satir in self.mizan:
            if satir.ana_hesap_kodu == target:
                return satir.net_bakiye
        return 0.0

    @staticmethod
    def _kod_eslesir(hesap_kodu: str, target: str) -> bool:
        """100 prefix'i 10000xxx kodlu hesaplari degil sadece 100, 100.01.001 gibi noktaii baslayanlari yakalamali."""
        hk = hesap_kodu.strip()
        return hk == target or hk.startswith(target + ".")

    def dovizli_bakiye_toplami(self, hesap_kodu_prefix: str) -> float:
        """Bir hesap grubunun dovizli alt hesaplarinin TL bakiye toplami."""
        toplam = 0.0
        target = hesap_kodu_prefix.strip()
        for satir in self._aktif_yabanci_para_satirlari():
            if self._kod_eslesir(satir["hesap_kodu"], target):
                toplam += satir["tl_tutar"]
        return toplam

    def dovizli_detay(self, hesap_kodu_prefix: str) -> dict:
        """Hesap grubunun dovizli detayi: {doviz_cinsi: (toplam_doviz, ortalama_kur, toplam_tl)}"""
        target = hesap_kodu_prefix.strip()
        detay = {}  # doviz_cinsi -> [doviz, tl]
        for satir in self._aktif_yabanci_para_satirlari():
            if not self._kod_eslesir(satir["hesap_kodu"], target):
                continue
            dc = satir["doviz_cinsi"].upper()
            if dc not in detay:
                detay[dc] = [0.0, 0.0]
            detay[dc][0] += satir["doviz_tutari"]
            detay[dc][1] += satir["tl_tutar"]
        # Kur hesapla
        sonuc = {}
        for dc, (doviz, tl) in detay.items():
            kur = tl / doviz if abs(doviz) > 0.001 else 0.0
            sonuc[dc] = (doviz, kur, tl)
        return sonuc

    def _aktif_yabanci_para_satirlari(self) -> list:
        """Oncelik: dovizli mizan, yuklenen kur Excel'i, beyanname eki."""
        satirlar = []
        for satir in self.dovizli_mizan:
            dc = (satir.doviz_cinsi or "").upper()
            if dc and dc not in ("TL", "TRY"):
                satirlar.append({
                    "hesap_kodu": satir.hesap_kodu,
                    "doviz_cinsi": dc,
                    "doviz_tutari": satir.doviz_bakiye,
                    "tl_tutar": satir.tl_bakiye,
                    "kaynak": "Dovizli mizan",
                })
        if satirlar:
            return satirlar

        kaynak_satirlar = self.kur_hesaplama_satirlari or self.beyanname.yabanci_para_satirlari
        for satir in kaynak_satirlar:
            dc = (satir.doviz_cinsi or "").upper()
            if not dc or dc in ("TL", "TRY"):
                continue
            kur = satir.kur or self._varsayilan_kur(dc)
            doviz = satir.doviz_tutari
            tl = satir.tl_tutar
            if abs(doviz) < 0.001 and abs(tl) > 0.001 and abs(kur) > 0.001:
                doviz = tl / kur
            if abs(tl) < 0.001 and abs(doviz) > 0.001 and abs(kur) > 0.001:
                tl = doviz * kur
            if abs(tl) < 0.001 and abs(doviz) < 0.001:
                continue
            satirlar.append({
                "hesap_kodu": satir.hesap_kodu,
                "doviz_cinsi": dc,
                "doviz_tutari": doviz,
                "tl_tutar": tl,
                "kaynak": satir.kaynak or "Kur hesaplama",
            })
        return satirlar

    def _varsayilan_kur(self, doviz_cinsi: str) -> float:
        dc = doviz_cinsi.upper()
        if dc == "USD":
            return self.kurlar.usd_alis
        if dc == "EUR":
            return self.kurlar.eur_alis
        if dc == "GBP":
            return self.kurlar.gbp_alis
        if dc == "CHF":
            return self.kurlar.chf_alis
        return 0.0
